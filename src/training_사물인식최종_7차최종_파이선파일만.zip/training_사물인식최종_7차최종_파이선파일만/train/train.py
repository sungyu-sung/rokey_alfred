#!/usr/bin/env python3
"""
YOLO 멀티 버전 학습 스크립트
사용법: python3 train.py --data ../data/data.yaml --models yolov10n
"""

import argparse
import os
import time
from datetime import datetime
from pathlib import Path

MODELS = [
    "yolov10n",
]


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description='YOLO 멀티 버전 학습')
    parser.add_argument('--data',      type=str,   required=True,       help='데이터셋 yaml 경로')
    parser.add_argument('--epochs',    type=int,   default=100,         help='에폭 수 (기본: 100)')
    parser.add_argument('--batch',     type=int,   default=16,          help='배치 사이즈 (기본: 16)')
    parser.add_argument('--imgsz',     type=int,   default=640,         help='이미지 사이즈 (기본: 640)')
    parser.add_argument('--device',    type=str,   default='0',         help='GPU 장치 (기본: 0, CPU: cpu)')
    parser.add_argument('--workers',   type=int,   default=8,           help='데이터로더 워커 수')
    parser.add_argument('--patience',  type=int,   default=50,          help='Early stopping patience (기본: 50)')
    parser.add_argument('--optimizer', type=str,   default='auto',      help='옵티마이저')
    parser.add_argument('--lr',        type=float, default=0.01,        help='초기 학습률')
    parser.add_argument('--save_dir',  type=str,   default='../weights',help='결과 저장 폴더')
    parser.add_argument('--use_date',  action='store_true',             help='폴더명에 날짜 포함')
    parser.add_argument('--skip_done', action='store_true',             help='이미 학습된 모델 스킵')
    parser.add_argument('--models',    type=str,   default=None,        help='모델 지정 (쉼표구분, 예: yolov10n,yolo11s)')
    parser.add_argument('--dry_run',   action='store_true',             help='목록만 출력, 학습 안 함')
    parser.add_argument('--seed',      type=int,   default=0,           help='랜덤 시드')
    parser.add_argument('--no-amp',    action='store_false', dest='amp', help='AMP 비활성화 (기본: 활성화)')
    parser.set_defaults(amp=True)
    return parser


def get_save_dir(base_dir: str, model_name: str, use_date: bool) -> str:
    if use_date:
        date_str = datetime.now().strftime("%Y%m%d")
        return os.path.join(base_dir, f"{date_str}_{model_name}")
    return os.path.join(base_dir, model_name)


def train_model(model_name: str, args) -> dict:
    from ultralytics import YOLO

    save_dir = get_save_dir(args.save_dir, model_name, args.use_date)
    start = time.time()

    print(f"\n{'='*50}")
    print(f"  학습 시작: {model_name}")
    print(f"  저장경로: {save_dir}")
    print(f"{'='*50}")

    try:
        model = YOLO(f"{model_name}.pt")
        model.train(
            data=args.data,
            epochs=args.epochs,
            batch=args.batch,
            imgsz=args.imgsz,
            device=args.device,
            workers=args.workers,
            project=args.save_dir,
            name=os.path.basename(save_dir),
            exist_ok=True,
            patience=args.patience,
            optimizer=args.optimizer,
            lr0=args.lr,
            seed=args.seed,
            amp=args.amp,
            verbose=False,
        )
        elapsed = time.time() - start
        print(f"  완료: {model_name} ({elapsed/60:.1f}분)")
        return {"model": model_name, "status": "success", "time": elapsed}

    except Exception as e:
        elapsed = time.time() - start
        print(f"  실패: {model_name} → {e}")
        return {"model": model_name, "status": "failed", "error": str(e), "time": elapsed}


def print_summary(results: list, total_time: float):
    print(f"\n{'='*50}")
    print(f"  학습 결과 요약")
    print(f"{'='*50}")
    success = [r for r in results if r["status"] == "success"]
    failed  = [r for r in results if r["status"] == "failed"]
    skipped = [r for r in results if r["status"] == "skipped"]

    print(f"  성공: {len(success)}개")
    for r in success:
        print(f"    - {r['model']} ({r['time']/60:.1f}분)")
    if skipped:
        print(f"  스킵: {len(skipped)}개")
        for r in skipped:
            print(f"    - {r['model']}")
    if failed:
        print(f"  실패: {len(failed)}개")
        for r in failed:
            print(f"    - {r['model']}: {r.get('error', '')}")

    print(f"\n  총 소요시간: {total_time/60:.1f}분")
    print(f"{'='*50}\n")


def main():
    parser = build_parser()
    args = parser.parse_args()

    model_list = [m.strip() for m in args.models.split(',')] if args.models else MODELS

    print(f"\n{'='*50}")
    print(f"  YOLO 학습 시작")
    print(f"  데이터셋: {args.data}")
    print(f"  에폭: {args.epochs} | 배치: {args.batch} | GPU: {args.device}")
    print(f"  모델: {model_list}")
    print(f"{'='*50}")

    if args.dry_run:
        print("\n[DRY RUN] 학습할 모델:")
        for i, m in enumerate(model_list, 1):
            print(f"  {i}. {m}")
        return

    results = []
    total_start = time.time()

    for model_name in model_list:
        if args.skip_done:
            weights = os.path.join(
                get_save_dir(args.save_dir, model_name, args.use_date),
                "weights", "best.pt"
            )
            if os.path.exists(weights):
                print(f"  스킵: {model_name} (이미 완료)")
                results.append({"model": model_name, "status": "skipped", "time": 0})
                continue

        results.append(train_model(model_name, args))

    total_time = time.time() - total_start
    print_summary(results, total_time)

    log_path = os.path.join(args.save_dir, "train_summary.txt")
    os.makedirs(args.save_dir, exist_ok=True)
    with open(log_path, "a") as f:
        f.write(f"\n완료: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"총 소요시간: {total_time/60:.1f}분\n\n")
        for r in results:
            f.write(f"{r['model']}: {r['status']} ({r['time']/60:.1f}분)\n")
            if r.get("error"):
                f.write(f"  오류: {r['error']}\n")
    print(f"  결과 로그: {log_path}")


if __name__ == '__main__':
    main()
