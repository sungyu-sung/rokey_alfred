"""train_temp_model.py — 클래스별 N장으로 임시 YOLOv8n 모델 학습

실행:
    python3 train_temp_model.py

결과:
    models/temp_model.pt  ← labeler.py 자동 라벨링에 사용
"""
import shutil
import random
from pathlib import Path
from ultralytics import YOLO

TRAIN_IMG_DIR  = Path("/home/han3/turtlebot4_ws/src/training/data/images")
LBL_DIR        = Path("/home/han3/turtlebot4_ws/src/training/data/labels")
CLASSES_TXT    = Path("/home/han3/turtlebot4_ws/src/training/data/classes.txt")
DATASET_DIR    = Path("/home/han3/turtlebot4_ws/src/training/data")
MODEL_DIR      = Path("/home/han3/turtlebot4_ws/src/training/weights")
EPOCHS         = 50
IMG_SIZE       = 640
VAL_RATIO      = 0.2
PER_CLASS_LIMIT = 20   # 클래스당 최대 학습 장 수


def parse_classes(txt_path: Path) -> set[int]:
    """라벨 txt에서 class_idx 집합 반환."""
    result = set()
    for line in txt_path.read_text().splitlines():
        line = line.strip()
        if line:
            result.add(int(line.split()[0]))
    return result


def build_dataset():
    classes = [l.strip() for l in CLASSES_TXT.read_text().splitlines() if l.strip()]
    print(f"클래스: {classes}")

    # 전체 (img, txt) 쌍 수집
    all_pairs = sorted([
        (p, LBL_DIR / (p.stem + ".txt"))
        for p in TRAIN_IMG_DIR.glob("*.jpg")
        if (LBL_DIR / (p.stem + ".txt")).exists()
    ])
    print(f"전체 데이터: {len(all_pairs)}장")

    # 클래스별 이미지 목록 구성
    class_to_pairs: dict[int, list] = {i: [] for i in range(len(classes))}
    for img_p, txt_p in all_pairs:
        for cls_idx in parse_classes(txt_p):
            if cls_idx in class_to_pairs:
                class_to_pairs[cls_idx].append((img_p, txt_p))

    for i, name in enumerate(classes):
        print(f"  [{i}] {name}: {len(class_to_pairs[i])}장 보유")

    # 클래스별 PER_CLASS_LIMIT 장 샘플링 (중복 허용 — 한 이미지에 여러 클래스)
    random.seed(42)
    selected: set[Path] = set()
    for i, name in enumerate(classes):
        pool = class_to_pairs[i]
        if not pool:
            print(f"  ⚠ [{name}] 데이터 없음 — 건너뜀")
            continue
        random.shuffle(pool)
        picked = pool[:PER_CLASS_LIMIT]
        for img_p, _ in picked:
            selected.add(img_p)
        print(f"  [{name}] {len(picked)}장 선택")

    # 선택된 이미지의 (img, txt) 쌍
    selected_pairs = [(p, LBL_DIR / (p.stem + ".txt")) for p in sorted(selected)]
    print(f"선택 총합 (중복 제거): {len(selected_pairs)}장")

    if not selected_pairs:
        raise RuntimeError("선택된 데이터가 없습니다. train_img/ 에 라벨 데이터를 먼저 추가하세요.")

    # train / val 분할
    random.shuffle(selected_pairs)
    n_val   = max(1, int(len(selected_pairs) * VAL_RATIO))
    val_set = selected_pairs[:n_val]
    trn_set = selected_pairs[n_val:]
    print(f"train: {len(trn_set)}장 / val: {len(val_set)}장")

    SUBSET_DIR = Path("/home/han3/turtlebot4_ws/src/training/data/subset")
    for split, subset in [("train", trn_set), ("val", val_set)]:
        img_dir = SUBSET_DIR / split / "images"
        lbl_dir = SUBSET_DIR / split / "labels"
        img_dir.mkdir(parents=True, exist_ok=True)
        lbl_dir.mkdir(parents=True, exist_ok=True)
        for img_p, txt_p in subset:
            shutil.copy(img_p, img_dir / img_p.name)
            shutil.copy(txt_p, lbl_dir / txt_p.name)

    yaml_content = (
        f"path: {SUBSET_DIR.resolve()}\n"
        f"train: train/images\n"
        f"val:   val/images\n"
        f"nc: {len(classes)}\n"
        f"names: {classes}\n"
    )
    yaml_path = SUBSET_DIR / "data.yaml"
    yaml_path.write_text(yaml_content)
    print(f"data.yaml 생성: {yaml_path}")
    return yaml_path


def train(yaml_path: Path):
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    model = YOLO("yolov8n.pt")
    model.train(
        data=str(yaml_path),
        epochs=EPOCHS,
        imgsz=IMG_SIZE,
        batch=8,
        project=str(MODEL_DIR),
        name="temp",
        exist_ok=True,
        verbose=True,
    )
    best = MODEL_DIR / "temp" / "weights" / "best.pt"
    out  = MODEL_DIR / "temp_model.pt"
    shutil.copy(best, out)
    print(f"\n✅ 모델 저장: {out}")
    return out


if __name__ == "__main__":
    print("=" * 50)
    print(f"임시 모델 학습  (클래스당 최대 {PER_CLASS_LIMIT}장)")
    print("=" * 50)

    if DATASET_DIR.exists():
        shutil.rmtree(DATASET_DIR)
    yaml_path = build_dataset()
    train(yaml_path)
    print("\n학습 완료. labeler.py에서 자동 라벨링 사용 가능.")

