#!/usr/bin/env python3
"""inference_depth.py — YOLO 추론 + RGB-D 3D 좌표 계산

토픽 (고정):
  /camera/color/image_raw  — 컬러
  /camera/depth/image_raw  — 뎁스 (16UC1 mm / 32FC1 m)

변환 방법:
  P1~P4 픽셀(마우스 클릭) + 실세계 X,Y(m) + 뎁스(자동) 입력
  → cv2.findHomography 로 픽셀→실세계 X,Y 변환
  → 4점 뎁스로 바닥 평면(d=a·u+b·v+c) 피팅
  → 감지 사물의 (바닥뎁스 - 실제뎁스) = 바닥 위 높이
"""
import os, sys, threading, json
os.environ['QT_QPA_PLATFORM_PLUGIN_PATH'] = '/usr/lib/x86_64-linux-gnu/qt5/plugins'
os.environ['QT_QPA_PLATFORM'] = 'wayland'

import cv2
import numpy as np
from pathlib import Path
from threading import Lock

from PyQt5 import QtWidgets, QtCore, QtGui
from PyQt5.QtCore import Qt, pyqtSignal, QThread, QTimer

WEIGHTS_DIR   = Path("/home/han3/turtlebot4_ws/src/training/weights")
SETTINGS_FILE = Path(__file__).parent / "inference_depth_settings.json"
COLOR_TOPIC = "/camera/color/image_raw"
DEPTH_TOPIC = "/camera/depth/image_raw"
PT_BGR   = [(0,255,80), (255,128,0), (0,200,255), (255,0,200)]
PT_NAMES = ["P1", "P2", "P3", "P4"]

try:
    import rclpy
    from sensor_msgs.msg import Image
    from cv_bridge import CvBridge
    ROS2_AVAILABLE = True
except ImportError:
    ROS2_AVAILABLE = False


# ── ROS2 구독 ──────────────────────────────────────────────────────────────────
class Ros2DepthSub(QThread):
    color_rx = pyqtSignal(object)
    depth_rx = pyqtSignal(object)

    def __init__(self):
        super().__init__()
        self._stop  = threading.Event()
        self.bridge = CvBridge()
        self._pub_det = None

    def run(self):
        if not rclpy.ok():
            rclpy.init()
        from std_msgs.msg import String as StringMsg
        node = rclpy.create_node('inf_depth_node')
        node.create_subscription(Image, COLOR_TOPIC, self._cb_color, 10)
        node.create_subscription(Image, DEPTH_TOPIC, self._cb_depth, 10)
        self._pub_det = node.create_publisher(StringMsg, '/astra/detection/info', 10)
        while not self._stop.is_set() and rclpy.ok():
            rclpy.spin_once(node, timeout_sec=0.05)
        node.destroy_node()

    def publish_det(self, json_str: str):
        if self._pub_det is None:
            return
        from std_msgs.msg import String as StringMsg
        msg = StringMsg()
        msg.data = json_str
        self._pub_det.publish(msg)

    def _cb_color(self, msg):
        try:
            self.color_rx.emit(self.bridge.imgmsg_to_cv2(msg, 'bgr8'))
        except Exception:
            pass

    def _cb_depth(self, msg):
        try:
            if msg.encoding == '32FC1':
                d = np.frombuffer(msg.data, dtype=np.float32).reshape(
                    msg.height, msg.width).copy()
            else:   # 16UC1 mm
                d = np.frombuffer(msg.data, dtype=np.uint16).reshape(
                    msg.height, msg.width).astype(np.float32) / 1000.0
            self.depth_rx.emit(d)
        except Exception:
            pass

    def stop(self):
        self._stop.set(); self.wait(2000)


# ── 클릭 가능 레이블 ──────────────────────────────────────────────────────────
class ClickableLabel(QtWidgets.QLabel):
    clicked_px = pyqtSignal(int, int)

    def __init__(self):
        super().__init__()
        self._sw = 640; self._sh = 480
        self.setCursor(Qt.CrossCursor)

    def set_src(self, w, h):
        self._sw, self._sh = max(1,w), max(1,h)

    def _map(self, lx, ly):
        lw, lh = self.width(), self.height()
        s = min(lw/self._sw, lh/self._sh)
        dw, dh = self._sw*s, self._sh*s
        rx, ry = lx-(lw-dw)/2, ly-(lh-dh)/2
        if 0 <= rx < dw and 0 <= ry < dh:
            return int(rx*self._sw/dw), int(ry*self._sh/dh)
        return None

    def mousePressEvent(self, ev):
        if ev.button() == Qt.LeftButton:
            r = self._map(ev.x(), ev.y())
            if r:
                self.clicked_px.emit(*r)
        super().mousePressEvent(ev)


# ── 유틸 ──────────────────────────────────────────────────────────────────────
def list_pt_files():
    if not WEIGHTS_DIR.exists():
        return []
    return [str(f.relative_to(WEIGHTS_DIR)) for f in sorted(WEIGHTS_DIR.rglob("*.pt"))]


def run_inference(model, frame, conf, allowed):
    # GPU-level class filter: map label names → class IDs
    class_ids = [k for k, v in model.names.items() if v in allowed]
    if not class_ids:
        return []
    out = []
    for r in model.predict(frame, conf=conf, verbose=False, classes=class_ids):
        if r.boxes is not None and len(r.boxes):
            for box in r.boxes:
                lbl = model.names[int(box.cls[0])]
                if lbl not in allowed:
                    continue
                x1,y1,x2,y2 = box.xyxy[0].tolist()
                out.append({'label':lbl, 'conf':float(box.conf[0]),
                            'cx':int((x1+x2)/2), 'cy':int((y1+y2)/2),
                            'x1':x1,'y1':y1,'x2':x2,'y2':y2, 'type':'det'})
        elif r.obb is not None and len(r.obb):
            for box in r.obb:
                lbl = model.names[int(box.cls[0])]
                if lbl not in allowed:
                    continue
                corners = box.xyxyxyxy[0].cpu().numpy().astype(int)
                mn,mx = corners.min(0), corners.max(0)
                out.append({'label':lbl, 'conf':float(box.conf[0]),
                            'cx':int((mn[0]+mx[0])/2), 'cy':int((mn[1]+mx[1])/2),
                            'x1':mn[0],'y1':mn[1],'x2':mx[0],'y2':mx[1],
                            'corners':corners, 'type':'obb'})
    return out


def to_pixmap(frame, w, h):
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    fh,fw,ch = rgb.shape
    qi = QtGui.QImage(rgb.data, fw,fh,ch*fw, QtGui.QImage.Format_RGB888)
    return QtGui.QPixmap.fromImage(qi).scaled(w,h,Qt.KeepAspectRatio,Qt.SmoothTransformation)


def read_depth_at(depth_arr, u, v):
    """뎁스 배열에서 (u,v) 픽셀의 유효한 뎁스(m) 반환. 없으면 None."""
    if depth_arr is None:
        return None
    if not (0 <= v < depth_arr.shape[0] and 0 <= u < depth_arr.shape[1]):
        return None
    z = float(depth_arr[v, u])
    return z if 0.05 < z < 30.0 else None


# ── 메인 UI ───────────────────────────────────────────────────────────────────
class InferenceDepthUI(QtWidgets.QWidget):
    sig_classes = pyqtSignal(list)
    sig_mdl_st  = pyqtSignal(str, str)
    sig_error   = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        self.model        = None
        self.ros2_sub     = None
        self._clk         = Lock()
        self._dlk         = Lock()
        self._color_frame = None
        self._depth_frame = None
        self.conf         = 0.40
        self._floor_pts      = []   # {u,v,depth_z}  최대 4 (호모그래피용)
        self._extra_floor_pts= []   # 추가 바닥점 (평면 피팅 확장용)
        self._mode        = 'normal'
        self._H           = None    # 호모그래피 (픽셀→world XY)
        self._floor_abc   = None    # (a,b,c): floor_depth(u,v) = a*u+b*v+c
        self._class_checks: dict[str, QtWidgets.QCheckBox] = {}
        self._detections  = []
        self._log_store   = []   # [{ts, items:[{label,conf,cx,cy,z}]}]
        self._saved_class_checks: dict = {}
        self._saved_corr_offsets: dict = {}  # {label: [dx, dy, dh]}

        self._init_ui()
        self.sig_classes.connect(self._rebuild_class_panel)
        self.sig_mdl_st.connect(lambda t,c:(
            self._mdl_lbl.setText(t),
            self._mdl_lbl.setStyleSheet(f"color:{c};font-size:10px;")))
        self.sig_error.connect(lambda m: QtWidgets.QMessageBox.critical(self,"오류",m))
        self._refresh_models()
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._tick)
        self._grid_timer = QTimer(self)
        self._grid_timer.timeout.connect(self._update_grid)
        self._log_timer = QTimer(self)
        self._log_timer.timeout.connect(self._log_tick)
        self._pub_timer = QTimer(self)
        self._pub_timer.timeout.connect(self._publish_tick)
        self._load_settings()
        # 저장된 모델 자동 로드
        if self._mdl_combo.currentText():
            self._load_model()
        # UI 완전 표시 후 ROS2 자동 연결 (200ms 지연)
        QTimer.singleShot(200, self._auto_connect)

    # ── UI 구성 ───────────────────────────────────────────────────────────────
    def _init_ui(self):
        self.setWindowTitle("YOLO Depth 추론  [4점 호모그래피 + 바닥 평면 + 뎁스 그리드]")
        content = QtWidgets.QWidget()
        root = QtWidgets.QVBoxLayout(content)
        root.setSpacing(3); root.setContentsMargins(5,5,5,5)
        root.addLayout(self._top_row())

        # 클래스 + 바닥면 패널 나란히 (수직 공간 절약)
        panels_row = QtWidgets.QHBoxLayout()
        panels_row.setSpacing(4)
        panels_row.addWidget(self._class_panel(), stretch=1)
        panels_row.addWidget(self._floor_panel(), stretch=2)
        root.addLayout(panels_row)

        # 영상 + 뎁스 그리드 나란히 — 남은 공간 모두 차지
        img_row = QtWidgets.QHBoxLayout()
        img_row.addWidget(self._image_panel(), stretch=1)
        img_row.addWidget(self._grid_panel(), stretch=1)
        root.addLayout(img_row, stretch=1)
        root.addWidget(self._result_panel())

        scroll = QtWidgets.QScrollArea()
        scroll.setWidget(content); scroll.setWidgetResizable(True)
        scroll.setStyleSheet("QScrollArea{border:none;}")
        outer = QtWidgets.QVBoxLayout(self)
        outer.setContentsMargins(0,0,0,0); outer.addWidget(scroll)

    # 행1: 연결 | 모델 | 설정
    def _top_row(self):
        row = QtWidgets.QHBoxLayout()

        cg = QtWidgets.QGroupBox("ROS2 연결 (고정 토픽)")
        cl = QtWidgets.QVBoxLayout(cg)
        cl.addWidget(QtWidgets.QLabel(f"색상: {COLOR_TOPIC}"))
        cl.addWidget(QtWidgets.QLabel(f"뎁스: {DEPTH_TOPIC}"))
        br = QtWidgets.QHBoxLayout()
        self._conn_btn = QtWidgets.QPushButton("연결")
        self._conn_btn.setStyleSheet(
            "QPushButton{background:#1a5a1a;color:#88ff88;font-weight:bold;"
            "border:1px solid #336633;border-radius:3px;}"
            "QPushButton:hover{background:#2a7a2a;}")
        self._conn_btn.clicked.connect(self._connect)
        self._disc_btn = QtWidgets.QPushButton("해제"); self._disc_btn.setEnabled(False)
        self._disc_btn.clicked.connect(self._disconnect)
        br.addWidget(self._conn_btn); br.addWidget(self._disc_btn)
        cl.addLayout(br)
        self._conn_lbl = QtWidgets.QLabel("미연결")
        self._conn_lbl.setStyleSheet("color:#888;font-size:10px;")
        cl.addWidget(self._conn_lbl)
        cg.setFixedWidth(260)
        row.addWidget(cg)

        mg = QtWidgets.QGroupBox("모델")
        ml = QtWidgets.QVBoxLayout(mg)
        self._mdl_combo = QtWidgets.QComboBox()
        lb = QtWidgets.QPushButton("로드")
        lb.setStyleSheet(
            "QPushButton{background:#2a2a4a;color:#aaaaff;border:1px solid #6666ff;"
            "border-radius:3px;font-weight:bold;}"
            "QPushButton:hover{background:#3a3a6a;}")
        lb.clicked.connect(self._load_model)
        self._mdl_lbl = QtWidgets.QLabel("미로드")
        self._mdl_lbl.setStyleSheet("color:#888;font-size:10px;"); self._mdl_lbl.setWordWrap(True)
        sr = QtWidgets.QHBoxLayout()
        sr.addWidget(QtWidgets.QLabel("감도:"))
        self._conf_sl = QtWidgets.QSlider(Qt.Horizontal)
        self._conf_sl.setRange(5,95); self._conf_sl.setValue(40)
        self._conf_sl.setStyleSheet(
            "QSlider::groove:horizontal{height:6px;background:#333;border-radius:3px;}"
            "QSlider::handle:horizontal{width:14px;height:14px;margin:-4px 0;"
            "background:#aaaaff;border-radius:7px;}"
            "QSlider::sub-page:horizontal{background:#aaaaff;border-radius:3px;}")
        self._conf_lbl = QtWidgets.QLabel("0.40")
        self._conf_lbl.setFixedWidth(34); self._conf_lbl.setStyleSheet("color:#aaaaff;font-weight:bold;")
        self._conf_sl.valueChanged.connect(self._on_conf)
        sr.addWidget(self._conf_sl); sr.addWidget(self._conf_lbl)
        ml.addWidget(self._mdl_combo); ml.addWidget(lb)
        ml.addWidget(self._mdl_lbl); ml.addLayout(sr)
        row.addWidget(mg)

        og = QtWidgets.QGroupBox("표시 설정")
        ol = QtWidgets.QFormLayout(og)
        rb = QtWidgets.QPushButton("↺ 모델 목록"); rb.clicked.connect(self._refresh_models)
        ol.addRow("", rb)
        self._dw_sp = QtWidgets.QSpinBox()
        self._dw_sp.setRange(320,1280); self._dw_sp.setSingleStep(32)
        self._dw_sp.setValue(640); self._dw_sp.valueChanged.connect(self._on_resize)
        ol.addRow("컬러 너비:", self._dw_sp)
        self._dh_sp = QtWidgets.QSpinBox()
        self._dh_sp.setRange(240,900); self._dh_sp.setSingleStep(32)
        self._dh_sp.setValue(480); self._dh_sp.valueChanged.connect(self._on_resize)
        ol.addRow("컬러 높이:", self._dh_sp)
        # 그리드 셀 수
        self._gcols = QtWidgets.QSpinBox()
        self._gcols.setRange(4,40); self._gcols.setValue(10)
        ol.addRow("그리드 열:", self._gcols)
        self._grows = QtWidgets.QSpinBox()
        self._grows.setRange(3,30); self._grows.setValue(7)
        ol.addRow("그리드 행:", self._grows)
        self._grid_interval_sp = QtWidgets.QSpinBox()
        self._grid_interval_sp.setRange(33, 5000); self._grid_interval_sp.setValue(200)
        self._grid_interval_sp.setSuffix(" ms")
        self._grid_interval_sp.valueChanged.connect(
            lambda v: self._grid_timer.setInterval(v))
        ol.addRow("그리드 갱신:", self._grid_interval_sp)
        self._grid_alpha_sp = QtWidgets.QSpinBox()
        self._grid_alpha_sp.setRange(0, 100); self._grid_alpha_sp.setValue(55)
        self._grid_alpha_sp.setSuffix(" %")
        ol.addRow("오버레이 불투명:", self._grid_alpha_sp)
        row.addWidget(og)
        return row

    # 클래스 선택 패널
    def _class_panel(self):
        grp = QtWidgets.QGroupBox("사물 클래스 선택  (체크된 클래스만 인식)")
        grp.setStyleSheet("QGroupBox{font-weight:bold;color:#88ffcc;background:#0e0e1e;}")
        grp.setMaximumHeight(210)
        outer = QtWidgets.QVBoxLayout(grp)
        br = QtWidgets.QHBoxLayout()
        ab = QtWidgets.QPushButton("전체 선택"); ab.setFixedWidth(90)
        ab.setStyleSheet("QPushButton{background:#1a3a1a;color:#88ff88;"
                         "border:1px solid #336633;border-radius:3px;font-size:11px;}"
                         "QPushButton:hover{background:#2a5a2a;}")
        ab.clicked.connect(self._sel_all)
        nb = QtWidgets.QPushButton("전체 해제"); nb.setFixedWidth(90)
        nb.setStyleSheet("QPushButton{background:#3a1a1a;color:#ff8888;"
                         "border:1px solid #663333;border-radius:3px;font-size:11px;}"
                         "QPushButton:hover{background:#5a2a2a;}")
        nb.clicked.connect(self._sel_none)
        self._cls_info = QtWidgets.QLabel("모델 로드 후 표시")
        self._cls_info.setStyleSheet("color:#666;font-size:10px;")
        br.addWidget(ab); br.addWidget(nb); br.addWidget(self._cls_info); br.addStretch()
        outer.addLayout(br)
        scroll = QtWidgets.QScrollArea(); scroll.setWidgetResizable(True)
        scroll.setMaximumHeight(110)
        scroll.setStyleSheet("QScrollArea{border:1px solid #333;background:#0a0a0a;border-radius:4px;}")
        self._cls_cont = QtWidgets.QWidget(); self._cls_cont.setStyleSheet("background:#0a0a0a;")
        self._cls_grid = QtWidgets.QGridLayout(self._cls_cont)
        self._cls_grid.setSpacing(8); self._cls_grid.setContentsMargins(8,6,8,6)
        scroll.setWidget(self._cls_cont)
        outer.addWidget(scroll)
        return grp

    # 바닥면 4점 패널
    def _floor_panel(self):
        FS  = "font-size:30px;"          # 기본 ~10px × 3
        FSB = "font-size:30px;font-weight:bold;"
        grp = QtWidgets.QGroupBox("바닥면 4점 설정  →  호모그래피(X,Y) + 바닥 평면(Z) 자동 계산")
        grp.setStyleSheet(f"QGroupBox{{font-weight:bold;font-size:30px;color:#ffcc88;background:#0e0e0a;}}")
        vl = QtWidgets.QVBoxLayout(grp); vl.setSpacing(6)

        def _lbl(txt, ss=""):
            w = QtWidgets.QLabel(txt); w.setStyleSheet(FS + ss); return w

        mr = QtWidgets.QHBoxLayout(); mr.setSpacing(8)
        mr.addWidget(_lbl("클릭 모드:"))
        self._mode_bg = QtWidgets.QButtonGroup(self)
        modes = [("일반","normal"),("바닥면4점","floor"),("추가바닥점","floor_extra")]
        for i,(label,val) in enumerate(modes):
            rb = QtWidgets.QRadioButton(label)
            rb.setChecked(val=='normal')
            rb.setStyleSheet(FS)
            rb.toggled.connect(lambda ck,v=val: ck and setattr(self,'_mode',v))
            self._mode_bg.addButton(rb,i)
            mr.addWidget(rb)

        _btn_ss = ("QPushButton{{background:{bg};color:{fg};"
                   "border:1px solid {bd};border-radius:4px;{fs}}}"
                   "QPushButton:hover{{background:{hv};}}")
        def _btn(txt, bg, fg, bd, hv):
            b = QtWidgets.QPushButton(txt)
            b.setStyleSheet(_btn_ss.format(bg=bg,fg=fg,bd=bd,hv=hv,fs=FS))
            return b

        fc = _btn("4점초기화","#2a1a00","#ffaa44","#aa6600","#4a2a00")
        fc.clicked.connect(self._clear_floor)
        ec = _btn("추가점초기화","#1a2a00","#aaff44","#668800","#2a4a00")
        ec.clicked.connect(self._clear_extra_floor)
        self._extra_pts_lbl = _lbl("추가점: 0개", "color:#aaff44;")
        mr.addWidget(fc); mr.addWidget(ec); mr.addWidget(self._extra_pts_lbl)
        mr.addStretch()
        vl.addLayout(mr)

        # 4점 테이블
        tbl = QtWidgets.QGridLayout(); tbl.setSpacing(6)
        for c,txt in enumerate(["포인트","픽셀 좌표  (바닥면 모드 → 클릭)","뎁스 Z","실세계 X(m)","실세계 Y(m)"]):
            tbl.addWidget(_lbl(txt, "color:#aaa;font-weight:bold;"), 0, c)

        self._pt_px_lbl = []
        self._pt_dz_lbl = []
        self._pt_wx_sp  = []
        self._pt_wy_sp  = []
        default_wx = [0.0, 1.0, 1.0, 0.0]
        default_wy = [0.0, 0.0, 1.0, 1.0]
        SP_SS = f"{FS}background:#0d0d1a;color:#ddeeff;"

        for i in range(4):
            bgr = PT_BGR[i]
            nl = QtWidgets.QLabel(PT_NAMES[i])
            nl.setStyleSheet(f"color:rgb({bgr[2]},{bgr[1]},{bgr[0]});"
                             "font-weight:bold;font-size:33px;")
            tbl.addWidget(nl, i+1, 0)

            pl = QtWidgets.QLabel("(미설정)")
            pl.setStyleSheet("color:#666;font-family:monospace;font-size:30px;"
                             "background:#111;border:1px solid #333;padding:3px 8px;border-radius:3px;")
            self._pt_px_lbl.append(pl)
            tbl.addWidget(pl, i+1, 1)

            dz = QtWidgets.QLabel("Z: —")
            dz.setStyleSheet("color:#88aaff;font-family:monospace;font-size:30px;"
                             "background:#0a0a1a;border:1px solid #333;padding:3px 8px;border-radius:3px;")
            self._pt_dz_lbl.append(dz)
            tbl.addWidget(dz, i+1, 2)

            wx = QtWidgets.QDoubleSpinBox()
            wx.setRange(-999,999); wx.setValue(default_wx[i])
            wx.setDecimals(3); wx.setSuffix(" m"); wx.setStyleSheet(SP_SS)
            self._pt_wx_sp.append(wx)
            tbl.addWidget(wx, i+1, 3)

            wy = QtWidgets.QDoubleSpinBox()
            wy.setRange(-999,999); wy.setValue(default_wy[i])
            wy.setDecimals(3); wy.setSuffix(" m"); wy.setStyleSheet(SP_SS)
            self._pt_wy_sp.append(wy)
            tbl.addWidget(wy, i+1, 4)

        vl.addLayout(tbl)

        # 호모그래피 계산 버튼 + 상태
        hr = QtWidgets.QHBoxLayout()
        hb = QtWidgets.QPushButton("호모그래피 계산  (픽셀 → 실세계 X,Y  +  바닥 평면 Z 자동)")
        hb.setStyleSheet(
            f"QPushButton{{background:#1a2a4a;color:#aaccff;border:1px solid #4466aa;"
            f"border-radius:4px;font-weight:bold;{FS}}}"
            "QPushButton:hover{background:#2a3a5a;}")
        hb.clicked.connect(self._compute_H)
        self._H_lbl = _lbl("미계산  (4점 클릭 → 실세계 X,Y 입력 → 계산)", "color:#888;")
        hr.addWidget(hb); hr.addWidget(self._H_lbl); hr.addStretch()
        vl.addLayout(hr)

        # 적용설정값: 바닥 평면 계수 (depth = a·u + b·v + c)
        abc_row = QtWidgets.QHBoxLayout(); abc_row.setSpacing(6)
        abc_row.addWidget(_lbl("바닥평면계수:","color:#ffdd88;font-weight:bold;"))
        abc_row.addWidget(_lbl("a","color:#aaaaff;"))
        self._abc_a_sp = QtWidgets.QDoubleSpinBox()
        self._abc_a_sp.setRange(-1, 1); self._abc_a_sp.setValue(0.0)
        self._abc_a_sp.setDecimals(6); self._abc_a_sp.setStyleSheet(SP_SS)
        abc_row.addWidget(self._abc_a_sp)
        abc_row.addWidget(_lbl("b","color:#aaaaff;"))
        self._abc_b_sp = QtWidgets.QDoubleSpinBox()
        self._abc_b_sp.setRange(-1, 1); self._abc_b_sp.setValue(0.0)
        self._abc_b_sp.setDecimals(6); self._abc_b_sp.setStyleSheet(SP_SS)
        abc_row.addWidget(self._abc_b_sp)
        abc_row.addWidget(_lbl("c(m)","color:#aaaaff;"))
        self._abc_c_sp = QtWidgets.QDoubleSpinBox()
        self._abc_c_sp.setRange(-20, 20); self._abc_c_sp.setValue(0.0)
        self._abc_c_sp.setDecimals(4); self._abc_c_sp.setSuffix(" m"); self._abc_c_sp.setStyleSheet(SP_SS)
        abc_row.addWidget(self._abc_c_sp)
        apply_abc_btn = _btn("적용","#1a2a1a","#88ffaa","#336633","#2a3a2a")
        apply_abc_btn.clicked.connect(self._apply_floor_abc)
        abc_row.addWidget(apply_abc_btn)
        abc_row.addStretch()
        vl.addLayout(abc_row)

        # 기준점: P1 기준 오프셋 입력
        ref_row = QtWidgets.QHBoxLayout(); ref_row.setSpacing(8)
        ref_row.addWidget(_lbl("기준점 (P1+오프셋):","color:#aaddff;font-weight:bold;"))
        ref_row.addWidget(_lbl("ΔX:","color:#ffaaaa;"))
        self._ref_x_sp = QtWidgets.QDoubleSpinBox()
        self._ref_x_sp.setRange(-999,999); self._ref_x_sp.setValue(0.0)
        self._ref_x_sp.setDecimals(3); self._ref_x_sp.setSuffix(" m"); self._ref_x_sp.setStyleSheet(SP_SS)
        ref_row.addWidget(self._ref_x_sp)
        ref_row.addWidget(_lbl("ΔY:","color:#ffaaaa;"))
        self._ref_y_sp = QtWidgets.QDoubleSpinBox()
        self._ref_y_sp.setRange(-999,999); self._ref_y_sp.setValue(0.0)
        self._ref_y_sp.setDecimals(3); self._ref_y_sp.setSuffix(" m"); self._ref_y_sp.setStyleSheet(SP_SS)
        ref_row.addWidget(self._ref_y_sp)
        ref_row.addWidget(_lbl("ΔZ:","color:#ffaaaa;"))
        self._ref_z_sp = QtWidgets.QDoubleSpinBox()
        self._ref_z_sp.setRange(-999,999); self._ref_z_sp.setValue(0.0)
        self._ref_z_sp.setDecimals(3); self._ref_z_sp.setSuffix(" m"); self._ref_z_sp.setStyleSheet(SP_SS)
        ref_row.addWidget(self._ref_z_sp)
        ref_row.addWidget(_lbl("→ (0,0,0)=P1위치","color:#888;"))
        ref_clr = _btn("초기화","#001a2a","#44aaff","#006699","#002a3a")
        ref_clr.clicked.connect(self._clear_ref)
        ref_row.addWidget(ref_clr)
        ref_row.addStretch()
        vl.addLayout(ref_row)

        # 카메라 높이 + 바닥 허용 오차
        cam_row = QtWidgets.QHBoxLayout(); cam_row.setSpacing(8)
        cam_row.addWidget(_lbl("카메라 높이:"))
        self._cam_h_sp = QtWidgets.QDoubleSpinBox()
        self._cam_h_sp.setRange(0.05, 5.0); self._cam_h_sp.setValue(0.50)
        self._cam_h_sp.setDecimals(2); self._cam_h_sp.setSuffix(" m"); self._cam_h_sp.setStyleSheet(SP_SS)
        cam_row.addWidget(self._cam_h_sp)
        cam_row.addSpacing(20)
        cam_row.addWidget(_lbl("바닥 판별 허용:"))
        self._floor_tol_sp = QtWidgets.QDoubleSpinBox()
        self._floor_tol_sp.setRange(1, 100); self._floor_tol_sp.setValue(6)
        self._floor_tol_sp.setDecimals(0); self._floor_tol_sp.setSuffix(" cm"); self._floor_tol_sp.setStyleSheet(SP_SS)
        cam_row.addWidget(self._floor_tol_sp)
        cam_row.addStretch()
        vl.addLayout(cam_row)
        return grp

    # 컬러 영상 패널
    def _image_panel(self):
        grp = QtWidgets.QGroupBox("컬러 영상  (클릭 → 좌표 설정)")
        grp.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        lay = QtWidgets.QVBoxLayout(grp)
        lay.setContentsMargins(2,2,2,2)
        self._img = ClickableLabel()
        self._img.setMinimumSize(640, 480)
        self._img.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        self._img.setStyleSheet("background:#111;color:#555;")
        self._img.setAlignment(Qt.AlignCenter)
        self._img.setText("연결 대기 중...")
        self._img.clicked_px.connect(self._on_click)
        lay.addWidget(self._img)
        return grp

    # 뎁스 그리드 패널
    def _grid_panel(self):
        grp = QtWidgets.QGroupBox(
            "뎁스 그리드  ■=바닥(녹)  ■=10cm↑(황)  ■=30cm↑(주)  ■=50cm↑(적)  □=뎁스없음")
        grp.setStyleSheet("QGroupBox{font-weight:bold;color:#aaddff;}")
        grp.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        lay = QtWidgets.QVBoxLayout(grp)
        lay.setContentsMargins(2,2,2,2)
        self._grid_lbl = QtWidgets.QLabel()
        self._grid_lbl.setMinimumSize(580, 480)
        self._grid_lbl.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        self._grid_lbl.setStyleSheet("background:#0a0a10;")
        self._grid_lbl.setAlignment(Qt.AlignCenter)
        self._grid_lbl.setText("연결 후 바닥 4점 설정 시 그리드 표시")
        lay.addWidget(self._grid_lbl)
        return grp

    # 결과 테이블
    def _result_panel(self):
        grp = QtWidgets.QGroupBox("감지 로그  (X · Y · 높이(m))")
        grp.setMinimumHeight(220)
        lay = QtWidgets.QVBoxLayout(grp)
        lay.setContentsMargins(3, 3, 3, 3); lay.setSpacing(4)

        # 컨트롤 행
        ctrl = QtWidgets.QHBoxLayout()
        # 자동 시작/정지 버튼
        self._log_auto_btn = QtWidgets.QPushButton("▶ 자동 시작"); self._log_auto_btn.setFixedWidth(100)
        self._log_auto_btn.setCheckable(True)
        self._log_auto_btn.setStyleSheet(
            "QPushButton{background:#0a2a0a;color:#66ff66;border:1px solid #336633;"
            "border-radius:4px;font-size:11px;font-weight:bold;}"
            "QPushButton:checked{background:#0a4a0a;color:#00ff88;border:1px solid #00cc44;}"
            "QPushButton:hover{background:#1a3a1a;}")
        self._log_auto_btn.toggled.connect(self._toggle_log_auto)
        ctrl.addWidget(self._log_auto_btn)
        ctrl.addWidget(QtWidgets.QLabel("간격:"))
        self._log_iv_sp = QtWidgets.QSpinBox()
        self._log_iv_sp.setRange(1, 60); self._log_iv_sp.setValue(3)
        self._log_iv_sp.setSuffix(" 초"); self._log_iv_sp.setFixedWidth(80)
        self._log_iv_sp.valueChanged.connect(
            lambda v: self._log_timer.setInterval(v * 1000))
        ctrl.addWidget(self._log_iv_sp)
        clr_btn = QtWidgets.QPushButton("지우기"); clr_btn.setFixedWidth(70)
        clr_btn.setStyleSheet(
            "QPushButton{background:#2a1010;color:#ff8888;border:1px solid #aa3333;"
            "border-radius:3px;font-size:10px;}"
            "QPushButton:hover{background:#4a1a1a;}")
        clr_btn.clicked.connect(self._clear_log)
        ctrl.addWidget(clr_btn)
        self._log_cnt_lbl = QtWidgets.QLabel("대기 중")
        self._log_cnt_lbl.setStyleSheet("color:#888;font-size:11px;")
        ctrl.addWidget(self._log_cnt_lbl)
        ctrl.addSpacing(20)
        ctrl.addWidget(QtWidgets.QLabel("발행 주기:"))
        self._pub_iv_sp = QtWidgets.QDoubleSpinBox()
        self._pub_iv_sp.setRange(0.1, 10.0); self._pub_iv_sp.setSingleStep(0.1)
        self._pub_iv_sp.setDecimals(1); self._pub_iv_sp.setValue(0.5)
        self._pub_iv_sp.setSuffix(" 초"); self._pub_iv_sp.setFixedWidth(90)
        self._pub_iv_sp.valueChanged.connect(
            lambda v: self._pub_timer.setInterval(int(v * 1000)))
        ctrl.addWidget(self._pub_iv_sp)
        ctrl.addStretch()
        lay.addLayout(ctrl)

        # 오프셋 입력 테이블 (클래스별 X/Y/높이 오프셋 — 로그 표시값에 더해짐)
        self._corr_tbl = QtWidgets.QTableWidget(0, 4)
        self._corr_tbl.setHorizontalHeaderLabels(
            ["클래스", "X오프셋(m)", "Y오프셋(m)", "높이오프셋(m)"])
        self._corr_tbl.setFixedHeight(130)
        self._corr_tbl.setStyleSheet(
            "QTableWidget{background:#080814;color:#cccccc;gridline-color:#2a2a3a;"
            "font-size:18px;}"
            "QHeaderView::section{background:#12122a;color:#aaccff;"
            "border:1px solid #2a2a3a;font-size:14px;font-weight:bold;}"
            "QTableWidget::item:selected{background:#1a2a4a;}")
        self._corr_tbl.horizontalHeader().setStretchLastSection(True)
        self._corr_tbl.verticalHeader().setDefaultSectionSize(36)
        self._corr_tbl.setEditTriggers(
            QtWidgets.QAbstractItemView.AllEditTriggers)
        self._corr_tbl.itemChanged.connect(self._on_corr_tbl_changed)
        lay.addWidget(self._corr_tbl)

        # 로그 텍스트 + 전송 목록 (나란히)
        bottom = QtWidgets.QHBoxLayout()
        self._log_txt = QtWidgets.QTextEdit()
        self._log_txt.setReadOnly(True)
        self._log_txt.setStyleSheet(
            "QTextEdit{background:#050510;color:#cccccc;"
            "border:1px solid #2a2a3a;font-family:monospace;}")
        bottom.addWidget(self._log_txt, 2)
        bottom.addWidget(self._pub_panel(), 1)
        lay.addLayout(bottom)
        return grp

    # 전송 목록 패널 (노드로 보낸 클래스명/X/Y)
    def _pub_panel(self):
        grp = QtWidgets.QGroupBox("전송 목록  (노드로 보낸 값)")
        grp.setStyleSheet("QGroupBox{font-weight:bold;color:#ffaa88;}")
        lay = QtWidgets.QVBoxLayout(grp)
        self._pub_cnt_lbl = QtWidgets.QLabel("대기 중")
        self._pub_cnt_lbl.setStyleSheet("color:#888;font-size:11px;")
        lay.addWidget(self._pub_cnt_lbl)
        self._pub_tbl = QtWidgets.QTableWidget(0, 3)
        self._pub_tbl.setHorizontalHeaderLabels(["클래스", "X(m)", "Y(m)"])
        self._pub_tbl.setStyleSheet(
            "QTableWidget{background:#080814;color:#ffddcc;gridline-color:#2a2a3a;"
            "font-family:monospace;font-size:14px;}"
            "QHeaderView::section{background:#2a1a12;color:#ffaa88;"
            "border:1px solid #2a2a3a;font-size:12px;font-weight:bold;}")
        self._pub_tbl.horizontalHeader().setStretchLastSection(True)
        self._pub_tbl.verticalHeader().setVisible(False)
        self._pub_tbl.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        lay.addWidget(self._pub_tbl)
        return grp

    # ── 클래스 패널 ───────────────────────────────────────────────────────────
    def _rebuild_class_panel(self, names):
        prev = {k: cb.isChecked() for k,cb in self._class_checks.items()}
        if self._saved_class_checks:
            prev.update(self._saved_class_checks)
        for i in reversed(range(self._cls_grid.count())):
            w = self._cls_grid.itemAt(i).widget()
            if w: w.deleteLater()
        self._class_checks.clear()
        COLS = 5
        for idx, name in enumerate(names):
            cb = QtWidgets.QCheckBox(name)
            cb.setChecked(prev.get(name, True)); cb.setMinimumWidth(100)
            cb.setStyleSheet(
                "QCheckBox{color:#e8ffe8;font-size:13px;font-weight:bold;"
                "padding:4px 8px;background:#141414;border:1px solid #333;border-radius:4px;}"
                "QCheckBox:hover{background:#1e2e1e;border:1px solid #44aa66;}"
                "QCheckBox::indicator{width:18px;height:18px;}"
                "QCheckBox::indicator:checked{background:#22aa44;border:2px solid #66dd88;border-radius:4px;}"
                "QCheckBox::indicator:unchecked{background:#1a1a1a;border:2px solid #555;border-radius:4px;}")
            self._cls_grid.addWidget(cb, idx//COLS, idx%COLS)
            self._class_checks[name] = cb
        self._cls_info.setText(f"총 {len(names)}개 클래스")
        self._cls_info.setStyleSheet("color:#88ffcc;font-size:11px;font-weight:bold;")

    def _allowed(self):
        return {k for k,cb in self._class_checks.items() if cb.isChecked()}

    def _sel_all(self):
        for cb in self._class_checks.values(): cb.setChecked(True)

    def _sel_none(self):
        for cb in self._class_checks.values(): cb.setChecked(False)

    # ── 바닥 평면 피팅 ────────────────────────────────────────────────────────
    def _fit_floor_plane(self):
        """모든 바닥점(4점 + 추가점)으로 평면 피팅: depth = a*u + b*v + c"""
        pts = self._floor_pts + self._extra_floor_pts
        if len(pts) < 3:
            self._floor_abc = None; return
        A = np.array([[p['u'], p['v'], 1.0] for p in pts], dtype=np.float64)
        b = np.array([p['depth_z'] for p in pts], dtype=np.float64)
        coeffs, _, _, _ = np.linalg.lstsq(A, b, rcond=None)
        self._floor_abc = tuple(coeffs)
        pred = A @ coeffs
        rms = float(np.sqrt(((pred - b)**2).mean()))
        self._sync_abc_ui()
        return rms

    def _sync_abc_ui(self):
        """현재 _floor_abc 값을 UI spinbox에 반영."""
        if self._floor_abc is None:
            return
        a, b, c = self._floor_abc
        self._abc_a_sp.setValue(float(a))
        self._abc_b_sp.setValue(float(b))
        self._abc_c_sp.setValue(float(c))

    def _apply_floor_abc(self):
        """spinbox 값을 _floor_abc에 직접 적용하고 로그 재계산."""
        a = self._abc_a_sp.value()
        b = self._abc_b_sp.value()
        c = self._abc_c_sp.value()
        self._floor_abc = (a, b, c)
        self._H_lbl.setText(
            f"✅ 수동 설정 적용  a={a:.6f}  b={b:.6f}  c={c:.4f}m")
        self._H_lbl.setStyleSheet("color:#ffdd88;font-size:10px;font-weight:bold;")
        self._recompute_log()

    def _open_abc_dialog(self):
        """바닥 평면 계수 수정 팝업 — a,b,c 조정 시 감지값(X,Y,높이) 실시간 미리보기."""
        dlg = QtWidgets.QDialog(self)
        dlg.setWindowTitle("바닥 평면 계수  |  감지값 실시간 미리보기")
        dlg.setMinimumWidth(700)
        dlg.setStyleSheet("background:#0e0e16;color:#dddddd;")

        vl = QtWidgets.QVBoxLayout(dlg)
        vl.setSpacing(10); vl.setContentsMargins(14, 14, 14, 14)

        SP  = "font-size:22px;background:#0d0d1a;color:#ddeeff;"
        LBL = "font-size:22px;color:#ffdd88;font-weight:bold;min-width:210px;"

        def mkrow(txt, sp):
            h = QtWidgets.QHBoxLayout()
            l = QtWidgets.QLabel(txt); l.setStyleSheet(LBL)
            h.addWidget(l); h.addWidget(sp); h.addStretch()
            return h

        a_sp = QtWidgets.QDoubleSpinBox()
        a_sp.setRange(-1, 1); a_sp.setDecimals(6); a_sp.setStyleSheet(SP); a_sp.setFixedWidth(230)
        a_sp.setValue(self._floor_abc[0] if self._floor_abc else 0.0)
        a_sp.setToolTip("가로(u) 기울기 — 픽셀 1개당 바닥 깊이 변화량")

        b_sp = QtWidgets.QDoubleSpinBox()
        b_sp.setRange(-1, 1); b_sp.setDecimals(6); b_sp.setStyleSheet(SP); b_sp.setFixedWidth(230)
        b_sp.setValue(self._floor_abc[1] if self._floor_abc else 0.0)
        b_sp.setToolTip("세로(v) 기울기 — 픽셀 1개당 바닥 깊이 변화량")

        c_sp = QtWidgets.QDoubleSpinBox()
        c_sp.setRange(-20, 20); c_sp.setDecimals(4); c_sp.setSuffix(" m")
        c_sp.setStyleSheet(SP); c_sp.setFixedWidth(230)
        c_sp.setValue(self._floor_abc[2] if self._floor_abc else 0.0)
        c_sp.setToolTip("절편 — 픽셀(0,0) 기준 바닥 예상 깊이")

        vl.addLayout(mkrow("a  (가로 기울기):", a_sp))
        vl.addLayout(mkrow("b  (세로 기울기):", b_sp))
        vl.addLayout(mkrow("c  (기준 깊이):", c_sp))

        # ── 실시간 미리보기 ──────────────────────────────────────────────────
        sep = QtWidgets.QFrame(); sep.setFrameShape(QtWidgets.QFrame.HLine)
        sep.setStyleSheet("color:#333;"); vl.addWidget(sep)

        prev_title = QtWidgets.QLabel("◀ 현재 감지 결과 미리보기  (계수 바꿀 때마다 자동 갱신)")
        prev_title.setStyleSheet("font-size:18px;color:#aaddff;font-weight:bold;")
        vl.addWidget(prev_title)

        prev_txt = QtWidgets.QTextEdit()
        prev_txt.setReadOnly(True)
        prev_txt.setFixedHeight(220)
        prev_txt.setStyleSheet("QTextEdit{background:#05050f;border:1px solid #2a2a3a;font-size:20px;}")
        vl.addWidget(prev_txt)

        cam_h = self._cam_h_sp.value()

        def _preview_xyz_with(cx, cy, z, a, b, c):
            """임시 a,b,c로 X,Y,높이 계산 (self._floor_abc 수정 없음)."""
            floor_z = a * cx + b * cy + c
            # X, Y: 호모그래피 + 비례식
            X, Y = None, None
            if self._H is not None:
                import numpy as _np
                pt  = _np.array([[[float(cx), float(cy)]]], dtype=_np.float32)
                wpt = _np.dot  # avoid re-import
                import cv2 as _cv2
                wpt = _cv2.perspectiveTransform(pt, self._H)
                X_f, Y_f = float(wpt[0,0,0]), float(wpt[0,0,1])
                if z is not None and floor_z > 0.01:
                    r = z / floor_z; X = X_f * r; Y = Y_f * r
                else:
                    X, Y = X_f, Y_f
            # 높이: cam_h 원근 보정
            ht = None
            if z is not None and floor_z > 0.01:
                ht = cam_h * (floor_z - z) / floor_z
            return X, Y, ht

        def _refresh_preview():
            dets = self._detections
            a, b, c = a_sp.value(), b_sp.value(), c_sp.value()
            RED = "#ff4444"; YEL = "#ffdd88"; GRY = "#888"
            FS  = "20pt"
            if not dets:
                prev_txt.setHtml(
                    f"<span style='color:{GRY};font-size:{FS}'>현재 감지된 사물 없음</span>")
                return
            html = []
            for d in dets:
                cx, cy = d['cx'], d['cy']
                z = d['xyz'][2] if d['xyz'] else None
                X, Y, ht = _preview_xyz_with(cx, cy, z, a, b, c)
                xs = f"{X:.3f}" if X is not None else "—"
                ys = f"{Y:.3f}" if Y is not None else "—"
                hs = f"{ht:.3f}" if ht is not None else "—"
                html.append(
                    f"<span style='color:{YEL};font-size:{FS};font-weight:bold'>{d['label']}</span>"
                    f"&nbsp;&nbsp;"
                    f"<span style='color:{GRY};font-size:{FS}'>X:</span>"
                    f"<span style='color:{RED};font-size:{FS};font-weight:bold'> {xs}m</span>"
                    f"&nbsp;&nbsp;"
                    f"<span style='color:{GRY};font-size:{FS}'>Y:</span>"
                    f"<span style='color:{RED};font-size:{FS};font-weight:bold'> {ys}m</span>"
                    f"&nbsp;&nbsp;"
                    f"<span style='color:{GRY};font-size:{FS}'>높이:</span>"
                    f"<span style='color:{RED};font-size:{FS};font-weight:bold'> {hs}m</span>"
                    f"<br>"
                )
            prev_txt.setHtml("".join(html))

        a_sp.valueChanged.connect(lambda _: _refresh_preview())
        b_sp.valueChanged.connect(lambda _: _refresh_preview())
        c_sp.valueChanged.connect(lambda _: _refresh_preview())
        _refresh_preview()   # 초기 표시

        # 주기 갱신 (감지 결과 바뀌면 반영)
        refresh_timer = QTimer(dlg)
        refresh_timer.timeout.connect(_refresh_preview)
        refresh_timer.start(500)

        # ── 상태 + 버튼 ────────────────────────────────────────────────────
        cur_lbl = QtWidgets.QLabel(
            (f"현재: a={self._floor_abc[0]:.6f}  b={self._floor_abc[1]:.6f}  c={self._floor_abc[2]:.4f}m"
             if self._floor_abc else "현재 바닥 평면 미설정"))
        cur_lbl.setStyleSheet("font-size:16px;color:#888;")
        vl.addWidget(cur_lbl)

        btn_row = QtWidgets.QHBoxLayout()
        apply_btn = QtWidgets.QPushButton("✅ 적용 + 로그 전체 재계산")
        apply_btn.setStyleSheet(
            "QPushButton{background:#1a3a1a;color:#88ffaa;border:1px solid #336633;"
            "border-radius:4px;font-size:20px;font-weight:bold;padding:6px 18px;}"
            "QPushButton:hover{background:#2a4a2a;}")
        cancel_btn = QtWidgets.QPushButton("닫기")
        cancel_btn.setStyleSheet(
            "QPushButton{background:#2a1a1a;color:#ff8888;border:1px solid #883333;"
            "border-radius:4px;font-size:18px;padding:6px 14px;}"
            "QPushButton:hover{background:#3a2a2a;}")

        def _apply():
            a, b, c = a_sp.value(), b_sp.value(), c_sp.value()
            self._floor_abc = (a, b, c)
            self._abc_a_sp.setValue(a); self._abc_b_sp.setValue(b); self._abc_c_sp.setValue(c)
            self._H_lbl.setText(f"✅ 수동 설정  a={a:.6f}  b={b:.6f}  c={c:.4f}m")
            self._H_lbl.setStyleSheet("color:#ffdd88;font-size:10px;font-weight:bold;")
            self._recompute_log()
            cur_lbl.setText(f"적용됨: a={a:.6f}  b={b:.6f}  c={c:.4f}m")
            cur_lbl.setStyleSheet("font-size:16px;color:#88ffaa;font-weight:bold;")

        apply_btn.clicked.connect(_apply)
        cancel_btn.clicked.connect(dlg.accept)
        btn_row.addWidget(apply_btn); btn_row.addWidget(cancel_btn); btn_row.addStretch()
        vl.addLayout(btn_row)
        dlg.exec_()

    def _floor_depth(self, u, v):
        """바닥 평면 모델에서 픽셀(u,v)의 예상 뎁스(m). 없으면 None."""
        if self._floor_abc is None:
            return None
        a,b,c = self._floor_abc
        return a*u + b*v + c

    def _height_above_floor(self, u, v, actual_z=None):
        """바닥 위 실세계 높이(m). 카메라 높이 원근 보정 적용."""
        fd = self._floor_depth(u, v)
        if fd is None:
            return None
        if actual_z is None:
            with self._dlk:
                depth = self._depth_frame
            actual_z = read_depth_at(depth, u, v)
        if actual_z is None:
            return None
        cam_h = self._cam_h_sp.value()
        depth_diff = fd - actual_z
        # 원근 보정: cam_h × (fd - actual_z) / fd
        return (cam_h * depth_diff / fd) if fd > 0.01 else depth_diff

    # ── 호모그래피 계산 ───────────────────────────────────────────────────────
    def _compute_H(self):
        if len(self._floor_pts) < 4:
            self._H_lbl.setText(f"오류: 4점 필요 (현재 {len(self._floor_pts)}점)")
            self._H_lbl.setStyleSheet("color:#ff8888;font-size:10px;")
            return

        px_pts = np.array([[p['u'],p['v']] for p in self._floor_pts[:4]], dtype=np.float32)
        wx_pts = np.array([
            [self._pt_wx_sp[i].value(), self._pt_wy_sp[i].value()]
            for i in range(4)
        ], dtype=np.float32)

        H, _ = cv2.findHomography(px_pts, wx_pts, cv2.RANSAC)
        if H is None:
            self._H_lbl.setText("계산 실패 (4점 공선 불가)")
            self._H_lbl.setStyleSheet("color:#ff8888;font-size:10px;")
            return
        self._H = H

        proj = cv2.perspectiveTransform(px_pts.reshape(-1,1,2), H).reshape(-1,2)
        rms_h = float(np.sqrt(((proj - wx_pts)**2).sum(axis=1).mean()))

        # 바닥 평면도 피팅
        rms_f = self._fit_floor_plane()

        msg = f"✅ 호모그래피 RMS={rms_h:.4f}m"
        if rms_f is not None:
            msg += f"  |  바닥평면 RMS={rms_f:.4f}m"
        self._H_lbl.setText(msg)
        self._H_lbl.setStyleSheet("color:#88ff88;font-size:10px;font-weight:bold;")
        self._recompute_log()   # 보정 완료 → 저장된 로그 전체 재계산

    # ── 3D 좌표 계산 ─────────────────────────────────────────────────────────
    def _get_3d(self, u, v, z_override=None):
        """픽셀(u,v) → (X,Y,Z).
        z_override: 저장된 Z값으로 재계산 시 전달 (로그 보정 재적용용)."""
        if self._H is None:
            return None

        pt  = np.array([[[float(u),float(v)]]], dtype=np.float32)
        wpt = cv2.perspectiveTransform(pt, self._H)
        X_f, Y_f = float(wpt[0,0,0]), float(wpt[0,0,1])

        if z_override is not None:
            Z = z_override
        else:
            with self._dlk:
                depth = self._depth_frame
            Z = read_depth_at(depth, u, v)

        if Z is not None and self._floor_abc is not None:
            # 비례식: 실제물체 XY = 바닥면XY × (실제뎁스 / 바닥뎁스)
            Z_f = self._floor_depth(u, v)
            if Z_f and Z_f > 0.01:
                ratio = Z / Z_f
                X = X_f * ratio
                Y = Y_f * ratio
            else:
                X, Y = X_f, Y_f
        else:
            X, Y = X_f, Y_f

        return (X, Y, Z)

    def _ref_offset(self):
        """P1 월드 좌표 + 오프셋 스핀박스 = 기준점(ref_x, ref_y). 감지 로그와 동일 기준."""
        if not self._floor_pts:
            return 0.0, 0.0
        return (self._pt_wx_sp[0].value() + self._ref_x_sp.value(),
                self._pt_wy_sp[0].value() + self._ref_y_sp.value())

    def _relative(self, xyz):
        """P1 월드 좌표 + 오프셋 스핀박스 값이 기준점. P1 미설정이면 None."""
        if xyz is None: return None
        x, y, z = xyz
        if x is None: return None
        # P1 월드 좌표 (4점 테이블에서 설정한 값)
        if not self._floor_pts:
            return None
        p1_wx = self._pt_wx_sp[0].value()
        p1_wy = self._pt_wy_sp[0].value()
        p1_wz = self._floor_pts[0]['depth_z']
        # 오프셋 더해서 최종 기준점
        rx = p1_wx + self._ref_x_sp.value()
        ry = p1_wy + self._ref_y_sp.value()
        rz = p1_wz + self._ref_z_sp.value()
        dz = (z - rz) if z is not None else None
        return (x - rx, y - ry, dz)

    # ── 클릭 핸들러 ───────────────────────────────────────────────────────────
    def _on_click(self, u: int, v: int):
        if self._mode == 'floor':
            # ★ FIX: 뎁스 먼저 읽기 — 없으면 에러 표시 후 리턴
            with self._dlk:
                depth = self._depth_frame
            depth_z = read_depth_at(depth, u, v)

            if depth_z is None:
                reason = "뎁스 이미지 미연결" if depth is None else f"픽셀({u},{v}) 뎁스 없음"
                QtWidgets.QMessageBox.warning(
                    self, "뎁스 읽기 실패",
                    f"{reason}\n유효 범위(0.05 ~ 30.0m) 밖이거나 뎁스가 없는 영역입니다.\n"
                    "다른 위치를 클릭하세요.")
                return

            if len(self._floor_pts) >= 4:
                self._floor_pts.clear()
                self._floor_abc = None; self._H = None
                for lbl in self._pt_px_lbl:
                    lbl.setText("(미설정)")
                    lbl.setStyleSheet("color:#666;font-family:monospace;font-size:11px;"
                                     "background:#111;border:1px solid #333;padding:2px 6px;border-radius:3px;")
                for lbl in self._pt_dz_lbl:
                    lbl.setText("Z: —")
                    lbl.setStyleSheet("color:#88aaff;font-family:monospace;font-size:11px;"
                                     "background:#0a0a1a;border:1px solid #333;padding:2px 6px;border-radius:3px;")
                self._H_lbl.setText("초기화됨")
                self._H_lbl.setStyleSheet("color:#888;font-size:10px;")

            i = len(self._floor_pts)
            self._floor_pts.append({'u': u, 'v': v, 'depth_z': depth_z})

            bgr = PT_BGR[i]
            self._pt_px_lbl[i].setText(f"u={u},  v={v}")
            self._pt_px_lbl[i].setStyleSheet(
                f"color:rgb({bgr[2]},{bgr[1]},{bgr[0]});font-family:monospace;"
                "font-size:11px;font-weight:bold;background:#111;border:1px solid #555;"
                "padding:2px 6px;border-radius:3px;")
            self._pt_dz_lbl[i].setText(f"Z: {depth_z:.3f}m")
            self._pt_dz_lbl[i].setStyleSheet(
                "color:#aaddff;font-family:monospace;font-size:11px;font-weight:bold;"
                "background:#0a0a1a;border:1px solid #4466aa;padding:2px 6px;border-radius:3px;")

        elif self._mode == 'floor_extra':
            with self._dlk:
                depth = self._depth_frame
            depth_z = read_depth_at(depth, u, v)
            if depth_z is None:
                QtWidgets.QMessageBox.warning(
                    self, "뎁스 읽기 실패",
                    f"픽셀({u},{v}) 뎁스 없음\n다른 위치를 클릭하세요.")
                return
            self._extra_floor_pts.append({'u': u, 'v': v, 'depth_z': depth_z})
            self._extra_pts_lbl.setText(f"추가점: {len(self._extra_floor_pts)}개")
            # 추가점 포함 평면 재피팅
            if len(self._floor_pts) >= 3:
                self._fit_floor_plane()


    def _clear_floor(self):
        self._floor_pts.clear(); self._floor_abc = None; self._H = None
        for lbl in self._pt_px_lbl:
            lbl.setText("(미설정)")
            lbl.setStyleSheet("color:#666;font-family:monospace;font-size:11px;"
                             "background:#111;border:1px solid #333;padding:2px 6px;border-radius:3px;")
        for lbl in self._pt_dz_lbl:
            lbl.setText("Z: —")
            lbl.setStyleSheet("color:#88aaff;font-family:monospace;font-size:11px;"
                             "background:#0a0a1a;border:1px solid #333;padding:2px 6px;border-radius:3px;")
        self._H_lbl.setText("초기화됨"); self._H_lbl.setStyleSheet("color:#888;font-size:10px;")

    def _clear_extra_floor(self):
        self._extra_floor_pts.clear()
        self._extra_pts_lbl.setText("추가점: 0개")
        # 추가점 없이 4점만으로 재피팅
        if len(self._floor_pts) >= 3:
            self._fit_floor_plane()

    def _clear_ref(self):
        self._ref_x_sp.setValue(0.0)
        self._ref_y_sp.setValue(0.0)
        self._ref_z_sp.setValue(0.0)

    # ── ROS2 연결 ─────────────────────────────────────────────────────────────
    def _auto_connect(self):
        """시작 시 ROS2 자동 연결 (rclpy 없으면 조용히 무시)."""
        if ROS2_AVAILABLE:
            self._connect()

    def _connect(self):
        if not ROS2_AVAILABLE:
            QtWidgets.QMessageBox.warning(self,"경고","rclpy를 찾을 수 없습니다."); return
        self._disconnect()
        self.ros2_sub = Ros2DepthSub()
        self.ros2_sub.color_rx.connect(self._on_color)
        self.ros2_sub.depth_rx.connect(self._on_depth)
        self.ros2_sub.start()
        self._conn_btn.setEnabled(False); self._disc_btn.setEnabled(True)
        self._conn_lbl.setText("연결됨  ✅"); self._conn_lbl.setStyleSheet("color:#88ff88;font-size:10px;")
        self.timer.start(33)
        self._grid_timer.start(self._grid_interval_sp.value())
        self._pub_timer.start(int(self._pub_iv_sp.value() * 1000))

    def _disconnect(self):
        self.timer.stop()
        self._grid_timer.stop()
        self._pub_timer.stop()
        if self.ros2_sub: self.ros2_sub.stop(); self.ros2_sub = None
        with self._clk: self._color_frame = None
        with self._dlk: self._depth_frame = None
        self._conn_btn.setEnabled(True); self._disc_btn.setEnabled(False)
        self._conn_lbl.setText("미연결"); self._conn_lbl.setStyleSheet("color:#888;font-size:10px;")
        self._img.clear(); self._img.setText("연결 해제됨")
        self._pub_tbl.setRowCount(0)
        self._pub_cnt_lbl.setText("대기 중")
        self._pub_cnt_lbl.setStyleSheet("color:#888;font-size:11px;")

    def _on_color(self, frame):
        with self._clk: self._color_frame = frame.copy()
        self._img.set_src(frame.shape[1], frame.shape[0])

    def _on_depth(self, depth):
        with self._dlk: self._depth_frame = depth.copy()

    def _on_conf(self, v):
        self.conf = v/100.0; self._conf_lbl.setText(f"{self.conf:.2f}")

    def _on_resize(self):
        self._img.setMinimumSize(self._dw_sp.value(), self._dh_sp.value())

    # ── 추론 루프 ─────────────────────────────────────────────────────────────
    def _tick(self):
        with self._clk:
            frame = self._color_frame
        if frame is None:
            return

        allowed = self._allowed()
        dets = []
        if self.model and allowed:
            try:
                for d in run_inference(self.model, frame, self.conf, allowed):
                    xyz = self._get_3d(d['cx'], d['cy'])
                    ht  = None
                    if xyz and xyz[2] is not None:
                        ht = self._height_above_floor(d['cx'], d['cy'], xyz[2])
                    rel = self._relative(xyz)
                    dets.append({**d, 'xyz': xyz, 'ht': ht, 'rel': rel})
            except Exception as e:
                print(f"[추론] {e}")
        self._detections = dets
        self._log_cnt_lbl.setText(f"현재 {len(dets)}개 감지 중")

        vis = self._draw_color(frame.copy(), dets)
        dw = max(self._img.width(), 640)
        dh = max(self._img.height(), 480)
        self._img.setPixmap(to_pixmap(vis, dw, dh))

    def _update_grid(self):
        grid_img = self._draw_depth_grid()
        gw, gh = self._grid_lbl.width(), self._grid_lbl.height()
        self._grid_lbl.setPixmap(to_pixmap(grid_img, gw, gh))

    # ── 노드 발행 (클래스명, X, Y) ────────────────────────────────────────────
    def _publish_tick(self):
        from datetime import datetime
        ts = datetime.now().strftime("%H:%M:%S")
        if not (self.ros2_sub and self._H is not None):
            self._pub_tbl.setRowCount(0)
            self._pub_cnt_lbl.setText("미연결 / 호모그래피 미설정")
            self._pub_cnt_lbl.setStyleSheet("color:#888;font-size:11px;")
            return

        ref_x, ref_y = self._ref_offset()
        rows = []
        for d in self._detections:
            xyz = d.get('xyz')
            if not xyz or xyz[0] is None:
                continue
            dx, dy, _dh = self._get_offsets(d['label'])
            X = xyz[0] + ref_x + dx
            Y = xyz[1] + ref_y + dy
            payload = {'class': d['label'],
                       'location': {'x': round(float(X), 3), 'y': round(float(Y), 3)}}
            self.ros2_sub.publish_det(json.dumps(payload))
            rows.append((d['label'], X, Y))

        self._pub_tbl.setRowCount(len(rows))
        for r, (label, X, Y) in enumerate(rows):
            for c, val in enumerate((label, f"{X:.3f}", f"{Y:.3f}")):
                it = QtWidgets.QTableWidgetItem(val)
                it.setFlags(it.flags() & ~Qt.ItemIsEditable)
                self._pub_tbl.setItem(r, c, it)

        if rows:
            self._pub_cnt_lbl.setText(f"[{ts}] {len(rows)}개 전송")
            self._pub_cnt_lbl.setStyleSheet("color:#ffaa88;font-size:11px;font-weight:bold;")
        else:
            self._pub_cnt_lbl.setText(f"[{ts}] 전송 없음 (감지 없음)")
            self._pub_cnt_lbl.setStyleSheet("color:#888;font-size:11px;")

    # ── 컬러 영상 오버레이 ────────────────────────────────────────────────────
    def _draw_color(self, vis, dets):
        col = (0, 255, 160)
        for d in dets:
            if d['type'] == 'obb':
                cv2.polylines(vis, [d['corners']], True, col, 2)
            else:
                cv2.rectangle(vis,(int(d['x1']),int(d['y1'])),
                              (int(d['x2']),int(d['y2'])), col, 2)
            y0 = max(int(d['y1'])-22, 14)
            cv2.putText(vis, f"{d['label']} {d['conf']:.2f}",
                        (int(d['x1']),y0), cv2.FONT_HERSHEY_SIMPLEX, 0.5, col, 1)
            xyz = d['xyz']; ht = d['ht']
            if xyz:
                X,Y,Z = xyz
                line2 = (f"X:{X:.2f} Y:{Y:.2f}"
                         + (f" Z:{Z:.2f}m" if Z is not None else " Z:없음")
                         + (f"  높이:{ht*100:.1f}cm" if ht is not None else ""))
                cv2.putText(vis, line2,(int(d['x1']),y0+16),
                            cv2.FONT_HERSHEY_SIMPLEX,0.4,(180,255,180),1)

        for i,p in enumerate(self._floor_pts):
            bgr=PT_BGR[i]; u,v=p['u'],p['v']
            cv2.circle(vis,(u,v),9,bgr,-1)
            cv2.circle(vis,(u,v),11,(255,255,255),1)
            cv2.putText(vis, f"{PT_NAMES[i]} Z={p['depth_z']:.2f}m",
                        (u+12,v+5),cv2.FONT_HERSHEY_SIMPLEX,0.4,bgr,1)
        n = len(self._floor_pts)
        pts_px = [(p['u'],p['v']) for p in self._floor_pts]
        for j in range(n):
            cv2.line(vis, pts_px[j], pts_px[(j+1)%n], (200,200,60),1)


        if self._H is None:
            cv2.putText(vis,"[호모그래피 미계산]",(10,22),
                        cv2.FONT_HERSHEY_SIMPLEX,0.5,(80,80,255),1)
        # 추가 바닥점 표시
        for p in self._extra_floor_pts:
            cv2.circle(vis,(p['u'],p['v']),6,(80,220,60),-1)
            cv2.circle(vis,(p['u'],p['v']),8,(255,255,255),1)

        hints={"floor":"▶ 바닥면 클릭 (P1→P4, 4점↑리셋)",
               "floor_extra":"▶ 추가 바닥점 클릭 (평면 확장)",
               "ref":"▶ 기준점 클릭"}
        if self._mode in hints:
            cv2.putText(vis,hints[self._mode],(10,vis.shape[0]-10),
                        cv2.FONT_HERSHEY_SIMPLEX,0.55,(0,220,255),2)
        return vis

    # ── 뎁스 그리드 렌더링 ────────────────────────────────────────────────────
    def _draw_depth_grid(self):
        GW, GH = self._grid_lbl.width(), self._grid_lbl.height()
        if GW <= 0 or GH <= 0:
            GW, GH = 580, 480

        with self._clk:
            color = self._color_frame
        with self._dlk:
            depth = self._depth_frame

        # ── base: 컬러 영상 ──────────────────────────────────────────────────
        if color is None:
            base = np.zeros((GH, GW, 3), dtype=np.uint8)
            cv2.putText(base, "컬러 미연결", (GW//4, GH//2),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.8, (100,100,200), 2)
            return base
        base = cv2.resize(color.copy(), (GW, GH), interpolation=cv2.INTER_LINEAR)

        if depth is None:
            cv2.putText(base, "뎁스 미연결", (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.8, (80,200,255), 2)
            return base

        ch_c, cw_c = color.shape[:2]
        dh_d, dw_d = depth.shape

        # ── 바닥 폴리곤: 4점 + 추가점의 볼록껍질 (정규화 좌표) ──────────────
        floor_poly = None
        all_floor = self._floor_pts + self._extra_floor_pts
        if len(all_floor) >= 3:
            pts_norm = np.array(
                [[p['u'] / cw_c, p['v'] / ch_c] for p in all_floor],
                dtype=np.float32)
            hull = cv2.convexHull(pts_norm)  # shape (N,1,2)
            floor_poly = hull

        COLS = self._gcols.value()
        ROWS = self._grows.value()
        cw = GW // COLS
        ch = GH // ROWS
        has_floor = self._floor_abc is not None
        alpha = self._grid_alpha_sp.value() / 100.0
        # 바닥 판별 허용 오차 (cm → m)
        floor_tol_m = self._floor_tol_sp.value() / 100.0
        cam_h = self._cam_h_sp.value()

        # ── 감지된 사물의 그리드 셀 매핑 ────────────────────────────────────
        det_cells = set()
        for det in self._detections:
            cx_n = det['cx'] / cw_c
            cy_n = det['cy'] / ch_c
            dc = int(cx_n * COLS); dr = int(cy_n * ROWS)
            if 0 <= dc < COLS and 0 <= dr < ROWS:
                det_cells.add((dr, dc))

        # ── overlay: 컬러 영상 복사 후 셀별 색상 채움 ────────────────────────
        overlay = base.copy()

        for row in range(ROWS):
            for col in range(COLS):
                u_d = int((col + 0.5) * dw_d / COLS)
                v_d = int((row + 0.5) * dh_d / ROWS)
                # floor_abc는 color 이미지 좌표로 피팅됐으므로 color 좌표로 평가
                u_c = int((col + 0.5) * cw_c / COLS)
                v_c = int((row + 0.5) * ch_c / ROWS)
                gx = col * cw
                gy = row * ch

                actual_z = read_depth_at(depth, u_d, v_d)
                floor_z  = self._floor_depth(u_c, v_c)
                has_det  = (row, col) in det_cells

                # 바닥 판별:
                # 1순위) floor_abc 있으면 뎁스 평면 방정식으로 전체 화면 판별
                # 2순위) floor_abc 없으면 폴리곤 안쪽만
                if has_floor and floor_z is not None and actual_z is not None:
                    tol = max(floor_tol_m, floor_z * 0.04)
                    on_floor = abs(actual_z - floor_z) < tol
                else:
                    u_n = float(col + 0.5) / COLS
                    v_n = float(row + 0.5) / ROWS
                    on_floor = (floor_poly is not None and
                                cv2.pointPolygonTest(
                                    floor_poly, (u_n, v_n), False) >= 0)

                if on_floor and not has_det:
                    # 바닥 영역 + 감지 없음 → 초록
                    label = f"FL {actual_z:.2f}" if actual_z is not None else "FL"
                    cv2.rectangle(overlay,(gx+1,gy+1),(gx+cw-1,gy+ch-1),(10,140,20),-1)
                    cv2.putText(overlay,label,(gx+3,gy+ch//2+4),
                                cv2.FONT_HERSHEY_SIMPLEX,0.32,(150,255,150),1)
                elif actual_z is None:
                    pass  # 뎁스 없음: 컬러 영상 그대로
                elif has_floor and floor_z is not None:
                    height_m = floor_z - actual_z
                    # 원근 보정 실제 높이: cam_h × (floor_z - actual_z) / floor_z
                    real_h = (cam_h * height_m / floor_z) if floor_z > 0.01 else height_m
                    ht_cm  = real_h * 100
                    if height_m < -floor_tol_m:
                        # 바닥보다 더 멀리 있는 픽셀 (벽/배경)
                        cell_col,label,tc = (30,30,55),f"BG",(80,80,120)
                    elif height_m < floor_tol_m:
                        # 바닥 레벨이지만 감지된 사물 있음
                        cell_col,label,tc = (30,100,30),f"FL✦{actual_z:.2f}",(120,255,120)
                    elif real_h < 0.10:
                        t = int(real_h/0.10*200)
                        cell_col,label,tc = (0,80+t,10),f"{ht_cm:.0f}cm",(200,255,200)
                    elif real_h < 0.30:
                        t = int((real_h-0.10)/0.20*255)
                        cell_col,label,tc = (0,255-t,t),f"{ht_cm:.0f}cm",(255,255,200)
                    elif real_h < 0.50:
                        t = int((real_h-0.30)/0.20*200)
                        cell_col,label,tc = (0,50,130+t),f"{ht_cm:.0f}cm",(255,200,150)
                    else:
                        cell_col,label,tc = (20,20,200),f"{ht_cm:.0f}cm",(200,150,255)
                    cv2.rectangle(overlay,(gx+1,gy+1),(gx+cw-1,gy+ch-1),cell_col,-1)
                    cv2.putText(overlay,label,(gx+3,gy+ch//2+4),
                                cv2.FONT_HERSHEY_SIMPLEX,0.32,tc,1)
                    cv2.putText(overlay,f"d{actual_z:.2f}",(gx+3,gy+ch-4),
                                cv2.FONT_HERSHEY_SIMPLEX,0.28,(160,160,180),1)
                else:
                    cv2.putText(overlay,f"{actual_z:.2f}m",(gx+3,gy+ch//2+4),
                                cv2.FONT_HERSHEY_SIMPLEX,0.32,(220,220,220),1)

                cv2.rectangle(overlay,(gx,gy),(gx+cw,gy+ch),(50,55,75),1)

        # ── 블렌딩: 컬러영상*(1-alpha) + 오버레이*alpha ─────────────────────
        img = cv2.addWeighted(base, 1.0 - alpha, overlay, alpha, 0)

        # ── 바닥 폴리곤 테두리 (볼록껍질) + 포인트 마커 ─────────────────────
        if floor_poly is not None and len(floor_poly) >= 3:
            hull_px = np.array(
                [[[int(pt[0][0]*GW), int(pt[0][1]*GH)]] for pt in floor_poly],
                dtype=np.int32)
            cv2.polylines(img, [hull_px], True, (0,255,80), 2)
        for i,p in enumerate(self._floor_pts):
            bgr = PT_BGR[i]
            gx_dot = int(p['u'] / cw_c * GW)
            gy_dot = int(p['v'] / ch_c * GH)
            cv2.circle(img,(gx_dot,gy_dot),7,bgr,-1)
            cv2.circle(img,(gx_dot,gy_dot),9,(255,255,255),1)
            cv2.putText(img,PT_NAMES[i],(gx_dot+10,gy_dot+5),
                        cv2.FONT_HERSHEY_SIMPLEX,0.38,bgr,1)
        for p in self._extra_floor_pts:
            gx_dot = int(p['u'] / cw_c * GW)
            gy_dot = int(p['v'] / ch_c * GH)
            cv2.circle(img,(gx_dot,gy_dot),5,(100,255,80),-1)
            cv2.circle(img,(gx_dot,gy_dot),7,(255,255,255),1)

        # ── 범례 ────────────────────────────────────────────────────────────
        legend_y = GH - 14
        items = [((10,140,20),"바닥"),((0,200,100),"10cm"),
                 ((0,100,200),"30cm"),((20,20,200),"50cm+")]
        lx = 4
        for c,lbl in items:
            cv2.rectangle(img,(lx,legend_y-10),(lx+12,legend_y),c,-1)
            cv2.putText(img,lbl,(lx+14,legend_y),
                        cv2.FONT_HERSHEY_SIMPLEX,0.3,(220,220,220),1)
            lx += 60

        if not has_floor:
            cv2.putText(img,"바닥 4점 설정 후 호모그래피 계산 시 높이 표시",
                        (4,20),cv2.FONT_HERSHEY_SIMPLEX,0.38,(240,240,100),1)
        return img

    def _toggle_log_auto(self, checked):
        if checked:
            self._log_auto_btn.setText("⏹ 자동 중지")
            self._log_timer.start(self._log_iv_sp.value() * 1000)
        else:
            self._log_auto_btn.setText("▶ 자동 시작")
            self._log_timer.stop()

    # ── 결과 로그 ─────────────────────────────────────────────────────────────
    def _log_tick(self):
        from datetime import datetime
        dets = self._detections
        if not dets:
            return
        ts = datetime.now().strftime("%H:%M:%S")
        entry = {
            'ts': ts,
            'items': [
                {'label': d['label'], 'conf': d['conf'],
                 'cx': d['cx'],  'cy': d['cy'],
                 'z': d['xyz'][2] if d['xyz'] else None}
                for d in dets
            ]
        }
        self._log_store.append(entry)
        self._append_log_entry(entry)
        if dets:
            self._update_corr_table(entry)

    def _append_log_entry(self, entry):
        """현재 보정값(_H, _floor_abc, cam_h)으로 항목 1개 렌더링."""
        RED = "#ff3333"; LABEL = "#ffdd88"; GRAY = "#888888"; FS = "33pt"
        parts = [f"<span style='color:{GRAY};font-size:18pt'>[{entry['ts']}]</span>"]
        if not entry['items']:
            parts.append(f"&nbsp;<span style='color:#444;font-size:22pt'>감지 없음</span><br>")
            parts.append("<hr style='border:0;border-top:1px solid #1a1a2a;margin:2px 0'>")
            self._log_txt.append("".join(parts))
            self._log_txt.verticalScrollBar().setValue(
                self._log_txt.verticalScrollBar().maximum())
            return
        parts.append("<br>")
        # 기준점 (P1 월드좌표 + 오프셋 스핀박스)
        ref_x, ref_y = self._ref_offset()
        for item in entry['items']:
            cx, cy, z = item['cx'], item['cy'], item['z']
            xyz = self._get_3d(cx, cy, z_override=z)
            ht  = self._height_above_floor(cx, cy, z) if z is not None else None
            dx, dy, dh = self._get_offsets(item['label'])
            Xv = (xyz[0] + ref_x + dx) if xyz and xyz[0] is not None else None
            Yv = (xyz[1] + ref_y + dy) if xyz and xyz[1] is not None else None
            Hv = (ht + dh)             if ht  is not None               else None
            X  = f"{Xv:.3f}" if Xv is not None else "—"
            Y  = f"{Yv:.3f}" if Yv is not None else "—"
            Hm = f"{Hv:.3f}" if Hv is not None else "—"
            parts.append(
                f"<span style='color:{LABEL};font-size:{FS};font-weight:bold'>"
                f"{item['label']}</span>"
                f"&nbsp;&nbsp;"
                f"<span style='color:{GRAY};font-size:{FS}'>X:</span>"
                f"<span style='color:{RED};font-size:{FS};font-weight:bold'> {X}m</span>"
                f"&nbsp;&nbsp;"
                f"<span style='color:{GRAY};font-size:{FS}'>Y:</span>"
                f"<span style='color:{RED};font-size:{FS};font-weight:bold'> {Y}m</span>"
                f"&nbsp;&nbsp;"
                f"<span style='color:{GRAY};font-size:{FS}'>높이:</span>"
                f"<span style='color:{RED};font-size:{FS};font-weight:bold'> {Hm}m</span>"
                f"<br>"
            )
        parts.append("<hr style='border:0;border-top:1px solid #2a2a3a;margin:2px 0'>")
        self._log_txt.append("".join(parts))
        sb = self._log_txt.verticalScrollBar()
        sb.setValue(sb.maximum())

    def _on_corr_tbl_changed(self, item):
        """오프셋 셀 변경 시 _saved_corr_offsets 갱신 후 설정 저장."""
        if item.column() == 0:
            return
        r = item.row()
        lbl_it = self._corr_tbl.item(r, 0)
        if lbl_it:
            def _val(col):
                it = self._corr_tbl.item(r, col)
                if it and it.text().strip():
                    try: return float(it.text())
                    except ValueError: pass
                return 0.0
            self._saved_corr_offsets[lbl_it.text()] = [_val(1), _val(2), _val(3)]
        self._save_settings()

    def _get_offsets(self, label):
        """클래스명에 해당하는 (dx, dy, dh) 오프셋 반환. 없으면 (0,0,0)."""
        for r in range(self._corr_tbl.rowCount()):
            lbl_it = self._corr_tbl.item(r, 0)
            if lbl_it and lbl_it.text() == label:
                def _val(col):
                    it = self._corr_tbl.item(r, col)
                    if it and it.text().strip():
                        try: return float(it.text())
                        except ValueError: pass
                    return 0.0
                return _val(1), _val(2), _val(3)
        saved = self._saved_corr_offsets.get(label)
        if saved:
            return float(saved[0]), float(saved[1]), float(saved[2])
        return 0.0, 0.0, 0.0

    def _update_corr_table(self, entry):
        """감지된 클래스 목록 갱신 — 기존 오프셋값 유지, 새 클래스는 0.0으로 추가."""
        items = entry['items']
        prev_offsets = {}
        for r in range(self._corr_tbl.rowCount()):
            lbl_it = self._corr_tbl.item(r, 0)
            if lbl_it:
                prev_offsets[lbl_it.text()] = (
                    self._corr_tbl.item(r, 1),
                    self._corr_tbl.item(r, 2),
                    self._corr_tbl.item(r, 3),
                )

        labels_seen = []
        for item in items:
            if item['label'] not in labels_seen:
                labels_seen.append(item['label'])

        self._corr_tbl.setRowCount(len(labels_seen))

        def _ro(txt):
            it = QtWidgets.QTableWidgetItem(txt)
            it.setForeground(QtGui.QColor("#aaccff"))
            it.setFlags(it.flags() & ~Qt.ItemIsEditable)
            return it

        for r, label in enumerate(labels_seen):
            self._corr_tbl.setItem(r, 0, _ro(label))
            prev = prev_offsets.get(label, (None, None, None))
            saved = self._saved_corr_offsets.get(label, [0.0, 0.0, 0.0])
            for col_idx, (prev_it, saved_val) in enumerate(zip(prev, saved), start=1):
                if prev_it and prev_it.text().strip():
                    val_str = prev_it.text()
                elif saved_val != 0.0:
                    val_str = str(saved_val)
                else:
                    val_str = "0.0"
                new_it = QtWidgets.QTableWidgetItem(val_str)
                new_it.setForeground(QtGui.QColor("#ffee88"))
                self._corr_tbl.setItem(r, col_idx, new_it)

    def _recompute_log(self):
        """저장된 로그 전체를 현재 오프셋/보정값으로 재렌더링."""
        if not self._log_store:
            return
        self._log_txt.clear()
        for entry in self._log_store:
            self._append_log_entry(entry)

    def _clear_log(self):
        self._log_store.clear()
        self._log_txt.clear()

    # ── 설정 저장/복원 ──────────────────────────────────────────────────────────
    def _save_settings(self):
        try:
            s = {
                'model':           self._mdl_combo.currentText(),
                'conf':            self._conf_sl.value(),
                'disp_w':          self._dw_sp.value(),
                'disp_h':          self._dh_sp.value(),
                'gcols':           self._gcols.value(),
                'grows':           self._grows.value(),
                'grid_interval':   self._grid_interval_sp.value(),
                'grid_alpha':      self._grid_alpha_sp.value(),
                'cam_h':           self._cam_h_sp.value(),
                'floor_tol':       self._floor_tol_sp.value(),
                'log_interval':    self._log_iv_sp.value(),
                'pub_interval':    self._pub_iv_sp.value(),
                'floor_pts':       [{'u': p['u'], 'v': p['v'], 'depth_z': p['depth_z']}
                                    for p in self._floor_pts],
                'extra_floor_pts': [{'u': p['u'], 'v': p['v'], 'depth_z': p['depth_z']}
                                    for p in self._extra_floor_pts],
                'pt_wx':           [self._pt_wx_sp[i].value() for i in range(4)],
                'pt_wy':           [self._pt_wy_sp[i].value() for i in range(4)],
                'ref_x':           self._ref_x_sp.value(),
                'ref_y':           self._ref_y_sp.value(),
                'ref_z':           self._ref_z_sp.value(),
                'H':               self._H.tolist() if self._H is not None else None,
                'floor_abc':       list(self._floor_abc) if self._floor_abc else None,
                'classes':         {k: cb.isChecked() for k, cb in self._class_checks.items()},
                'corr_offsets':    self._saved_corr_offsets,
            }
            SETTINGS_FILE.write_text(json.dumps(s, ensure_ascii=False, indent=2))
        except Exception as e:
            print(f"[설정 저장 오류] {e}")

    def _load_settings(self):
        if not SETTINGS_FILE.exists():
            return
        try:
            s = json.loads(SETTINGS_FILE.read_text())
            # 단순 위젯
            model = s.get('model', '')
            for i in range(self._mdl_combo.count()):
                if self._mdl_combo.itemText(i) == model:
                    self._mdl_combo.setCurrentIndex(i); break
            self._conf_sl.setValue(int(s.get('conf', 40)))
            self._dw_sp.setValue(s.get('disp_w', 640))
            self._dh_sp.setValue(s.get('disp_h', 480))
            self._gcols.setValue(s.get('gcols', 10))
            self._grows.setValue(s.get('grows', 7))
            self._grid_interval_sp.setValue(s.get('grid_interval', 200))
            self._grid_alpha_sp.setValue(s.get('grid_alpha', 55))
            self._cam_h_sp.setValue(s.get('cam_h', 0.50))
            self._floor_tol_sp.setValue(s.get('floor_tol', 6))
            self._log_iv_sp.setValue(s.get('log_interval', 3))
            self._pub_iv_sp.setValue(s.get('pub_interval', 0.5))
            # 월드 XY 스핀박스
            pt_wx = s.get('pt_wx', [0.0]*4)
            pt_wy = s.get('pt_wy', [0.0]*4)
            for i in range(4):
                if i < len(pt_wx): self._pt_wx_sp[i].setValue(float(pt_wx[i]))
                if i < len(pt_wy): self._pt_wy_sp[i].setValue(float(pt_wy[i]))
            # 바닥 4점 복원
            fps = s.get('floor_pts', [])
            self._floor_pts = [{'u': p['u'], 'v': p['v'], 'depth_z': p['depth_z']} for p in fps]
            for i, p in enumerate(self._floor_pts):
                bgr = PT_BGR[i]
                self._pt_px_lbl[i].setText(f"u={p['u']},  v={p['v']}")
                self._pt_px_lbl[i].setStyleSheet(
                    f"color:rgb({bgr[2]},{bgr[1]},{bgr[0]});font-family:monospace;"
                    "font-size:11px;font-weight:bold;background:#111;border:1px solid #555;"
                    "padding:2px 6px;border-radius:3px;")
                self._pt_dz_lbl[i].setText(f"Z: {p['depth_z']:.3f}m")
                self._pt_dz_lbl[i].setStyleSheet(
                    "color:#aaddff;font-family:monospace;font-size:11px;font-weight:bold;"
                    "background:#0a0a1a;border:1px solid #4466aa;padding:2px 6px;border-radius:3px;")
            # 추가 바닥점
            efps = s.get('extra_floor_pts', [])
            self._extra_floor_pts = [{'u': p['u'], 'v': p['v'], 'depth_z': p['depth_z']} for p in efps]
            if self._extra_floor_pts:
                self._extra_pts_lbl.setText(f"추가점: {len(self._extra_floor_pts)}개")
            # 호모그래피 행렬
            H = s.get('H', None)
            if H is not None:
                import numpy as np
                self._H = np.array(H, dtype=np.float64)
                self._H_lbl.setText("✅ 저장된 호모그래피 복원됨")
                self._H_lbl.setStyleSheet("color:#88ff88;font-size:10px;font-weight:bold;")
            # 바닥 평면 계수
            fa = s.get('floor_abc', None)
            if fa is not None:
                self._floor_abc = tuple(fa)
                self._sync_abc_ui()
            # 기준점 (스핀박스 값)
            self._ref_x_sp.setValue(s.get('ref_x', 0.0))
            self._ref_y_sp.setValue(s.get('ref_y', 0.0))
            self._ref_z_sp.setValue(s.get('ref_z', 0.0))
            # 클래스 체크 상태 (모델 로드 후 적용)
            self._saved_class_checks = s.get('classes', {})
            # 오프셋 복원
            self._saved_corr_offsets = s.get('corr_offsets', {})
        except Exception as e:
            print(f"[설정 로드 오류] {e}")

    # ── 모델 관리 ─────────────────────────────────────────────────────────────
    def _refresh_models(self):
        files = list_pt_files()
        self._mdl_combo.clear(); self._mdl_combo.addItems(files)

    def _load_model(self):
        rel = self._mdl_combo.currentText()
        if not rel: return
        self.sig_mdl_st.emit("로드 중...","#888888")
        threading.Thread(target=self._do_load, args=(rel,), daemon=True).start()

    def _do_load(self, rel):
        from ultralytics import YOLO
        try:
            m = YOLO(str(WEIGHTS_DIR/rel))
            names = list(m.names.values())
            self.model = m
            self.sig_classes.emit(names)
            self.sig_mdl_st.emit(f"✅ {rel}  ({len(names)}cls)","#aaaaff")
        except Exception as e:
            self.sig_error.emit(str(e))

    def closeEvent(self, ev):
        self._save_settings()
        self._disconnect(); ev.accept()


if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    app.setStyle('Fusion')
    _pal = QtGui.QPalette()
    _pal.setColor(QtGui.QPalette.Window,          QtGui.QColor(10, 10, 15))
    _pal.setColor(QtGui.QPalette.WindowText,      QtGui.QColor(220, 220, 220))
    _pal.setColor(QtGui.QPalette.Base,            QtGui.QColor(8, 8, 12))
    _pal.setColor(QtGui.QPalette.AlternateBase,   QtGui.QColor(18, 18, 26))
    _pal.setColor(QtGui.QPalette.Button,          QtGui.QColor(28, 28, 42))
    _pal.setColor(QtGui.QPalette.ButtonText,      QtGui.QColor(220, 220, 220))
    _pal.setColor(QtGui.QPalette.Text,            QtGui.QColor(220, 220, 220))
    _pal.setColor(QtGui.QPalette.Highlight,       QtGui.QColor(60, 100, 200))
    _pal.setColor(QtGui.QPalette.HighlightedText, QtGui.QColor(255, 255, 255))
    _pal.setColor(QtGui.QPalette.ToolTipBase,     QtGui.QColor(20, 20, 30))
    _pal.setColor(QtGui.QPalette.ToolTipText,     QtGui.QColor(220, 220, 220))
    app.setPalette(_pal)
    win = InferenceDepthUI()
    win.showMaximized()
    sys.exit(app.exec_())
