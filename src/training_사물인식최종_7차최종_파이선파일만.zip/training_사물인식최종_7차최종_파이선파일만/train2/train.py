"""train.py — YOLO Detection 학습 매니저 (GUI) + 데이터 증강"""
import sys
import os
import time
import shutil
import random
import yaml
import cv2
import numpy as np
os.environ['QT_QPA_PLATFORM_PLUGIN_PATH'] = '/usr/lib/x86_64-linux-gnu/qt5/plugins'
os.environ['QT_QPA_PLATFORM'] = 'wayland'

import torch
from pathlib import Path
from threading import Thread

from PyQt5 import QtWidgets, QtCore
from PyQt5.QtCore import pyqtSignal
from ultralytics import YOLO

DEFAULT_DATA  = "/home/han3/turtlebot4_ws/src/training/data/data.yaml"
DEFAULT_IMGSZ = 704
WEIGHTS_DIR   = Path("/home/han3/turtlebot4_ws/src/training/weights")
AUG_DIR       = Path("/home/han3/turtlebot4_ws/src/training/data/yolo_dataset")


class TrainManager(QtWidgets.QWidget):
    sig_log   = pyqtSignal(str)
    sig_epoch = pyqtSignal(int, int, float, float, float)
    sig_done  = pyqtSignal(bool, str)

    def __init__(self):
        super().__init__()
        self._train_start = 0.0
        self._init_ui()
        self.sig_log.connect(self.log)
        self.sig_epoch.connect(self._on_epoch)
        self.sig_done.connect(self._on_done)

    # ── UI ────────────────────────────────────────────────────────────────────
    def _init_ui(self):
        self.setWindowTitle("YOLO Detection 학습 매니저")
        self.setMinimumSize(680, 920)
        layout = QtWidgets.QVBoxLayout(self)

        # 1. 데이터 설정
        data_grp = QtWidgets.QGroupBox("1. 원본 데이터")
        data_lay = QtWidgets.QFormLayout()
        data_row = QtWidgets.QHBoxLayout()
        self.data_edit = QtWidgets.QLineEdit(DEFAULT_DATA)
        browse_btn = QtWidgets.QPushButton("찾기")
        browse_btn.setFixedWidth(50)
        browse_btn.clicked.connect(self._browse_data)
        data_row.addWidget(self.data_edit)
        data_row.addWidget(browse_btn)
        data_lay.addRow("data.yaml:", data_row)
        data_grp.setLayout(data_lay)
        layout.addWidget(data_grp)

        # 2. 데이터 증강
        aug_grp = QtWidgets.QGroupBox("2. 데이터 증강 (Augmentation)")
        aug_grp.setStyleSheet("QGroupBox{font-weight:bold;}")
        aug_main = QtWidgets.QVBoxLayout(aug_grp)

        # 증강 활성화 체크
        self.aug_chk = QtWidgets.QCheckBox(
            "증강 활성화  →  data/yolo_dataset/ 에 생성 후 해당 데이터로 학습")
        self.aug_chk.setChecked(True)
        self.aug_chk.setStyleSheet("color:#88ffcc;font-weight:bold;")
        self.aug_chk.toggled.connect(self._on_aug_toggle)
        aug_main.addWidget(self.aug_chk)

        # 증강 항목 체크박스
        aug_grid = QtWidgets.QGridLayout()
        self.chk_flip   = QtWidgets.QCheckBox("좌우 반전  (cx = 1-cx)")
        self.chk_bright = QtWidgets.QCheckBox("밝기 변화  (±40)")
        self.chk_blur   = QtWidgets.QCheckBox("Gaussian Blur  (5×5)")
        self.chk_noise  = QtWidgets.QCheckBox("노이즈 추가  (±20)")
        self.chk_flip.setChecked(True)
        self.chk_bright.setChecked(True)
        self.chk_blur.setChecked(True)
        self.chk_noise.setChecked(False)
        for chk in (self.chk_flip, self.chk_bright, self.chk_blur, self.chk_noise):
            chk.stateChanged.connect(self._update_aug_preview)
        aug_grid.addWidget(self.chk_flip,   0, 0)
        aug_grid.addWidget(self.chk_bright, 0, 1)
        aug_grid.addWidget(self.chk_blur,   1, 0)
        aug_grid.addWidget(self.chk_noise,  1, 1)
        aug_main.addLayout(aug_grid)

        # 증강 예상 정보
        self.aug_info_lbl = QtWidgets.QLabel("")
        self.aug_info_lbl.setStyleSheet(
            "color:#aaa;font-size:10px;background:#111;padding:3px;")
        aug_main.addWidget(self.aug_info_lbl)
        layout.addWidget(aug_grp)
        self._aug_items = [self.chk_flip, self.chk_bright, self.chk_blur, self.chk_noise]
        self._update_aug_preview()

        # 3. 모델 설정
        model_grp = QtWidgets.QGroupBox("3. 모델 설정")
        model_lay = QtWidgets.QFormLayout()
        self.model_combo = QtWidgets.QComboBox()
        self.model_combo.addItems([
            "yolov8n.pt", "yolov8s.pt",
            "yolo11n.pt", "yolo11s.pt",
            "yolo12n.pt", "yolo12s.pt",
            "yolo26n.pt",
        ])
        model_lay.addRow("Base Model:", self.model_combo)
        self.imgsz_sp = QtWidgets.QSpinBox()
        self.imgsz_sp.setRange(32, 1280)
        self.imgsz_sp.setSingleStep(32)
        self.imgsz_sp.setValue(DEFAULT_IMGSZ)
        model_lay.addRow("Image Size (imgsz):", self.imgsz_sp)
        model_grp.setLayout(model_lay)
        layout.addWidget(model_grp)

        # 4. 학습 설정
        trn_grp = QtWidgets.QGroupBox("4. 학습 설정")
        t_lay   = QtWidgets.QFormLayout()
        dev_row = QtWidgets.QHBoxLayout()
        self.radio_gpu = QtWidgets.QRadioButton("GPU (NVIDIA CUDA)")
        self.radio_cpu = QtWidgets.QRadioButton("CPU")
        if torch.cuda.is_available():
            self.radio_gpu.setText(f"GPU: {torch.cuda.get_device_name(0)}")
            self.radio_gpu.setChecked(True)
        else:
            self.radio_gpu.setEnabled(False)
            self.radio_cpu.setChecked(True)
        dev_row.addWidget(self.radio_gpu)
        dev_row.addWidget(self.radio_cpu)
        self.epoch_sp = QtWidgets.QSpinBox()
        self.epoch_sp.setRange(1, 1000)
        self.epoch_sp.setValue(100)
        self.batch_sp = QtWidgets.QSpinBox()
        self.batch_sp.setRange(1, 128)
        self.batch_sp.setValue(16)
        self.name_edit = QtWidgets.QLineEdit("detection_v1")

        # Early Stopping
        es_row = QtWidgets.QHBoxLayout()
        self.es_chk = QtWidgets.QCheckBox("Early Stopping")
        self.es_chk.setChecked(True)
        self.es_chk.setStyleSheet("color:#ffdd88;font-weight:bold;")
        self.es_chk.toggled.connect(self._on_es_toggle)
        es_row.addWidget(self.es_chk)
        es_row.addWidget(QtWidgets.QLabel("patience:"))
        self.patience_sp = QtWidgets.QSpinBox()
        self.patience_sp.setRange(1, 500)
        self.patience_sp.setValue(20)
        self.patience_sp.setFixedWidth(60)
        self.patience_sp.setToolTip("개선 없이 몇 에폭 지나면 조기 종료")
        es_row.addWidget(self.patience_sp)
        es_row.addWidget(QtWidgets.QLabel("에폭"))
        es_row.addStretch()

        t_lay.addRow("연산 장치:", dev_row)
        t_lay.addRow("Epochs:", self.epoch_sp)
        t_lay.addRow("Batch Size:", self.batch_sp)
        t_lay.addRow("실험 이름:", self.name_edit)
        t_lay.addRow("", es_row)
        trn_grp.setLayout(t_lay)
        layout.addWidget(trn_grp)

        # 5. 진행률
        prog_grp = QtWidgets.QGroupBox("5. 학습 진행률")
        prog_lay = QtWidgets.QVBoxLayout()
        self.progress_bar = QtWidgets.QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setFixedHeight(26)
        self.progress_bar.setFormat("%v / %m  epoch  (%p%)")
        self.progress_bar.setStyleSheet(self._bar_css("#1565C0"))
        prog_lay.addWidget(self.progress_bar)
        metric_row = QtWidgets.QHBoxLayout()
        self.epoch_lbl = QtWidgets.QLabel("Epoch: -")
        self.loss_lbl  = QtWidgets.QLabel("Loss: -")
        self.map50_lbl = QtWidgets.QLabel("mAP50: -")
        self.map95_lbl = QtWidgets.QLabel("mAP50-95: -")
        self.eta_lbl   = QtWidgets.QLabel("ETA: -")
        for lbl in (self.epoch_lbl, self.loss_lbl, self.map50_lbl,
                    self.map95_lbl, self.eta_lbl):
            lbl.setStyleSheet(
                "color:#88ddff;background:#111;padding:3px 6px;"
                "border:1px solid #333;border-radius:3px;font-size:11px;")
            metric_row.addWidget(lbl)
        prog_lay.addLayout(metric_row)
        prog_grp.setLayout(prog_lay)
        layout.addWidget(prog_grp)

        # 6. 로그
        self.log_area = QtWidgets.QTextEdit()
        self.log_area.setReadOnly(True)
        self.log_area.setStyleSheet(
            "background:#1e1e1e;color:#d4d4d4;"
            "font-family:'Consolas',monospace;font-size:10pt;")
        layout.addWidget(self.log_area)

        # 7. 버튼
        self.train_btn = QtWidgets.QPushButton("학습 시작")
        self.train_btn.setFixedHeight(44)
        self.train_btn.setStyleSheet(
            "QPushButton{background:#2E7D32;color:white;"
            "font-size:14px;font-weight:bold;border-radius:5px;}"
            "QPushButton:hover{background:#388E3C;}"
            "QPushButton:disabled{background:#555;color:#999;}")
        self.train_btn.clicked.connect(self.start_training)
        layout.addWidget(self.train_btn)

    def _bar_css(self, color: str) -> str:
        return f"""
            QProgressBar {{
                border:2px solid #444;border-radius:5px;
                background:#1a1a1a;color:white;
                font-weight:bold;text-align:center;
            }}
            QProgressBar::chunk {{background:{color};border-radius:3px;}}
        """

    # ── 증강 미리보기 ─────────────────────────────────────────────────────────
    def _update_aug_preview(self):
        if not self.aug_chk.isChecked():
            self.aug_info_lbl.setText("증강 비활성 — 원본 data.yaml 그대로 학습")
            return
        n = sum(c.isChecked() for c in self._aug_items)
        self.aug_info_lbl.setText(
            f"선택된 증강 {n}종  →  원본 1장당 최대 {n+1}장 생성\n"
            f"저장: {AUG_DIR}/images/  +  {AUG_DIR}/labels/\n"
            f"학습 data.yaml: {AUG_DIR}/data.yaml")

    def _on_aug_toggle(self, checked: bool):
        for chk in self._aug_items:
            chk.setEnabled(checked)
        self._update_aug_preview()

    def _on_es_toggle(self, checked: bool):
        self.patience_sp.setEnabled(checked)

    def _browse_data(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self, "data.yaml 선택", "", "YAML Files (*.yaml *.yml)")
        if path:
            self.data_edit.setText(path)

    # ── 로그 ─────────────────────────────────────────────────────────────────
    def log(self, text: str):
        self.log_area.append(text)
        self.log_area.verticalScrollBar().setValue(
            self.log_area.verticalScrollBar().maximum())

    # ── 진행률 시그널 핸들러 ──────────────────────────────────────────────────
    def _on_epoch(self, cur: int, total: int, loss: float, map50: float, map95: float):
        self.progress_bar.setMaximum(total)
        self.progress_bar.setValue(cur)
        self.epoch_lbl.setText(f"Epoch: {cur}/{total}")
        self.loss_lbl.setText(f"Loss: {loss:.4f}" if loss > 0 else "Loss: -")
        self.map50_lbl.setText(f"mAP50: {map50:.3f}" if map50 > 0 else "mAP50: -")
        self.map95_lbl.setText(f"mAP50-95: {map95:.3f}" if map95 > 0 else "mAP50-95: -")
        if cur > 0 and self._train_start > 0:
            elapsed   = time.time() - self._train_start
            remaining = elapsed / cur * (total - cur)
            h, m, s   = int(remaining//3600), int((remaining%3600)//60), int(remaining%60)
            self.eta_lbl.setText(f"ETA: {h:02d}:{m:02d}:{s:02d}")
        color = "#00C853" if map50 >= 0.8 else ("#FFD600" if map50 >= 0.5 else "#1565C0")
        self.progress_bar.setStyleSheet(self._bar_css(color))

    def _on_done(self, success: bool, msg: str):
        self.train_btn.setEnabled(True)
        self.train_btn.setText("학습 시작")
        if success:
            self.progress_bar.setValue(self.progress_bar.maximum())
            self.eta_lbl.setText("ETA: 완료")
            self.log(f"\n✅ {msg}")
        else:
            self.log(f"\n❌ {msg}")

    # ── 데이터 증강 ───────────────────────────────────────────────────────────
    def _prepare_augmented_dataset(self, src_yaml_path: str) -> str:
        """
        원본 data.yaml 을 읽어 이미지+라벨을 AUG_DIR 에 복사·증강.
        새 data.yaml 경로를 반환.
        """
        src_yaml = Path(src_yaml_path)
        with open(src_yaml, "r", encoding="utf-8") as f:
            cfg = yaml.safe_load(f)

        # 원본 이미지 / 라벨 디렉토리 결정
        base     = Path(cfg.get("path", src_yaml.parent))
        img_rel  = cfg.get("train", "images")
        src_imgs = base / img_rel
        src_lbls = base / img_rel.replace("images", "labels")
        if not src_imgs.exists():
            raise FileNotFoundError(f"이미지 폴더 없음: {src_imgs}")

        # AUG_DIR 초기화
        aug_imgs = AUG_DIR / "images"
        aug_lbls = AUG_DIR / "labels"
        if AUG_DIR.exists():
            shutil.rmtree(AUG_DIR)
        aug_imgs.mkdir(parents=True)
        aug_lbls.mkdir(parents=True)

        exts    = {".jpg", ".jpeg", ".png", ".bmp"}
        images  = [p for p in src_imgs.iterdir() if p.suffix.lower() in exts]
        ok = aug = 0

        self.sig_log.emit(f"📂 원본 이미지: {len(images)}장  →  증강 중...")

        for img_path in images:
            lbl_path = src_lbls / (img_path.stem + ".txt")
            if not lbl_path.exists():
                continue

            # 원본 복사
            shutil.copy(img_path, aug_imgs / img_path.name)
            shutil.copy(lbl_path, aug_lbls / (img_path.stem + ".txt"))
            ok += 1

            labels = [l for l in lbl_path.read_text().splitlines() if l.strip()]
            img    = cv2.imread(str(img_path))
            if img is None:
                continue

            # 좌우 반전
            if self.chk_flip.isChecked():
                flipped = cv2.flip(img, 1)
                new_lbl = []
                for line in labels:
                    parts = line.split()
                    if len(parts) == 5:   # Detection: cls cx cy w h
                        cls = parts[0]
                        cx, cy, w, h = map(float, parts[1:])
                        cx = 1.0 - cx
                        new_lbl.append(f"{cls} {cx:.6f} {cy:.6f} {w:.6f} {h:.6f}")
                    else:
                        new_lbl.append(line)
                self._save_aug(img_path.stem + "_flip", flipped, new_lbl, aug_imgs, aug_lbls)
                aug += 1

            # 밝기 변화
            if self.chk_bright.isChecked():
                val    = random.randint(-40, 40)
                bright = np.clip(img.astype(np.int32) + val, 0, 255).astype(np.uint8)
                self._save_aug(img_path.stem + "_brt", bright, labels, aug_imgs, aug_lbls)
                aug += 1

            # Gaussian Blur
            if self.chk_blur.isChecked():
                blurred = cv2.GaussianBlur(img, (5, 5), 0)
                self._save_aug(img_path.stem + "_blur", blurred, labels, aug_imgs, aug_lbls)
                aug += 1

            # 노이즈
            if self.chk_noise.isChecked():
                noise   = np.random.randint(-20, 21, img.shape, dtype=np.int32)
                noisy   = np.clip(img.astype(np.int32) + noise, 0, 255).astype(np.uint8)
                self._save_aug(img_path.stem + "_noise", noisy, labels, aug_imgs, aug_lbls)
                aug += 1

        total_imgs = len(list(aug_imgs.glob("*")))
        self.sig_log.emit(
            f"✅ 증강 완료  원본={ok}장  증강추가={aug}장  합계={total_imgs}장")

        # 새 data.yaml 생성
        new_yaml = {
            "path":  str(AUG_DIR),
            "train": "images",
            "val":   "images",
            "nc":    cfg.get("nc", 0),
            "names": cfg.get("names", {}),
        }
        out_yaml = AUG_DIR / "data.yaml"
        with open(out_yaml, "w", encoding="utf-8") as f:
            yaml.dump(new_yaml, f, allow_unicode=True, sort_keys=False)
        self.sig_log.emit(f"📄 data.yaml 생성: {out_yaml}")
        return str(out_yaml)

    def _save_aug(self, stem: str, img: np.ndarray, labels: list,
                  img_dir: Path, lbl_dir: Path):
        cv2.imwrite(str(img_dir / f"{stem}.jpg"), img)
        (lbl_dir / f"{stem}.txt").write_text("\n".join(labels))

    # ── 학습 시작 ─────────────────────────────────────────────────────────────
    def start_training(self):
        data_path  = self.data_edit.text().strip()
        model_name = self.model_combo.currentText()
        imgsz      = self.imgsz_sp.value()
        epochs     = self.epoch_sp.value()
        batch      = self.batch_sp.value()
        device     = 0 if self.radio_gpu.isChecked() else 'cpu'
        name       = self.name_edit.text().strip() or "detection_v1"
        patience   = self.patience_sp.value() if self.es_chk.isChecked() else 0
        use_aug    = self.aug_chk.isChecked()

        if not Path(data_path).exists():
            QtWidgets.QMessageBox.warning(
                self, "경고", f"data.yaml 파일이 없습니다:\n{data_path}")
            return

        self.log(f"\n{'='*50}")
        self.log(f"  모델: {model_name}  |  imgsz: {imgsz}")
        self.log(f"  epochs: {epochs}  batch: {batch}")
        self.log(f"  장치: {'GPU' if device == 0 else 'CPU'}")
        self.log(f"  Early Stopping: {'patience=' + str(patience) if patience else '비활성화'}")
        self.log(f"  데이터 증강: {'활성화' if use_aug else '비활성화'}")
        self.log(f"{'='*50}")

        self.progress_bar.setMaximum(epochs)
        self.progress_bar.setValue(0)
        self.epoch_lbl.setText("Epoch: -")
        self.loss_lbl.setText("Loss: -")
        self.map50_lbl.setText("mAP50: -")
        self.map95_lbl.setText("mAP50-95: -")
        self.eta_lbl.setText("ETA: -")
        self.train_btn.setEnabled(False)
        self.train_btn.setText("학습 중...")
        self._train_start = 0.0   # 증강 후 재설정

        sig_epoch = self.sig_epoch
        sig_log   = self.sig_log
        sig_done  = self.sig_done

        # 증강 체크박스 상태 캡처 (스레드에서 Qt 위젯 직접 접근 금지)
        do_flip   = self.chk_flip.isChecked()
        do_bright = self.chk_bright.isChecked()
        do_blur   = self.chk_blur.isChecked()
        do_noise  = self.chk_noise.isChecked()

        def _train(patience=patience):
            try:
                train_data = data_path

                # ── 증강 단계 ─────────────────────────────────────────────
                if use_aug:
                    sig_log.emit("\n[1/2] 데이터 증강 준비 중...")
                    train_data = self._prepare_augmented_dataset(data_path)
                    sig_log.emit(f"[1/2] 완료  →  {train_data}")
                    sig_log.emit("\n[2/2] 학습 시작...")
                else:
                    sig_log.emit("\n학습 시작 (증강 없음)...")

                # 학습 타이머 시작 (증강 완료 후)
                import time as _t
                self._train_start = _t.time()

                WEIGHTS_DIR.mkdir(parents=True, exist_ok=True)
                _train2_dir = Path(__file__).parent
                _local = _train2_dir / model_name
                model = YOLO(str(_local) if _local.exists() else model_name)

                def on_epoch_end(trainer):
                    cur   = trainer.epoch + 1
                    total = trainer.epochs
                    loss  = float(trainer.loss.item()) if hasattr(trainer, 'loss') else 0.0
                    m     = trainer.metrics or {}
                    map50 = float(m.get('metrics/mAP50(B)', 0))
                    map95 = float(m.get('metrics/mAP50-95(B)', 0))
                    sig_epoch.emit(cur, total, loss, map50, map95)
                    sig_log.emit(
                        f"  [{cur:>3}/{total}]  loss={loss:.4f}"
                        f"  mAP50={map50:.3f}  mAP50-95={map95:.3f}")

                def on_train_end(trainer):
                    final = trainer.epoch + 1
                    total = trainer.epochs
                    if final < total:
                        sig_log.emit(
                            f"\n⏹ Early Stopping: {final}/{total} 에폭에서 조기 종료")

                model.add_callback('on_train_epoch_end', on_epoch_end)
                model.add_callback('on_train_end', on_train_end)

                model.train(
                    data     = train_data,
                    epochs   = epochs,
                    batch    = batch,
                    imgsz    = imgsz,
                    device   = device,
                    patience = patience,
                    project  = str(WEIGHTS_DIR),
                    name     = name,
                    exist_ok = True,
                    verbose  = False,
                )
                best = WEIGHTS_DIR / name / "weights" / "best.pt"
                sig_done.emit(True, f"학습 완료!\n   best.pt: {best}")
            except Exception as e:
                sig_done.emit(False, f"오류: {e}")

        Thread(target=_train, daemon=True).start()


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    ex  = TrainManager()
    ex.show()
    sys.exit(app.exec_())
