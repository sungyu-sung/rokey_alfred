"""train.py — YOLO Detection 학습 매니저 (GUI)"""
import sys
import os
import time
os.environ['QT_QPA_PLATFORM_PLUGIN_PATH'] = '/usr/lib/x86_64-linux-gnu/qt5/plugins'
os.environ['QT_QPA_PLATFORM'] = 'wayland'

import torch
from pathlib import Path
from threading import Thread

from PyQt5 import QtWidgets, QtCore
from PyQt5.QtCore import pyqtSignal
from ultralytics import YOLO

DEFAULT_DATA  = "/home/han3/turtlebot4_ws/src/training/data/data.yaml"
DEFAULT_IMGSZ = 704
WEIGHTS_DIR   = Path("/home/han3/turtlebot4_ws/src/training/weights")


class TrainManager(QtWidgets.QWidget):
    # 스레드 → UI 안전 통신용 시그널
    sig_log       = pyqtSignal(str)
    sig_epoch     = pyqtSignal(int, int, float, float, float)  # cur, total, loss, map50, map50_95
    sig_done      = pyqtSignal(bool, str)                       # success, message

    def __init__(self):
        super().__init__()
        self.base_dir    = Path(__file__).parent
        self._train_start = 0.0
        self._init_ui()
        self.sig_log.connect(self.log)
        self.sig_epoch.connect(self._on_epoch)
        self.sig_done.connect(self._on_done)

    def _init_ui(self):
        self.setWindowTitle("YOLO Detection 학습 매니저")
        self.setFixedSize(660, 780)
        layout = QtWidgets.QVBoxLayout(self)

        # 1. 데이터 설정
        data_grp = QtWidgets.QGroupBox("1. 데이터 설정")
        data_lay = QtWidgets.QFormLayout()
        data_row = QtWidgets.QHBoxLayout()
        self.data_edit = QtWidgets.QLineEdit(DEFAULT_DATA)
        browse_btn = QtWidgets.QPushButton("찾기")
        browse_btn.setFixedWidth(50)
        browse_btn.clicked.connect(self._browse_data)
        data_row.addWidget(self.data_edit)
        data_row.addWidget(browse_btn)
        data_lay.addRow("data.yaml:", data_row)
        data_grp.setLayout(data_lay)
        layout.addWidget(data_grp)

        # 2. 모델 설정
        model_grp = QtWidgets.QGroupBox("2. 모델 설정")
        model_lay = QtWidgets.QFormLayout()
        self.model_combo = QtWidgets.QComboBox()
        self.model_combo.addItems(["yolov8n.pt", "yolov8s.pt", "yolo11n.pt", "yolo11s.pt"])
        model_lay.addRow("Base Model:", self.model_combo)
        self.imgsz_sp = QtWidgets.QSpinBox()
        self.imgsz_sp.setRange(32, 1280)
        self.imgsz_sp.setSingleStep(32)
        self.imgsz_sp.setValue(DEFAULT_IMGSZ)
        model_lay.addRow("Image Size (imgsz):", self.imgsz_sp)
        model_grp.setLayout(model_lay)
        layout.addWidget(model_grp)

        # 3. 학습 설정
        trn_grp = QtWidgets.QGroupBox("3. 학습 설정")
        t_lay   = QtWidgets.QFormLayout()
        dev_row = QtWidgets.QHBoxLayout()
        self.radio_gpu = QtWidgets.QRadioButton("GPU (NVIDIA CUDA)")
        self.radio_cpu = QtWidgets.QRadioButton("CPU")
        if torch.cuda.is_available():
            self.radio_gpu.setText(f"GPU: {torch.cuda.get_device_name(0)}")
            self.radio_gpu.setChecked(True)
        else:
            self.radio_gpu.setEnabled(False)
            self.radio_cpu.setChecked(True)
        dev_row.addWidget(self.radio_gpu)
        dev_row.addWidget(self.radio_cpu)
        self.epoch_sp = QtWidgets.QSpinBox()
        self.epoch_sp.setRange(1, 1000)
        self.epoch_sp.setValue(100)
        self.batch_sp = QtWidgets.QSpinBox()
        self.batch_sp.setRange(1, 128)
        self.batch_sp.setValue(16)
        self.name_edit = QtWidgets.QLineEdit("detection_v1")
        # Early Stopping
        es_row = QtWidgets.QHBoxLayout()
        self.es_chk = QtWidgets.QCheckBox("Early Stopping 활성화")
        self.es_chk.setChecked(True)
        self.es_chk.setStyleSheet("color:#ffdd88;font-weight:bold;")
        self.es_chk.toggled.connect(self._on_es_toggle)
        es_row.addWidget(self.es_chk)
        es_row.addWidget(QtWidgets.QLabel("patience:"))
        self.patience_sp = QtWidgets.QSpinBox()
        self.patience_sp.setRange(1, 500)
        self.patience_sp.setValue(20)
        self.patience_sp.setFixedWidth(60)
        self.patience_sp.setToolTip("개선 없이 몇 에폭 지나면 조기 종료")
        es_row.addWidget(self.patience_sp)
        es_row.addWidget(QtWidgets.QLabel("에폭"))
        es_row.addStretch()

        t_lay.addRow("연산 장치:", dev_row)
        t_lay.addRow("Epochs:", self.epoch_sp)
        t_lay.addRow("Batch Size:", self.batch_sp)
        t_lay.addRow("실험 이름:", self.name_edit)
        t_lay.addRow("", es_row)
        trn_grp.setLayout(t_lay)
        layout.addWidget(trn_grp)

        # 4. 진행률
        prog_grp = QtWidgets.QGroupBox("4. 학습 진행률")
        prog_lay = QtWidgets.QVBoxLayout()

        self.progress_bar = QtWidgets.QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setFixedHeight(26)
        self.progress_bar.setFormat("%v / %m  epoch  (%p%)")
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                border: 2px solid #444;
                border-radius: 5px;
                background: #1a1a1a;
                color: white;
                font-weight: bold;
                text-align: center;
            }
            QProgressBar::chunk {
                background: qlineargradient(
                    x1:0, y1:0, x2:1, y2:0,
                    stop:0 #1565C0, stop:1 #42A5F5);
                border-radius: 3px;
            }
        """)
        prog_lay.addWidget(self.progress_bar)

        # 메트릭 행
        metric_row = QtWidgets.QHBoxLayout()
        self.epoch_lbl  = QtWidgets.QLabel("Epoch: -")
        self.loss_lbl   = QtWidgets.QLabel("Loss: -")
        self.map50_lbl  = QtWidgets.QLabel("mAP50: -")
        self.map95_lbl  = QtWidgets.QLabel("mAP50-95: -")
        self.eta_lbl    = QtWidgets.QLabel("ETA: -")
        for lbl in (self.epoch_lbl, self.loss_lbl, self.map50_lbl,
                    self.map95_lbl, self.eta_lbl):
            lbl.setStyleSheet(
                "color:#88ddff;background:#111;padding:3px 6px;"
                "border:1px solid #333;border-radius:3px;font-size:11px;")
            metric_row.addWidget(lbl)
        prog_lay.addLayout(metric_row)
        prog_grp.setLayout(prog_lay)
        layout.addWidget(prog_grp)

        # 5. 로그
        self.log_area = QtWidgets.QTextEdit()
        self.log_area.setReadOnly(True)
        self.log_area.setStyleSheet(
            "background:#1e1e1e;color:#d4d4d4;"
            "font-family:'Consolas',monospace;font-size:10pt;")
        layout.addWidget(self.log_area)

        # 6. 버튼
        self.train_btn = QtWidgets.QPushButton("학습 시작")
        self.train_btn.setFixedHeight(44)
        self.train_btn.setStyleSheet(
            "QPushButton{background:#2E7D32;color:white;"
            "font-size:14px;font-weight:bold;border-radius:5px;}"
            "QPushButton:hover{background:#388E3C;}"
            "QPushButton:disabled{background:#555;color:#999;}")
        self.train_btn.clicked.connect(self.start_training)
        layout.addWidget(self.train_btn)

    def log(self, text: str):
        self.log_area.append(text)
        self.log_area.verticalScrollBar().setValue(
            self.log_area.verticalScrollBar().maximum())

    def _on_es_toggle(self, checked: bool):
        self.patience_sp.setEnabled(checked)

    def _browse_data(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self, "data.yaml 선택", "", "YAML Files (*.yaml *.yml)")
        if path:
            self.data_edit.setText(path)

    # ── 시그널 핸들러 ─────────────────────────────────────────────────────────
    def _on_epoch(self, cur: int, total: int, loss: float, map50: float, map95: float):
        self.progress_bar.setMaximum(total)
        self.progress_bar.setValue(cur)

        self.epoch_lbl.setText(f"Epoch: {cur}/{total}")
        self.loss_lbl.setText(f"Loss: {loss:.4f}" if loss > 0 else "Loss: -")
        self.map50_lbl.setText(f"mAP50: {map50:.3f}" if map50 > 0 else "mAP50: -")
        self.map95_lbl.setText(f"mAP50-95: {map95:.3f}" if map95 > 0 else "mAP50-95: -")

        if cur > 0 and self._train_start > 0:
            elapsed  = time.time() - self._train_start
            per_ep   = elapsed / cur
            remaining = per_ep * (total - cur)
            h, m, s = int(remaining//3600), int((remaining%3600)//60), int(remaining%60)
            self.eta_lbl.setText(f"ETA: {h:02d}:{m:02d}:{s:02d}")

        # 색상: mAP 기준
        if map50 >= 0.8:
            chunk_color = "#00C853"   # 초록
        elif map50 >= 0.5:
            chunk_color = "#FFD600"   # 노랑
        else:
            chunk_color = "#1565C0"   # 파랑 (기본)
        self.progress_bar.setStyleSheet(f"""
            QProgressBar {{
                border: 2px solid #444; border-radius: 5px;
                background: #1a1a1a; color: white;
                font-weight: bold; text-align: center;
            }}
            QProgressBar::chunk {{
                background: {chunk_color}; border-radius: 3px;
            }}
        """)

    def _on_done(self, success: bool, msg: str):
        self.train_btn.setEnabled(True)
        self.train_btn.setText("학습 시작")
        if success:
            self.progress_bar.setValue(self.progress_bar.maximum())
            self.eta_lbl.setText("ETA: 완료")
            self.log(f"\n✅ {msg}")
        else:
            self.log(f"\n❌ {msg}")

    # ── 학습 ─────────────────────────────────────────────────────────────────
    def start_training(self):
        data_path  = self.data_edit.text().strip()
        model_name = self.model_combo.currentText()
        imgsz      = self.imgsz_sp.value()
        epochs     = self.epoch_sp.value()
        batch      = self.batch_sp.value()
        device     = 0 if self.radio_gpu.isChecked() else 'cpu'
        name       = self.name_edit.text().strip() or "detection_v1"
        patience   = self.patience_sp.value() if self.es_chk.isChecked() else 0

        if not Path(data_path).exists():
            QtWidgets.QMessageBox.warning(
                self, "경고", f"data.yaml 파일이 없습니다:\n{data_path}")
            return

        self.log(f"\n{'='*50}")
        self.log(f"  모델: {model_name}")
        self.log(f"  데이터: {data_path}")
        self.log(f"  imgsz: {imgsz}  epochs: {epochs}  batch: {batch}")
        self.log(f"  장치: {'GPU' if device == 0 else 'CPU'}")
        if patience > 0:
            self.log(f"  Early Stopping: patience={patience} 에폭")
        else:
            self.log(f"  Early Stopping: 비활성화")
        self.log(f"{'='*50}")

        # 진행바 초기화
        self.progress_bar.setMaximum(epochs)
        self.progress_bar.setValue(0)
        self.progress_bar.setFormat("%v / %m  epoch  (%p%)")
        self.epoch_lbl.setText("Epoch: -")
        self.loss_lbl.setText("Loss: -")
        self.map50_lbl.setText("mAP50: -")
        self.map95_lbl.setText("mAP50-95: -")
        self.eta_lbl.setText("ETA: -")
        self.train_btn.setEnabled(False)
        self.train_btn.setText("학습 중...")
        self._train_start = time.time()

        sig_epoch = self.sig_epoch
        sig_log   = self.sig_log
        sig_done  = self.sig_done

        def _train(patience=patience):
            try:
                WEIGHTS_DIR.mkdir(parents=True, exist_ok=True)
                model = YOLO(model_name)

                # YOLO 에포크 완료 콜백
                def on_epoch_end(trainer):
                    cur    = trainer.epoch + 1
                    total  = trainer.epochs
                    loss   = float(trainer.loss.item()) if hasattr(trainer, 'loss') else 0.0
                    m      = trainer.metrics or {}
                    map50  = float(m.get('metrics/mAP50(B)', 0))
                    map95  = float(m.get('metrics/mAP50-95(B)', 0))
                    sig_epoch.emit(cur, total, loss, map50, map95)
                    sig_log.emit(
                        f"  [{cur:>3}/{total}]  loss={loss:.4f}"
                        f"  mAP50={map50:.3f}  mAP50-95={map95:.3f}")

                model.add_callback('on_train_epoch_end', on_epoch_end)

                def on_train_end(trainer):
                    final = trainer.epoch + 1
                    total = trainer.epochs
                    if final < total:
                        sig_log.emit(
                            f"\n⏹ Early Stopping: {final}/{total} 에폭에서 조기 종료"
                            f"  (patience={patience}, 이후 {patience}에폭 개선 없음)")

                model.add_callback('on_train_end', on_train_end)

                model.train(
                    data     = data_path,
                    epochs   = epochs,
                    batch    = batch,
                    imgsz    = imgsz,
                    device   = device,
                    patience = patience,
                    project  = str(WEIGHTS_DIR),
                    name     = name,
                    exist_ok = True,
                    verbose  = False,
                )
                best = WEIGHTS_DIR / name / "weights" / "best.pt"
                sig_done.emit(True, f"학습 완료!\n   best.pt: {best}")
            except Exception as e:
                sig_done.emit(False, f"학습 오류: {e}")

        Thread(target=_train, daemon=True).start()


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    ex  = TrainManager()
    ex.show()
    sys.exit(app.exec_())
