#!/usr/bin/env python3
"""inference_compare.py — YOLO 두 모델 동시 비교 추론

영상 소스: 웹캠 / 동영상 파일 / ROS2 토픽 (label_image_capture.py 와 동일 구조)
모델 A, B 각각 weights/ 에서 선택 → 같은 프레임에 동시 추론 → 나란히 표시
"""
import os, sys, threading, time, json
os.environ['QT_QPA_PLATFORM_PLUGIN_PATH'] = '/usr/lib/x86_64-linux-gnu/qt5/plugins'
os.environ['QT_QPA_PLATFORM'] = 'wayland'

import cv2
import numpy as np
from pathlib import Path
from threading import Lock

from PyQt5 import QtWidgets, QtCore, QtGui
from PyQt5.QtCore import Qt, pyqtSignal, QThread, QTimer

WEIGHTS_DIR    = Path("/home/han3/turtlebot4_ws/src/training/weights")
SETTINGS_FILE  = Path(__file__).parent / "inference_compare_settings.json"
DISP_W, DISP_H = 540, 400
COL_A = (255, 120,   0)   # BGR 주황
COL_B = (  0, 200, 255)   # BGR 청록

ROS2_TOPIC_PRESETS = [
    "/robot2/oakd/rgb/image_raw/compressed",
    "/robot2/oakd/rgb/image_raw",
    "/robot4/oakd/rgb/image_raw/compressed",
    "/robot4/oakd/rgb/image_raw",
    "/camera/color/image_raw",
]

# ── ROS2 optional ─────────────────────────────────────────────────────────────
try:
    import rclpy
    from rclpy.node import Node
    from sensor_msgs.msg import Image, CompressedImage
    from cv_bridge import CvBridge
    ROS2_AVAILABLE = True
except ImportError:
    ROS2_AVAILABLE = False


# ── ROS2 구독 스레드 (QThread 기반 — QSocketNotifier 경고 방지) ─────────────
class Ros2Subscriber(QThread):
    frame_received = pyqtSignal(object)

    def __init__(self, topic: str):
        super().__init__()
        self.topic         = topic
        self.is_compressed = topic.endswith("/compressed")
        self._stop         = threading.Event()
        self.bridge        = CvBridge()

    def run(self):
        if not rclpy.ok():
            rclpy.init()
        node = rclpy.create_node('inference_compare_sub')
        if self.is_compressed:
            node.create_subscription(CompressedImage, self.topic,
                                     self._cb_compressed, 10)
        else:
            node.create_subscription(Image, self.topic, self._cb_raw, 10)
        while not self._stop.is_set() and rclpy.ok():
            rclpy.spin_once(node, timeout_sec=0.05)
        node.destroy_node()

    def _cb_raw(self, msg):
        try:
            frame = self.bridge.imgmsg_to_cv2(msg, 'bgr8')
            self.frame_received.emit(frame)
        except Exception:
            pass

    def _cb_compressed(self, msg):
        try:
            buf   = np.frombuffer(msg.data, dtype=np.uint8)
            frame = cv2.imdecode(buf, cv2.IMREAD_COLOR)
            if frame is not None:
                self.frame_received.emit(frame)
        except Exception:
            pass

    def stop(self):
        self._stop.set()
        self.wait(2000)


# ── 유틸 ─────────────────────────────────────────────────────────────────────
def list_pt_files() -> list:
    if not WEIGHTS_DIR.exists():
        return []
    return [str(f.relative_to(WEIGHTS_DIR))
            for f in sorted(WEIGHTS_DIR.rglob("*.pt"))]


def run_inference(model, frame, conf, allowed=None):
    """단일 모델 추론 → position_list 반환. allowed=None이면 전체 클래스."""
    results   = model.predict(frame, conf=conf, verbose=False)
    positions = []
    for r in results:
        if r.boxes is not None and len(r.boxes):
            for box in r.boxes:
                label = model.names[int(box.cls[0])]
                if allowed is not None and label not in allowed:
                    continue
                x1, y1, x2, y2 = box.xyxy[0].tolist()
                positions.append({
                    'label': label, 'conf': float(box.conf[0]),
                    'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2, 'type': 'det',
                })
        elif r.obb is not None and len(r.obb):
            for box in r.obb:
                label = model.names[int(box.cls[0])]
                if allowed is not None and label not in allowed:
                    continue
                corners = box.xyxyxyxy[0].cpu().numpy().astype(int)
                x1y1 = corners.min(axis=0); x2y2 = corners.max(axis=0)
                positions.append({
                    'label': label, 'conf': float(box.conf[0]),
                    'x1': x1y1[0], 'y1': x1y1[1], 'x2': x2y2[0], 'y2': x2y2[1],
                    'corners': corners, 'type': 'obb',
                })
    return positions


def draw_boxes(frame: np.ndarray, positions: list, col) -> np.ndarray:
    vis = frame.copy()
    for p in positions:
        if p['type'] == 'obb':
            cv2.polylines(vis, [p['corners']], True, col, 2)
        else:
            cv2.rectangle(vis,
                          (int(p['x1']), int(p['y1'])),
                          (int(p['x2']), int(p['y2'])), col, 2)
        lbl = f"{p['label']} {p['conf']:.2f}"
        cv2.putText(vis, lbl,
                    (int(p['x1']), max(int(p['y1']) - 6, 14)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.55, col, 2)
    return vis


def frame_to_pixmap(frame: np.ndarray, w: int, h: int) -> QtGui.QPixmap:
    rgb  = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    fh, fw, ch = rgb.shape
    qi   = QtGui.QImage(rgb.data, fw, fh, ch * fw, QtGui.QImage.Format_RGB888)
    return QtGui.QPixmap.fromImage(qi).scaled(
        w, h, Qt.KeepAspectRatio, Qt.SmoothTransformation)


# ── 메인 UI ───────────────────────────────────────────────────────────────────
class InferenceCompareUI(QtWidgets.QWidget):
    sig_classes_a = pyqtSignal(list)
    sig_classes_b = pyqtSignal(list)
    sig_status_a  = pyqtSignal(str, str)   # (text, color)
    sig_status_b  = pyqtSignal(str, str)
    sig_error     = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        self.model_a: object = None
        self.model_b: object = None

        self.cap:      object = None
        self.ros2_sub: object = None
        self._cur_frame = None
        self._frame_lock = Lock()
        self._source_open = False

        self._pos_a: list = []
        self._pos_b: list = []

        self.conf_thresh = 0.40
        self.disp_w = 540
        self.disp_h = 400

        self._class_checks_a: dict = {}
        self._class_checks_b: dict = {}
        self._saved_classes_a: dict = {}
        self._saved_classes_b: dict = {}

        self._init_ui()

        self.sig_classes_a.connect(self._rebuild_classes_a)
        self.sig_classes_b.connect(self._rebuild_classes_b)
        self.sig_status_a.connect(lambda t,c: (
            self.status_a.setText(t),
            self.status_a.setStyleSheet(f"color:{c};font-size:10px;")))
        self.sig_status_b.connect(lambda t,c: (
            self.status_b.setText(t),
            self.status_b.setStyleSheet(f"color:{c};font-size:10px;")))
        self.sig_error.connect(lambda m: QtWidgets.QMessageBox.critical(self,"오류",m))

        self._refresh_models()
        self._load_settings()

        self.display_timer = QTimer(self)
        self.display_timer.timeout.connect(self._tick)

    # ── UI 구성 ───────────────────────────────────────────────────────────────
    def _init_ui(self):
        self.setWindowTitle("YOLO 두 모델 비교 추론")

        content = QtWidgets.QWidget()
        root = QtWidgets.QVBoxLayout(content)
        root.setSpacing(6); root.setContentsMargins(6, 6, 6, 6)

        _cb_style = ("QCheckBox{color:#dddddd;font-size:11px;padding:2px 4px;"
                     "background:#141420;border:1px solid #333;border-radius:3px;}"
                     "QCheckBox:hover{background:#1e1e30;border:1px solid #555;}"
                     "QCheckBox::indicator{width:14px;height:14px;}"
                     "QCheckBox::indicator:checked{background:#2255aa;border:2px solid #4488dd;border-radius:3px;}"
                     "QCheckBox::indicator:unchecked{background:#111;border:2px solid #444;border-radius:3px;}")

        # ── 상단: 소스 + 모델 + 파라미터 ────────────────────────────────────
        top = QtWidgets.QHBoxLayout()

        # [A] 영상 소스
        src_grp = QtWidgets.QGroupBox("영상 소스")
        src_grp.setStyleSheet("QGroupBox{color:#dddddd;font-weight:bold;}")
        src_lay = QtWidgets.QVBoxLayout(src_grp)

        type_row = QtWidgets.QHBoxLayout()
        type_row.addWidget(QtWidgets.QLabel("소스:"))
        self.src_combo = QtWidgets.QComboBox()
        items = ["웹캠", "동영상 파일"]
        if ROS2_AVAILABLE:
            items.append("ROS2 토픽")
        self.src_combo.addItems(items)
        self.src_combo.currentIndexChanged.connect(self._on_src_type_change)
        type_row.addWidget(self.src_combo)
        src_lay.addLayout(type_row)

        self.cam_widget = QtWidgets.QWidget()
        cam_row = QtWidgets.QHBoxLayout(self.cam_widget)
        cam_row.setContentsMargins(0,0,0,0)
        cam_row.addWidget(QtWidgets.QLabel("번호:"))
        self.cam_spin = QtWidgets.QSpinBox()
        self.cam_spin.setRange(0, 10)
        cam_row.addWidget(self.cam_spin)
        src_lay.addWidget(self.cam_widget)

        self.file_widget = QtWidgets.QWidget()
        file_row = QtWidgets.QHBoxLayout(self.file_widget)
        file_row.setContentsMargins(0,0,0,0)
        self.file_edit = QtWidgets.QLineEdit()
        self.file_edit.setPlaceholderText("동영상 파일 경로...")
        file_browse = QtWidgets.QPushButton("찾기")
        file_browse.clicked.connect(self._browse_video)
        file_row.addWidget(self.file_edit)
        file_row.addWidget(file_browse)
        self.file_widget.setVisible(False)
        src_lay.addWidget(self.file_widget)

        self.ros2_widget = QtWidgets.QWidget()
        ros2_col = QtWidgets.QVBoxLayout(self.ros2_widget)
        ros2_col.setContentsMargins(0,0,0,0)
        preset_row = QtWidgets.QHBoxLayout()
        preset_row.addWidget(QtWidgets.QLabel("프리셋:"))
        self.topic_preset = QtWidgets.QComboBox()
        self.topic_preset.addItems(ROS2_TOPIC_PRESETS + ["직접 입력..."])
        self.topic_preset.currentIndexChanged.connect(self._on_topic_preset_change)
        preset_row.addWidget(self.topic_preset)
        ros2_col.addLayout(preset_row)
        topic_row = QtWidgets.QHBoxLayout()
        topic_row.addWidget(QtWidgets.QLabel("토픽:"))
        self.topic_edit = QtWidgets.QLineEdit(ROS2_TOPIC_PRESETS[0])
        topic_row.addWidget(self.topic_edit)
        ros2_col.addLayout(topic_row)
        self.ros2_widget.setVisible(False)
        src_lay.addWidget(self.ros2_widget)

        btn_row = QtWidgets.QHBoxLayout()
        self.open_btn = QtWidgets.QPushButton("열기")
        self.open_btn.setFixedHeight(32)
        self.open_btn.setStyleSheet(
            "QPushButton{background:#1a5a1a;color:#88ff88;font-weight:bold;"
            "border:1px solid #336633;border-radius:3px;}"
            "QPushButton:hover{background:#2a7a2a;}")
        self.open_btn.clicked.connect(self.open_source)
        self.close_btn = QtWidgets.QPushButton("닫기")
        self.close_btn.setFixedHeight(32)
        self.close_btn.setEnabled(False)
        self.close_btn.clicked.connect(self.close_source)
        btn_row.addWidget(self.open_btn); btn_row.addWidget(self.close_btn)
        src_lay.addLayout(btn_row)
        self.src_status = QtWidgets.QLabel("소스 없음")
        self.src_status.setStyleSheet("color:#bbbbbb;font-size:10px;")
        src_lay.addWidget(self.src_status)
        src_grp.setFixedWidth(270)
        top.addWidget(src_grp)

        # [B] 모델 A (클래스 체크박스 포함)
        ma_grp = QtWidgets.QGroupBox("모델 A  (주황)")
        ma_grp.setStyleSheet("QGroupBox{color:#ff9944;font-weight:bold;}")
        ma_lay = QtWidgets.QVBoxLayout(ma_grp)
        self.combo_a = QtWidgets.QComboBox()
        self.combo_a.setMinimumWidth(220)
        load_a = QtWidgets.QPushButton("로드 A")
        load_a.setStyleSheet(
            "QPushButton{background:#4a2000;color:#ffaa55;border:1px solid #ff7800;"
            "border-radius:3px;font-weight:bold;}"
            "QPushButton:hover{background:#6a3000;}")
        load_a.clicked.connect(self._load_a)
        self.status_a = QtWidgets.QLabel("미로드")
        self.status_a.setStyleSheet("color:#cccccc;font-size:10px;")
        self.status_a.setWordWrap(True)
        ma_lay.addWidget(self.combo_a); ma_lay.addWidget(load_a)
        ma_lay.addWidget(self.status_a)
        # 클래스 체크박스 영역
        ca_btn = QtWidgets.QHBoxLayout()
        for lbl, fn in [("전체선택", lambda: [cb.setChecked(True)  for cb in self._class_checks_a.values()]),
                        ("전체해제", lambda: [cb.setChecked(False) for cb in self._class_checks_a.values()])]:
            b = QtWidgets.QPushButton(lbl); b.setFixedHeight(20); b.clicked.connect(fn); ca_btn.addWidget(b)
        self._cls_info_a = QtWidgets.QLabel("모델 로드 후 표시")
        self._cls_info_a.setStyleSheet("color:#aaaaaa;font-size:10px;")
        ca_btn.addWidget(self._cls_info_a); ca_btn.addStretch()
        ma_lay.addLayout(ca_btn)
        cls_sa = QtWidgets.QScrollArea(); cls_sa.setMaximumHeight(130); cls_sa.setWidgetResizable(True)
        cls_sa.setStyleSheet("QScrollArea{border:1px solid #333;background:#0e0e18;}")
        self._cls_cont_a = QtWidgets.QWidget()
        self._cls_cont_a.setStyleSheet("background:#0e0e18;")
        self._cls_grid_a = QtWidgets.QGridLayout(self._cls_cont_a)
        self._cls_grid_a.setSpacing(3); self._cls_grid_a.setContentsMargins(4,3,4,3)
        cls_sa.setWidget(self._cls_cont_a)
        ma_lay.addWidget(cls_sa)
        top.addWidget(ma_grp)

        # [C] 모델 B (클래스 체크박스 포함)
        mb_grp = QtWidgets.QGroupBox("모델 B  (청록)")
        mb_grp.setStyleSheet("QGroupBox{color:#44ddff;font-weight:bold;}")
        mb_lay = QtWidgets.QVBoxLayout(mb_grp)
        self.combo_b = QtWidgets.QComboBox()
        self.combo_b.setMinimumWidth(220)
        load_b = QtWidgets.QPushButton("로드 B")
        load_b.setStyleSheet(
            "QPushButton{background:#001a2a;color:#44ddff;border:1px solid #00c8ff;"
            "border-radius:3px;font-weight:bold;}"
            "QPushButton:hover{background:#003a4a;}")
        load_b.clicked.connect(self._load_b)
        self.status_b = QtWidgets.QLabel("미로드")
        self.status_b.setStyleSheet("color:#cccccc;font-size:10px;")
        self.status_b.setWordWrap(True)
        mb_lay.addWidget(self.combo_b); mb_lay.addWidget(load_b)
        mb_lay.addWidget(self.status_b)
        cb_btn = QtWidgets.QHBoxLayout()
        for lbl, fn in [("전체선택", lambda: [cb.setChecked(True)  for cb in self._class_checks_b.values()]),
                        ("전체해제", lambda: [cb.setChecked(False) for cb in self._class_checks_b.values()])]:
            b = QtWidgets.QPushButton(lbl); b.setFixedHeight(20); b.clicked.connect(fn); cb_btn.addWidget(b)
        self._cls_info_b = QtWidgets.QLabel("모델 로드 후 표시")
        self._cls_info_b.setStyleSheet("color:#aaaaaa;font-size:10px;")
        cb_btn.addWidget(self._cls_info_b); cb_btn.addStretch()
        mb_lay.addLayout(cb_btn)
        cls_sb = QtWidgets.QScrollArea(); cls_sb.setMaximumHeight(130); cls_sb.setWidgetResizable(True)
        cls_sb.setStyleSheet("QScrollArea{border:1px solid #333;background:#0e0e18;}")
        self._cls_cont_b = QtWidgets.QWidget()
        self._cls_cont_b.setStyleSheet("background:#0e0e18;")
        self._cls_grid_b = QtWidgets.QGridLayout(self._cls_cont_b)
        self._cls_grid_b.setSpacing(3); self._cls_grid_b.setContentsMargins(4,3,4,3)
        cls_sb.setWidget(self._cls_cont_b)
        mb_lay.addWidget(cls_sb)
        top.addWidget(mb_grp)

        # [D] 파라미터
        param_grp = QtWidgets.QGroupBox("설정")
        param_grp.setStyleSheet("QGroupBox{color:#dddddd;font-weight:bold;}")
        p_lay = QtWidgets.QFormLayout(param_grp)
        ref_btn = QtWidgets.QPushButton("↺ 모델 목록")
        ref_btn.clicked.connect(self._refresh_models)
        p_lay.addRow("", ref_btn)
        self.conf_sp = QtWidgets.QDoubleSpinBox()
        self.conf_sp.setRange(0.05, 0.95); self.conf_sp.setValue(0.40)
        self.conf_sp.setSingleStep(0.05); self.conf_sp.setDecimals(2)
        self.conf_sp.valueChanged.connect(lambda v: setattr(self, 'conf_thresh', v))
        p_lay.addRow("conf:", self.conf_sp)
        self.disp_w_sp = QtWidgets.QSpinBox()
        self.disp_w_sp.setRange(160, 1920); self.disp_w_sp.setSingleStep(32)
        self.disp_w_sp.setValue(540); self.disp_w_sp.valueChanged.connect(self._on_disp_resize)
        p_lay.addRow("표시 너비:", self.disp_w_sp)
        self.disp_h_sp = QtWidgets.QSpinBox()
        self.disp_h_sp.setRange(120, 1080); self.disp_h_sp.setSingleStep(32)
        self.disp_h_sp.setValue(400); self.disp_h_sp.valueChanged.connect(self._on_disp_resize)
        p_lay.addRow("표시 높이:", self.disp_h_sp)
        top.addWidget(param_grp)

        root.addLayout(top)

        # ── 가운데: 두 영상 나란히 ────────────────────────────────────────
        mid = QtWidgets.QHBoxLayout()

        a_grp = QtWidgets.QGroupBox("모델 A 추론")
        a_grp.setStyleSheet("QGroupBox{color:#ff9944;font-weight:bold;}")
        a_grp.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        a_lay = QtWidgets.QVBoxLayout(a_grp); a_lay.setContentsMargins(2,2,2,2)
        self.img_a = QtWidgets.QLabel("모델 A 미로드")
        self.img_a.setMinimumSize(320, 240)
        self.img_a.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        self.img_a.setStyleSheet("background:#0e0e18;color:#aaaaaa;")
        self.img_a.setAlignment(Qt.AlignCenter)
        self.det_a = QtWidgets.QLabel("—")
        self.det_a.setStyleSheet("color:#ffaa55;background:#180a00;padding:4px;"
                                  "font-family:monospace;font-size:11px;")
        self.det_a.setWordWrap(True); self.det_a.setMaximumHeight(60)
        a_lay.addWidget(self.img_a, stretch=1); a_lay.addWidget(self.det_a)
        mid.addWidget(a_grp, stretch=1)

        sep = QtWidgets.QFrame(); sep.setFrameShape(QtWidgets.QFrame.VLine)
        sep.setStyleSheet("color:#444;"); mid.addWidget(sep)

        b_grp = QtWidgets.QGroupBox("모델 B 추론")
        b_grp.setStyleSheet("QGroupBox{color:#44ddff;font-weight:bold;}")
        b_grp.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        b_lay = QtWidgets.QVBoxLayout(b_grp); b_lay.setContentsMargins(2,2,2,2)
        self.img_b = QtWidgets.QLabel("모델 B 미로드")
        self.img_b.setMinimumSize(320, 240)
        self.img_b.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        self.img_b.setStyleSheet("background:#0e0e18;color:#aaaaaa;")
        self.img_b.setAlignment(Qt.AlignCenter)
        self.det_b = QtWidgets.QLabel("—")
        self.det_b.setStyleSheet("color:#44ddff;background:#000f18;padding:4px;"
                                  "font-family:monospace;font-size:11px;")
        self.det_b.setWordWrap(True); self.det_b.setMaximumHeight(60)
        b_lay.addWidget(self.img_b, stretch=1); b_lay.addWidget(self.det_b)
        mid.addWidget(b_grp, stretch=1)

        root.addLayout(mid, stretch=1)

        # ── 하단: 요약 ────────────────────────────────────────────────────
        quad_grp = QtWidgets.QGroupBox("감지 결과  — ● 주황=모델A   ◆ 청록=모델B")
        quad_grp.setStyleSheet("QGroupBox{color:#dddddd;font-weight:bold;}")
        quad_grp.setMaximumHeight(180)
        q_lay = QtWidgets.QVBoxLayout(quad_grp); q_lay.setContentsMargins(2,2,2,2)
        self.quad_lbl = QtWidgets.QLabel()
        self.quad_lbl.setStyleSheet("background:#0e0e18;"); self.quad_lbl.setMinimumHeight(120)
        q_lay.addWidget(self.quad_lbl)
        root.addWidget(quad_grp)

        # ── QScrollArea 래핑 ──────────────────────────────────────────────
        scroll = QtWidgets.QScrollArea()
        scroll.setWidget(content); scroll.setWidgetResizable(True)
        scroll.setStyleSheet("QScrollArea{border:none;}")
        outer = QtWidgets.QVBoxLayout(self)
        outer.setContentsMargins(0,0,0,0); outer.addWidget(scroll)

        # 미사용 변수 억제
        _ = _cb_style

    # ── 소스 관리 ─────────────────────────────────────────────────────────────
    def _on_src_type_change(self, idx):
        sel = ["cam", "file", "ros2"][min(idx, 2)]
        self.cam_widget.setVisible(sel == "cam")
        self.file_widget.setVisible(sel == "file")
        self.ros2_widget.setVisible(sel == "ros2")

    def _on_topic_preset_change(self, idx):
        if idx < len(ROS2_TOPIC_PRESETS):
            self.topic_edit.setText(ROS2_TOPIC_PRESETS[idx])
            self.topic_edit.setReadOnly(True)
        else:
            self.topic_edit.setReadOnly(False)
            self.topic_edit.clear()

    def _browse_video(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self, "동영상 파일 선택", "",
            "Video Files (*.mp4 *.avi *.mkv *.mov);;All Files (*)")
        if path:
            self.file_edit.setText(path)

    def open_source(self):
        self.close_source()
        idx = self.src_combo.currentIndex()
        sel = ["cam", "file", "ros2"][min(idx, 2)]

        if sel == "ros2":
            if not ROS2_AVAILABLE:
                QtWidgets.QMessageBox.warning(self, "경고", "ROS2 패키지 없음")
                return
            topic = self.topic_edit.text().strip()
            if not topic:
                QtWidgets.QMessageBox.warning(self, "경고", "토픽 이름 입력")
                return
            self.ros2_sub = Ros2Subscriber(topic)
            self.ros2_sub.frame_received.connect(self._on_frame)
            self.ros2_sub.start()
            self.src_status.setText(f"ROS2: {topic}")
        else:
            src = self.cam_spin.value() if sel == "cam" else self.file_edit.text().strip()
            if sel == "file" and not src:
                QtWidgets.QMessageBox.warning(self, "경고", "파일 경로 선택")
                return
            self.cap = cv2.VideoCapture(src)
            if not self.cap.isOpened():
                QtWidgets.QMessageBox.critical(self, "오류", f"열기 실패: {src}")
                self.cap = None
                return
            self.src_status.setText(f"열림: {src}")

        self._source_open = True
        self.open_btn.setEnabled(False)
        self.close_btn.setEnabled(True)
        self.display_timer.start(33)

    def close_source(self):
        self.display_timer.stop()
        if self.cap:
            self.cap.release()
            self.cap = None
        if self.ros2_sub:
            self.ros2_sub.stop()
            self.ros2_sub = None
        with self._frame_lock:
            self._cur_frame = None
        self._source_open = False
        self.open_btn.setEnabled(True)
        self.close_btn.setEnabled(False)
        self.src_status.setText("소스 없음")
        self.img_a.clear(); self.img_a.setText("소스 닫힘")
        self.img_b.clear(); self.img_b.setText("소스 닫힘")

    def _on_frame(self, frame):
        with self._frame_lock:
            self._cur_frame = frame.copy()

    # ── 추론 루프 (타이머) ────────────────────────────────────────────────────
    def _tick(self):
        # OpenCV 소스: 타이머에서 직접 read
        if self.cap and self.cap.isOpened():
            ret, frame = self.cap.read()
            if not ret:
                self.cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                return
            with self._frame_lock:
                self._cur_frame = frame.copy()

        with self._frame_lock:
            frame = self._cur_frame

        if frame is None:
            return

        pos_a, pos_b = [], []
        vis_a = vis_b = frame

        if self.model_a:
            try:
                pos_a = run_inference(self.model_a, frame, self.conf_thresh, self._allowed_a())
                vis_a = draw_boxes(frame, pos_a, COL_A)
            except Exception as e:
                print(f"[A] {e}")

        if self.model_b:
            try:
                pos_b = run_inference(self.model_b, frame, self.conf_thresh, self._allowed_b())
                vis_b = draw_boxes(frame, pos_b, COL_B)
            except Exception as e:
                print(f"[B] {e}")

        self._pos_a, self._pos_b = pos_a, pos_b
        dw = max(self.img_a.width(), 320)
        dh = max(self.img_a.height(), 240)
        self.img_a.setPixmap(frame_to_pixmap(vis_a, dw, dh))
        self.img_b.setPixmap(frame_to_pixmap(vis_b, dw, dh))
        self._update_det_labels()
        self._update_quad()

    def _on_disp_resize(self):
        self.disp_w = self.disp_w_sp.value()
        self.disp_h = self.disp_h_sp.value()
        self.img_a.setMinimumSize(self.disp_w, self.disp_h)
        self.img_b.setMinimumSize(self.disp_w, self.disp_h)

    # ── 모델 관리 ─────────────────────────────────────────────────────────────
    def _refresh_models(self):
        files = list_pt_files()
        for c in (self.combo_a, self.combo_b):
            c.clear(); c.addItems(files)

    def _load_model(self, rel: str, slot: str):
        from ultralytics import YOLO
        path = WEIGHTS_DIR / rel
        try:
            m = YOLO(str(path))
            cls_names = list(m.names.values())
            if slot == 'A':
                self.model_a = m
                self.sig_status_a.emit(f"✅ {rel}  ({len(cls_names)}cls)", "#ff9944")
                self.sig_classes_a.emit(cls_names)
            else:
                self.model_b = m
                self.sig_status_b.emit(f"✅ {rel}  ({len(cls_names)}cls)", "#44ddff")
                self.sig_classes_b.emit(cls_names)
        except Exception as e:
            self.sig_error.emit(f"로드 실패: {e}")

    def _load_a(self):
        rel = self.combo_a.currentText()
        if rel:
            self.status_a.setText("로드 중...")
            from threading import Thread
            Thread(target=self._load_model, args=(rel, 'A'), daemon=True).start()

    def _load_b(self):
        rel = self.combo_b.currentText()
        if rel:
            self.status_b.setText("로드 중...")
            from threading import Thread
            Thread(target=self._load_model, args=(rel, 'B'), daemon=True).start()

    # ── 클래스 체크박스 ───────────────────────────────────────────────────────
    def _rebuild_classes(self, names, grid, cont, checks, info_lbl, saved):
        for i in reversed(range(grid.count())):
            w = grid.itemAt(i).widget()
            if w: w.deleteLater()
        checks.clear()
        COLS = 4
        for idx, name in enumerate(names):
            cb = QtWidgets.QCheckBox(name)
            cb.setChecked(saved.get(name, True))
            cb.setStyleSheet(
                "QCheckBox{color:#dddddd;font-size:11px;padding:2px 4px;"
                "background:#141420;border:1px solid #333;border-radius:3px;}"
                "QCheckBox:hover{background:#1e1e30;}"
                "QCheckBox::indicator{width:14px;height:14px;}"
                "QCheckBox::indicator:checked{background:#2255aa;border:2px solid #4488dd;border-radius:3px;}"
                "QCheckBox::indicator:unchecked{background:#111;border:2px solid #444;border-radius:3px;}")
            grid.addWidget(cb, idx//COLS, idx%COLS)
            checks[name] = cb
        info_lbl.setText(f"총 {len(names)}개 클래스")
        info_lbl.setStyleSheet("color:#88ddaa;font-size:10px;font-weight:bold;")

    def _rebuild_classes_a(self, names):
        self._rebuild_classes(names, self._cls_grid_a, self._cls_cont_a,
                              self._class_checks_a, self._cls_info_a, self._saved_classes_a)

    def _rebuild_classes_b(self, names):
        self._rebuild_classes(names, self._cls_grid_b, self._cls_cont_b,
                              self._class_checks_b, self._cls_info_b, self._saved_classes_b)

    def _allowed_a(self):
        if not self._class_checks_a: return None
        return {k for k,cb in self._class_checks_a.items() if cb.isChecked()}

    def _allowed_b(self):
        if not self._class_checks_b: return None
        return {k for k,cb in self._class_checks_b.items() if cb.isChecked()}

    # ── 결과 표시 ─────────────────────────────────────────────────────────────
    def _update_det_labels(self):
        def fmt(positions, label):
            if not positions:
                return f"[{label}] 검출 없음"
            return "\n".join(
                f"[{label}] {p['label']} {p['conf']:.2f}"
                for p in positions)
        self.det_a.setText(fmt(self._pos_a, 'A'))
        self.det_b.setText(fmt(self._pos_b, 'B'))

    def _update_quad(self):
        W = self.quad_lbl.width()  or 1200
        H = self.quad_lbl.height() or 200
        img = self._draw_detection_summary(W, H)
        rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        qi  = QtGui.QImage(rgb.data, W, H, 3 * W, QtGui.QImage.Format_RGB888)
        self.quad_lbl.setPixmap(QtGui.QPixmap.fromImage(qi))

    def _draw_detection_summary(self, W: int, H: int) -> np.ndarray:
        """모델 A/B 검출 결과를 나란히 표시하는 요약 패널."""
        img = np.full((H, W, 3), (14, 14, 24), dtype=np.uint8)
        mid = W // 2

        # 구분선
        cv2.line(img, (mid, 0), (mid, H), (60, 60, 80), 1)

        # 제목
        cv2.putText(img, "Model A", (10, 24),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, COL_A, 2)
        cv2.putText(img, "Model B", (mid + 10, 24),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, COL_B, 2)

        # A 결과
        y = 55
        if not self._pos_a:
            cv2.putText(img, "(검출 없음)", (10, y),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (100, 100, 100), 1)
        for p in self._pos_a:
            line = f"{p['label']}  {p['conf']:.2f}"
            cv2.putText(img, line, (10, y),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.55, COL_A, 1)
            y += 26
            if y > H - 10:
                break

        # B 결과
        y = 55
        if not self._pos_b:
            cv2.putText(img, "(검출 없음)", (mid + 10, y),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (100, 100, 100), 1)
        for p in self._pos_b:
            line = f"{p['label']}  {p['conf']:.2f}"
            cv2.putText(img, line, (mid + 10, y),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.55, COL_B, 1)
            y += 26
            if y > H - 10:
                break

        # A/B 수 비교
        count_txt = f"A: {len(self._pos_a)}개   B: {len(self._pos_b)}개"
        cv2.putText(img, count_txt, (W - 200, H - 10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.55, (180, 180, 180), 1)
        return img

    # ── 설정 저장/복원 ────────────────────────────────────────────────────────
    def _save_settings(self):
        try:
            s = {
                'conf':       self.conf_sp.value(),
                'disp_w':     self.disp_w_sp.value(),
                'disp_h':     self.disp_h_sp.value(),
                'src_type':   self.src_combo.currentIndex(),
                'cam_num':    self.cam_spin.value(),
                'video_file': self.file_edit.text(),
                'ros2_topic': self.topic_edit.text(),
                'model_a':    self.combo_a.currentText(),
                'model_b':    self.combo_b.currentText(),
                'classes_a':  {k: cb.isChecked() for k,cb in self._class_checks_a.items()},
                'classes_b':  {k: cb.isChecked() for k,cb in self._class_checks_b.items()},
            }
            SETTINGS_FILE.write_text(json.dumps(s, ensure_ascii=False, indent=2))
        except Exception as e:
            print(f"[설정 저장 오류] {e}")

    def _load_settings(self):
        if not SETTINGS_FILE.exists():
            return
        try:
            s = json.loads(SETTINGS_FILE.read_text())
            self.conf_sp.setValue(s.get('conf', 0.40))
            self.disp_w_sp.setValue(s.get('disp_w', 540))
            self.disp_h_sp.setValue(s.get('disp_h', 400))
            si = s.get('src_type', 0)
            if si < self.src_combo.count():
                self.src_combo.setCurrentIndex(si)
            self.cam_spin.setValue(s.get('cam_num', 0))
            vf = s.get('video_file', '')
            if vf: self.file_edit.setText(vf)
            topic = s.get('ros2_topic', '')
            if topic:
                self.topic_edit.setText(topic)
                if topic in ROS2_TOPIC_PRESETS:
                    self.topic_preset.setCurrentIndex(ROS2_TOPIC_PRESETS.index(topic))
            ma = s.get('model_a', '')
            for i in range(self.combo_a.count()):
                if self.combo_a.itemText(i) == ma:
                    self.combo_a.setCurrentIndex(i); break
            mb = s.get('model_b', '')
            for i in range(self.combo_b.count()):
                if self.combo_b.itemText(i) == mb:
                    self.combo_b.setCurrentIndex(i); break
            # 클래스 체크 상태 — 모델 로드 후 _rebuild_classes_a/b 에서 적용
            self._saved_classes_a = s.get('classes_a', {})
            self._saved_classes_b = s.get('classes_b', {})
        except Exception as e:
            print(f"[설정 로드 오류] {e}")

    def closeEvent(self, event):
        self._save_settings()
        self.close_source()
        event.accept()


# ── 진입점 ───────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    app.setStyle('Fusion')
    _pal = QtGui.QPalette()
    _pal.setColor(QtGui.QPalette.Window,          QtGui.QColor(14, 14, 22))
    _pal.setColor(QtGui.QPalette.WindowText,      QtGui.QColor(200, 200, 200))
    _pal.setColor(QtGui.QPalette.Base,            QtGui.QColor(10, 10, 16))
    _pal.setColor(QtGui.QPalette.AlternateBase,   QtGui.QColor(20, 20, 30))
    _pal.setColor(QtGui.QPalette.Button,          QtGui.QColor(30, 30, 48))
    _pal.setColor(QtGui.QPalette.ButtonText,      QtGui.QColor(200, 200, 200))
    _pal.setColor(QtGui.QPalette.Highlight,       QtGui.QColor(60, 100, 200))
    _pal.setColor(QtGui.QPalette.HighlightedText, QtGui.QColor(255, 255, 255))
    _pal.setColor(QtGui.QPalette.Text,            QtGui.QColor(200, 200, 200))
    _pal.setColor(QtGui.QPalette.ToolTipBase,     QtGui.QColor(20, 20, 30))
    _pal.setColor(QtGui.QPalette.ToolTipText,     QtGui.QColor(200, 200, 200))
    app.setPalette(_pal)
    win = InferenceCompareUI()
    win.showMaximized()
    sys.exit(app.exec_())
