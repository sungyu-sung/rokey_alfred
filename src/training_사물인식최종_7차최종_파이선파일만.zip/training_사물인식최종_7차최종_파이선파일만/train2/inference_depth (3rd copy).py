#!/usr/bin/env python3
"""inference_depth.py — YOLO 추론 + RGB-D 3D 좌표 계산

토픽 (고정):
  /camera/color/image_raw  — 컬러
  /camera/depth/image_raw  — 뎁스 (16UC1 mm / 32FC1 m)

변환 방법:
  P1~P4 픽셀(마우스 클릭) + 실세계 X,Y(m) + 뎁스(자동) 입력
  → cv2.findHomography 로 픽셀→실세계 X,Y 변환
  → 4점 뎁스로 바닥 평면(d=a·u+b·v+c) 피팅
  → 감지 사물의 (바닥뎁스 - 실제뎁스) = 바닥 위 높이
"""
import os, sys, threading
os.environ['QT_QPA_PLATFORM_PLUGIN_PATH'] = '/usr/lib/x86_64-linux-gnu/qt5/plugins'
os.environ['QT_QPA_PLATFORM'] = 'wayland'

import cv2
import numpy as np
from pathlib import Path
from threading import Lock

from PyQt5 import QtWidgets, QtCore, QtGui
from PyQt5.QtCore import Qt, pyqtSignal, QThread, QTimer

WEIGHTS_DIR = Path("/home/han3/turtlebot4_ws/src/training/weights")
COLOR_TOPIC = "/camera/color/image_raw"
DEPTH_TOPIC = "/camera/depth/image_raw"
PT_BGR   = [(0,255,80), (255,128,0), (0,200,255), (255,0,200)]
PT_NAMES = ["P1", "P2", "P3", "P4"]

try:
    import rclpy
    from sensor_msgs.msg import Image
    from cv_bridge import CvBridge
    ROS2_AVAILABLE = True
except ImportError:
    ROS2_AVAILABLE = False


# ── ROS2 구독 ──────────────────────────────────────────────────────────────────
class Ros2DepthSub(QThread):
    color_rx = pyqtSignal(object)
    depth_rx = pyqtSignal(object)

    def __init__(self):
        super().__init__()
        self._stop  = threading.Event()
        self.bridge = CvBridge()

    def run(self):
        if not rclpy.ok():
            rclpy.init()
        node = rclpy.create_node('inf_depth_node')
        node.create_subscription(Image, COLOR_TOPIC, self._cb_color, 10)
        node.create_subscription(Image, DEPTH_TOPIC, self._cb_depth, 10)
        while not self._stop.is_set() and rclpy.ok():
            rclpy.spin_once(node, timeout_sec=0.05)
        node.destroy_node()

    def _cb_color(self, msg):
        try:
            self.color_rx.emit(self.bridge.imgmsg_to_cv2(msg, 'bgr8'))
        except Exception:
            pass

    def _cb_depth(self, msg):
        try:
            if msg.encoding == '32FC1':
                d = np.frombuffer(msg.data, dtype=np.float32).reshape(
                    msg.height, msg.width).copy()
            else:   # 16UC1 mm
                d = np.frombuffer(msg.data, dtype=np.uint16).reshape(
                    msg.height, msg.width).astype(np.float32) / 1000.0
            self.depth_rx.emit(d)
        except Exception:
            pass

    def stop(self):
        self._stop.set(); self.wait(2000)


# ── 클릭 가능 레이블 ──────────────────────────────────────────────────────────
class ClickableLabel(QtWidgets.QLabel):
    clicked_px = pyqtSignal(int, int)

    def __init__(self):
        super().__init__()
        self._sw = 640; self._sh = 480
        self.setCursor(Qt.CrossCursor)

    def set_src(self, w, h):
        self._sw, self._sh = max(1,w), max(1,h)

    def _map(self, lx, ly):
        lw, lh = self.width(), self.height()
        s = min(lw/self._sw, lh/self._sh)
        dw, dh = self._sw*s, self._sh*s
        rx, ry = lx-(lw-dw)/2, ly-(lh-dh)/2
        if 0 <= rx < dw and 0 <= ry < dh:
            return int(rx*self._sw/dw), int(ry*self._sh/dh)
        return None

    def mousePressEvent(self, ev):
        if ev.button() == Qt.LeftButton:
            r = self._map(ev.x(), ev.y())
            if r:
                self.clicked_px.emit(*r)
        super().mousePressEvent(ev)


# ── 유틸 ──────────────────────────────────────────────────────────────────────
def list_pt_files():
    if not WEIGHTS_DIR.exists():
        return []
    return [str(f.relative_to(WEIGHTS_DIR)) for f in sorted(WEIGHTS_DIR.rglob("*.pt"))]


def run_inference(model, frame, conf, allowed):
    out = []
    for r in model.predict(frame, conf=conf, verbose=False):
        if r.boxes is not None and len(r.boxes):
            for box in r.boxes:
                lbl = model.names[int(box.cls[0])]
                if lbl not in allowed:
                    continue
                x1,y1,x2,y2 = box.xyxy[0].tolist()
                out.append({'label':lbl, 'conf':float(box.conf[0]),
                            'cx':int((x1+x2)/2), 'cy':int((y1+y2)/2),
                            'x1':x1,'y1':y1,'x2':x2,'y2':y2, 'type':'det'})
        elif r.obb is not None and len(r.obb):
            for box in r.obb:
                lbl = model.names[int(box.cls[0])]
                if lbl not in allowed:
                    continue
                corners = box.xyxyxyxy[0].cpu().numpy().astype(int)
                mn,mx = corners.min(0), corners.max(0)
                out.append({'label':lbl, 'conf':float(box.conf[0]),
                            'cx':int((mn[0]+mx[0])/2), 'cy':int((mn[1]+mx[1])/2),
                            'x1':mn[0],'y1':mn[1],'x2':mx[0],'y2':mx[1],
                            'corners':corners, 'type':'obb'})
    return out


def to_pixmap(frame, w, h):
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    fh,fw,ch = rgb.shape
    qi = QtGui.QImage(rgb.data, fw,fh,ch*fw, QtGui.QImage.Format_RGB888)
    return QtGui.QPixmap.fromImage(qi).scaled(w,h,Qt.KeepAspectRatio,Qt.SmoothTransformation)


def read_depth_at(depth_arr, u, v):
    """뎁스 배열에서 (u,v) 픽셀의 유효한 뎁스(m) 반환. 없으면 None."""
    if depth_arr is None:
        return None
    if not (0 <= v < depth_arr.shape[0] and 0 <= u < depth_arr.shape[1]):
        return None
    z = float(depth_arr[v, u])
    return z if 0.05 < z < 30.0 else None


# ── 메인 UI ───────────────────────────────────────────────────────────────────
class InferenceDepthUI(QtWidgets.QWidget):
    sig_classes = pyqtSignal(list)
    sig_mdl_st  = pyqtSignal(str, str)
    sig_error   = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        self.model        = None
        self.ros2_sub     = None
        self._clk         = Lock()
        self._dlk         = Lock()
        self._color_frame = None
        self._depth_frame = None
        self.conf         = 0.40
        self._floor_pts   = []      # {u,v,depth_z}  최대 4
        self._ref_uvxyz   = None    # (u,v,X,Y,Z)
        self._mode        = 'normal'
        self._H           = None    # 호모그래피 (픽셀→world XY)
        self._floor_abc   = None    # (a,b,c): floor_depth(u,v) = a*u+b*v+c
        self._class_checks: dict[str, QtWidgets.QCheckBox] = {}
        self._detections  = []

        self._init_ui()
        self.sig_classes.connect(self._rebuild_class_panel)
        self.sig_mdl_st.connect(lambda t,c:(
            self._mdl_lbl.setText(t),
            self._mdl_lbl.setStyleSheet(f"color:{c};font-size:10px;")))
        self.sig_error.connect(lambda m: QtWidgets.QMessageBox.critical(self,"오류",m))
        self._refresh_models()
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._tick)
        self._grid_timer = QTimer(self)
        self._grid_timer.timeout.connect(self._update_grid)

    # ── UI 구성 ───────────────────────────────────────────────────────────────
    def _init_ui(self):
        self.setWindowTitle("YOLO Depth 추론  [4점 호모그래피 + 바닥 평면 + 뎁스 그리드]")
        root = QtWidgets.QVBoxLayout(self)
        root.setSpacing(4); root.setContentsMargins(5,5,5,5)
        root.addLayout(self._top_row())
        root.addWidget(self._class_panel())
        root.addWidget(self._floor_panel())

        # 영상 + 뎁스 그리드 나란히 — 남은 공간 모두 차지
        img_row = QtWidgets.QHBoxLayout()
        img_row.addWidget(self._image_panel(), stretch=1)
        img_row.addWidget(self._grid_panel(), stretch=1)
        root.addLayout(img_row, stretch=3)
        root.addWidget(self._result_panel())

    # 행1: 연결 | 모델 | 설정
    def _top_row(self):
        row = QtWidgets.QHBoxLayout()

        cg = QtWidgets.QGroupBox("ROS2 연결 (고정 토픽)")
        cl = QtWidgets.QVBoxLayout(cg)
        cl.addWidget(QtWidgets.QLabel(f"색상: {COLOR_TOPIC}"))
        cl.addWidget(QtWidgets.QLabel(f"뎁스: {DEPTH_TOPIC}"))
        br = QtWidgets.QHBoxLayout()
        self._conn_btn = QtWidgets.QPushButton("연결")
        self._conn_btn.setStyleSheet(
            "QPushButton{background:#1a5a1a;color:#88ff88;font-weight:bold;"
            "border:1px solid #336633;border-radius:3px;}"
            "QPushButton:hover{background:#2a7a2a;}")
        self._conn_btn.clicked.connect(self._connect)
        self._disc_btn = QtWidgets.QPushButton("해제"); self._disc_btn.setEnabled(False)
        self._disc_btn.clicked.connect(self._disconnect)
        br.addWidget(self._conn_btn); br.addWidget(self._disc_btn)
        cl.addLayout(br)
        self._conn_lbl = QtWidgets.QLabel("미연결")
        self._conn_lbl.setStyleSheet("color:#888;font-size:10px;")
        cl.addWidget(self._conn_lbl)
        cg.setFixedWidth(260)
        row.addWidget(cg)

        mg = QtWidgets.QGroupBox("모델")
        ml = QtWidgets.QVBoxLayout(mg)
        self._mdl_combo = QtWidgets.QComboBox()
        lb = QtWidgets.QPushButton("로드")
        lb.setStyleSheet(
            "QPushButton{background:#2a2a4a;color:#aaaaff;border:1px solid #6666ff;"
            "border-radius:3px;font-weight:bold;}"
            "QPushButton:hover{background:#3a3a6a;}")
        lb.clicked.connect(self._load_model)
        self._mdl_lbl = QtWidgets.QLabel("미로드")
        self._mdl_lbl.setStyleSheet("color:#888;font-size:10px;"); self._mdl_lbl.setWordWrap(True)
        sr = QtWidgets.QHBoxLayout()
        sr.addWidget(QtWidgets.QLabel("감도:"))
        self._conf_sl = QtWidgets.QSlider(Qt.Horizontal)
        self._conf_sl.setRange(5,95); self._conf_sl.setValue(40)
        self._conf_sl.setStyleSheet(
            "QSlider::groove:horizontal{height:6px;background:#333;border-radius:3px;}"
            "QSlider::handle:horizontal{width:14px;height:14px;margin:-4px 0;"
            "background:#aaaaff;border-radius:7px;}"
            "QSlider::sub-page:horizontal{background:#aaaaff;border-radius:3px;}")
        self._conf_lbl = QtWidgets.QLabel("0.40")
        self._conf_lbl.setFixedWidth(34); self._conf_lbl.setStyleSheet("color:#aaaaff;font-weight:bold;")
        self._conf_sl.valueChanged.connect(self._on_conf)
        sr.addWidget(self._conf_sl); sr.addWidget(self._conf_lbl)
        ml.addWidget(self._mdl_combo); ml.addWidget(lb)
        ml.addWidget(self._mdl_lbl); ml.addLayout(sr)
        row.addWidget(mg)

        og = QtWidgets.QGroupBox("표시 설정")
        ol = QtWidgets.QFormLayout(og)
        rb = QtWidgets.QPushButton("↺ 모델 목록"); rb.clicked.connect(self._refresh_models)
        ol.addRow("", rb)
        self._dw_sp = QtWidgets.QSpinBox()
        self._dw_sp.setRange(320,1280); self._dw_sp.setSingleStep(32)
        self._dw_sp.setValue(640); self._dw_sp.valueChanged.connect(self._on_resize)
        ol.addRow("컬러 너비:", self._dw_sp)
        self._dh_sp = QtWidgets.QSpinBox()
        self._dh_sp.setRange(240,900); self._dh_sp.setSingleStep(32)
        self._dh_sp.setValue(480); self._dh_sp.valueChanged.connect(self._on_resize)
        ol.addRow("컬러 높이:", self._dh_sp)
        # 그리드 셀 수
        self._gcols = QtWidgets.QSpinBox()
        self._gcols.setRange(4,40); self._gcols.setValue(10)
        ol.addRow("그리드 열:", self._gcols)
        self._grows = QtWidgets.QSpinBox()
        self._grows.setRange(3,30); self._grows.setValue(7)
        ol.addRow("그리드 행:", self._grows)
        self._grid_interval_sp = QtWidgets.QSpinBox()
        self._grid_interval_sp.setRange(33, 5000); self._grid_interval_sp.setValue(200)
        self._grid_interval_sp.setSuffix(" ms")
        self._grid_interval_sp.valueChanged.connect(
            lambda v: self._grid_timer.setInterval(v))
        ol.addRow("그리드 갱신:", self._grid_interval_sp)
        row.addWidget(og)
        return row

    # 클래스 선택 패널
    def _class_panel(self):
        grp = QtWidgets.QGroupBox("사물 클래스 선택  (체크된 클래스만 인식)")
        grp.setStyleSheet("QGroupBox{font-weight:bold;color:#88ffcc;}")
        outer = QtWidgets.QVBoxLayout(grp)
        br = QtWidgets.QHBoxLayout()
        ab = QtWidgets.QPushButton("전체 선택"); ab.setFixedWidth(90)
        ab.setStyleSheet("QPushButton{background:#1a3a1a;color:#88ff88;"
                         "border:1px solid #336633;border-radius:3px;font-size:11px;}"
                         "QPushButton:hover{background:#2a5a2a;}")
        ab.clicked.connect(self._sel_all)
        nb = QtWidgets.QPushButton("전체 해제"); nb.setFixedWidth(90)
        nb.setStyleSheet("QPushButton{background:#3a1a1a;color:#ff8888;"
                         "border:1px solid #663333;border-radius:3px;font-size:11px;}"
                         "QPushButton:hover{background:#5a2a2a;}")
        nb.clicked.connect(self._sel_none)
        self._cls_info = QtWidgets.QLabel("모델 로드 후 표시")
        self._cls_info.setStyleSheet("color:#666;font-size:10px;")
        br.addWidget(ab); br.addWidget(nb); br.addWidget(self._cls_info); br.addStretch()
        outer.addLayout(br)
        scroll = QtWidgets.QScrollArea(); scroll.setWidgetResizable(True)
        scroll.setMaximumHeight(110)
        scroll.setStyleSheet("QScrollArea{border:1px solid #333;background:#0a0a0a;border-radius:4px;}")
        self._cls_cont = QtWidgets.QWidget(); self._cls_cont.setStyleSheet("background:#0a0a0a;")
        self._cls_grid = QtWidgets.QGridLayout(self._cls_cont)
        self._cls_grid.setSpacing(8); self._cls_grid.setContentsMargins(8,6,8,6)
        scroll.setWidget(self._cls_cont)
        outer.addWidget(scroll)
        return grp

    # 바닥면 4점 패널
    def _floor_panel(self):
        grp = QtWidgets.QGroupBox("바닥면 4점 설정  →  호모그래피(X,Y) + 바닥 평면(Z) 자동 계산")
        grp.setStyleSheet("QGroupBox{font-weight:bold;color:#ffcc88;}")
        vl = QtWidgets.QVBoxLayout(grp)

        mr = QtWidgets.QHBoxLayout()
        mr.addWidget(QtWidgets.QLabel("클릭 모드:"))
        self._mode_bg = QtWidgets.QButtonGroup(self)
        for i,(label,val) in enumerate([("일반","normal"),("바닥면 4점","floor"),("기준점","ref")]):
            rb = QtWidgets.QRadioButton(label)
            rb.setChecked(val=='normal')
            rb.toggled.connect(lambda ck,v=val: ck and setattr(self,'_mode',v))
            self._mode_bg.addButton(rb,i)
            mr.addWidget(rb)
        fc = QtWidgets.QPushButton("바닥점 초기화"); fc.setFixedWidth(100)
        fc.setStyleSheet("QPushButton{background:#2a1a00;color:#ffaa44;"
                         "border:1px solid #aa6600;border-radius:3px;font-size:10px;}"
                         "QPushButton:hover{background:#4a2a00;}")
        fc.clicked.connect(self._clear_floor)
        rc = QtWidgets.QPushButton("기준점 초기화"); rc.setFixedWidth(100)
        rc.setStyleSheet("QPushButton{background:#001a2a;color:#44aaff;"
                         "border:1px solid #006699;border-radius:3px;font-size:10px;}"
                         "QPushButton:hover{background:#002a3a;}")
        rc.clicked.connect(self._clear_ref)
        mr.addWidget(fc); mr.addWidget(rc); mr.addStretch()
        vl.addLayout(mr)

        # 4점 테이블
        tbl = QtWidgets.QGridLayout(); tbl.setSpacing(5)
        for c,txt in enumerate(["포인트","픽셀 좌표  (바닥면 모드 → 클릭)","뎁스 Z","실세계 X(m)","실세계 Y(m)"]):
            lbl = QtWidgets.QLabel(txt)
            lbl.setStyleSheet("color:#aaa;font-size:11px;font-weight:bold;")
            tbl.addWidget(lbl, 0, c)

        self._pt_px_lbl = []
        self._pt_dz_lbl = []  # ← 뎁스 표시 추가
        self._pt_wx_sp  = []
        self._pt_wy_sp  = []
        default_wx = [0.0, 1.0, 1.0, 0.0]
        default_wy = [0.0, 0.0, 1.0, 1.0]

        for i in range(4):
            bgr = PT_BGR[i]
            nl = QtWidgets.QLabel(PT_NAMES[i])
            nl.setStyleSheet(f"color:rgb({bgr[2]},{bgr[1]},{bgr[0]});"
                             "font-weight:bold;font-size:13px;")
            nl.setFixedWidth(28)
            tbl.addWidget(nl, i+1, 0)

            pl = QtWidgets.QLabel("(미설정)")
            pl.setStyleSheet("color:#666;font-family:monospace;font-size:11px;"
                             "background:#111;border:1px solid #333;padding:2px 6px;border-radius:3px;")
            pl.setFixedWidth(160)
            self._pt_px_lbl.append(pl)
            tbl.addWidget(pl, i+1, 1)

            # 뎁스 값 표시 레이블 (새로 추가)
            dz = QtWidgets.QLabel("Z: —")
            dz.setStyleSheet("color:#88aaff;font-family:monospace;font-size:11px;"
                             "background:#0a0a1a;border:1px solid #333;padding:2px 6px;border-radius:3px;")
            dz.setFixedWidth(100)
            self._pt_dz_lbl.append(dz)
            tbl.addWidget(dz, i+1, 2)

            wx = QtWidgets.QDoubleSpinBox()
            wx.setRange(-999,999); wx.setValue(default_wx[i])
            wx.setDecimals(3); wx.setSuffix(" m"); wx.setFixedWidth(110)
            self._pt_wx_sp.append(wx)
            tbl.addWidget(wx, i+1, 3)

            wy = QtWidgets.QDoubleSpinBox()
            wy.setRange(-999,999); wy.setValue(default_wy[i])
            wy.setDecimals(3); wy.setSuffix(" m"); wy.setFixedWidth(110)
            self._pt_wy_sp.append(wy)
            tbl.addWidget(wy, i+1, 4)

        vl.addLayout(tbl)

        # 호모그래피 계산 버튼 + 상태
        hr = QtWidgets.QHBoxLayout()
        hb = QtWidgets.QPushButton("호모그래피 계산  (픽셀 → 실세계 X,Y  +  바닥 평면 Z 자동)")
        hb.setFixedHeight(28)
        hb.setStyleSheet(
            "QPushButton{background:#1a2a4a;color:#aaccff;border:1px solid #4466aa;"
            "border-radius:4px;font-weight:bold;font-size:11px;}"
            "QPushButton:hover{background:#2a3a5a;}")
        hb.clicked.connect(self._compute_H)
        self._H_lbl = QtWidgets.QLabel("미계산  (4점 클릭 → 실세계 X,Y 입력 → 계산)")
        self._H_lbl.setStyleSheet("color:#888;font-size:10px;")
        hr.addWidget(hb); hr.addWidget(self._H_lbl); hr.addStretch()
        vl.addLayout(hr)

        self._ref_lbl = QtWidgets.QLabel("기준점: (미설정)  — 기준점 모드에서 이미지 클릭")
        self._ref_lbl.setStyleSheet("color:#88ccff;font-family:monospace;font-size:10px;")
        vl.addWidget(self._ref_lbl)
        return grp

    # 컬러 영상 패널
    def _image_panel(self):
        grp = QtWidgets.QGroupBox("컬러 영상  (클릭 → 좌표 설정)")
        grp.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        lay = QtWidgets.QVBoxLayout(grp)
        lay.setContentsMargins(2,2,2,2)
        self._img = ClickableLabel()
        self._img.setMinimumSize(640, 480)
        self._img.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        self._img.setStyleSheet("background:#111;color:#555;")
        self._img.setAlignment(Qt.AlignCenter)
        self._img.setText("연결 대기 중...")
        self._img.clicked_px.connect(self._on_click)
        lay.addWidget(self._img)
        return grp

    # 뎁스 그리드 패널
    def _grid_panel(self):
        grp = QtWidgets.QGroupBox(
            "뎁스 그리드  ■=바닥(녹)  ■=10cm↑(황)  ■=30cm↑(주)  ■=50cm↑(적)  □=뎁스없음")
        grp.setStyleSheet("QGroupBox{font-weight:bold;color:#aaddff;}")
        grp.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        lay = QtWidgets.QVBoxLayout(grp)
        lay.setContentsMargins(2,2,2,2)
        self._grid_lbl = QtWidgets.QLabel()
        self._grid_lbl.setMinimumSize(580, 480)
        self._grid_lbl.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        self._grid_lbl.setStyleSheet("background:#0a0a10;")
        self._grid_lbl.setAlignment(Qt.AlignCenter)
        self._grid_lbl.setText("연결 후 바닥 4점 설정 시 그리드 표시")
        lay.addWidget(self._grid_lbl)
        return grp

    # 결과 테이블
    def _result_panel(self):
        grp = QtWidgets.QGroupBox("감지 결과  (실세계 좌표 + 바닥 기준 높이 + 상대좌표)")
        grp.setMaximumHeight(240)
        lay = QtWidgets.QVBoxLayout(grp)
        lay.setContentsMargins(2,2,2,2)
        self._tbl = QtWidgets.QTableWidget(0, 9)
        self._tbl.setHorizontalHeaderLabels(
            ["클래스","감도","X(m)","Y(m)","Z뎁스(m)","바닥Z(m)","높이(cm)","ΔX(m)","ΔY(m)"])
        self._tbl.setStyleSheet(
            "QTableWidget{background:#0e0e1e;color:#cccccc;"
            "gridline-color:#333;font-family:monospace;font-size:22px;}"
            "QHeaderView::section{background:#1a1a2e;color:#88aaff;"
            "border:1px solid #333;font-size:16px;font-weight:bold;}")
        self._tbl.horizontalHeader().setStretchLastSection(True)
        self._tbl.horizontalHeader().setMinimumSectionSize(80)
        self._tbl.verticalHeader().setDefaultSectionSize(50)
        self._tbl.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self._tbl.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
        lay.addWidget(self._tbl)
        return grp

    # ── 클래스 패널 ───────────────────────────────────────────────────────────
    def _rebuild_class_panel(self, names):
        prev = {k: cb.isChecked() for k,cb in self._class_checks.items()}
        for i in reversed(range(self._cls_grid.count())):
            w = self._cls_grid.itemAt(i).widget()
            if w: w.deleteLater()
        self._class_checks.clear()
        COLS = 5
        for idx, name in enumerate(names):
            cb = QtWidgets.QCheckBox(name)
            cb.setChecked(prev.get(name, True)); cb.setMinimumWidth(100)
            cb.setStyleSheet(
                "QCheckBox{color:#e8ffe8;font-size:13px;font-weight:bold;"
                "padding:4px 8px;background:#141414;border:1px solid #333;border-radius:4px;}"
                "QCheckBox:hover{background:#1e2e1e;border:1px solid #44aa66;}"
                "QCheckBox::indicator{width:18px;height:18px;}"
                "QCheckBox::indicator:checked{background:#22aa44;border:2px solid #66dd88;border-radius:4px;}"
                "QCheckBox::indicator:unchecked{background:#1a1a1a;border:2px solid #555;border-radius:4px;}")
            self._cls_grid.addWidget(cb, idx//COLS, idx%COLS)
            self._class_checks[name] = cb
        self._cls_info.setText(f"총 {len(names)}개 클래스")
        self._cls_info.setStyleSheet("color:#88ffcc;font-size:11px;font-weight:bold;")

    def _allowed(self):
        return {k for k,cb in self._class_checks.items() if cb.isChecked()}

    def _sel_all(self):
        for cb in self._class_checks.values(): cb.setChecked(True)

    def _sel_none(self):
        for cb in self._class_checks.values(): cb.setChecked(False)

    # ── 바닥 평면 피팅 ────────────────────────────────────────────────────────
    def _fit_floor_plane(self):
        """4점 (u,v,depth_z)로 바닥 평면 피팅: depth = a*u + b*v + c"""
        pts = self._floor_pts
        if len(pts) < 3:
            self._floor_abc = None; return
        A = np.array([[p['u'], p['v'], 1.0] for p in pts], dtype=np.float64)
        b = np.array([p['depth_z'] for p in pts], dtype=np.float64)
        coeffs, _, _, _ = np.linalg.lstsq(A, b, rcond=None)
        self._floor_abc = tuple(coeffs)
        pred = A @ coeffs
        rms = float(np.sqrt(((pred - b)**2).mean()))
        return rms

    def _floor_depth(self, u, v):
        """바닥 평면 모델에서 픽셀(u,v)의 예상 뎁스(m). 없으면 None."""
        if self._floor_abc is None:
            return None
        a,b,c = self._floor_abc
        return a*u + b*v + c

    def _height_above_floor(self, u, v, actual_z=None):
        """바닥 위 높이(m). 양수=바닥 위, 0=바닥면. None=계산 불가."""
        fd = self._floor_depth(u, v)
        if fd is None:
            return None
        if actual_z is None:
            with self._dlk:
                depth = self._depth_frame
            actual_z = read_depth_at(depth, u, v)
        if actual_z is None:
            return None
        return fd - actual_z   # 바닥이 카메라에서 더 멀기 때문에 fd > actual_z = 위에 있는 것

    # ── 호모그래피 계산 ───────────────────────────────────────────────────────
    def _compute_H(self):
        if len(self._floor_pts) < 4:
            self._H_lbl.setText(f"오류: 4점 필요 (현재 {len(self._floor_pts)}점)")
            self._H_lbl.setStyleSheet("color:#ff8888;font-size:10px;")
            return

        px_pts = np.array([[p['u'],p['v']] for p in self._floor_pts[:4]], dtype=np.float32)
        wx_pts = np.array([
            [self._pt_wx_sp[i].value(), self._pt_wy_sp[i].value()]
            for i in range(4)
        ], dtype=np.float32)

        H, _ = cv2.findHomography(px_pts, wx_pts, cv2.RANSAC)
        if H is None:
            self._H_lbl.setText("계산 실패 (4점 공선 불가)")
            self._H_lbl.setStyleSheet("color:#ff8888;font-size:10px;")
            return
        self._H = H

        proj = cv2.perspectiveTransform(px_pts.reshape(-1,1,2), H).reshape(-1,2)
        rms_h = float(np.sqrt(((proj - wx_pts)**2).sum(axis=1).mean()))

        # 바닥 평면도 피팅
        rms_f = self._fit_floor_plane()

        msg = f"✅ 호모그래피 RMS={rms_h:.4f}m"
        if rms_f is not None:
            msg += f"  |  바닥평면 RMS={rms_f:.4f}m"
        self._H_lbl.setText(msg)
        self._H_lbl.setStyleSheet("color:#88ff88;font-size:10px;font-weight:bold;")

    # ── 3D 좌표 계산 ─────────────────────────────────────────────────────────
    def _get_3d(self, u, v):
        """픽셀(u,v) → (X,Y,Z). X,Y=호모그래피, Z=뎁스이미지. 실패 시 None."""
        if self._H is None:
            return None

        # X, Y — 호모그래피
        pt  = np.array([[[float(u),float(v)]]], dtype=np.float32)
        wpt = cv2.perspectiveTransform(pt, self._H)
        X, Y = float(wpt[0,0,0]), float(wpt[0,0,1])

        # Z — 뎁스 이미지 (폴백 없음: 읽지 못하면 None 반환)
        with self._dlk:
            depth = self._depth_frame
        Z = read_depth_at(depth, u, v)
        # Z가 None이어도 X,Y는 유효하므로 반환 (Z=None 포함)
        return (X, Y, Z)

    def _relative(self, xyz):
        if self._ref_uvxyz is None or xyz is None:
            return None
        rx,ry,rz = self._ref_uvxyz[2], self._ref_uvxyz[3], self._ref_uvxyz[4]
        x,y,z    = xyz
        dz = (z - rz) if (z is not None and rz is not None) else None
        return (x-rx, y-ry, dz)

    # ── 클릭 핸들러 ───────────────────────────────────────────────────────────
    def _on_click(self, u: int, v: int):
        if self._mode == 'floor':
            # ★ FIX: 뎁스 먼저 읽기 — 없으면 에러 표시 후 리턴
            with self._dlk:
                depth = self._depth_frame
            depth_z = read_depth_at(depth, u, v)

            if depth_z is None:
                reason = "뎁스 이미지 미연결" if depth is None else f"픽셀({u},{v}) 뎁스 없음"
                QtWidgets.QMessageBox.warning(
                    self, "뎁스 읽기 실패",
                    f"{reason}\n유효 범위(0.05 ~ 30.0m) 밖이거나 뎁스가 없는 영역입니다.\n"
                    "다른 위치를 클릭하세요.")
                return

            if len(self._floor_pts) >= 4:
                self._floor_pts.clear()
                self._floor_abc = None; self._H = None
                for lbl in self._pt_px_lbl:
                    lbl.setText("(미설정)")
                    lbl.setStyleSheet("color:#666;font-family:monospace;font-size:11px;"
                                     "background:#111;border:1px solid #333;padding:2px 6px;border-radius:3px;")
                for lbl in self._pt_dz_lbl:
                    lbl.setText("Z: —")
                    lbl.setStyleSheet("color:#88aaff;font-family:monospace;font-size:11px;"
                                     "background:#0a0a1a;border:1px solid #333;padding:2px 6px;border-radius:3px;")
                self._H_lbl.setText("초기화됨")
                self._H_lbl.setStyleSheet("color:#888;font-size:10px;")

            i = len(self._floor_pts)
            self._floor_pts.append({'u': u, 'v': v, 'depth_z': depth_z})

            bgr = PT_BGR[i]
            self._pt_px_lbl[i].setText(f"u={u},  v={v}")
            self._pt_px_lbl[i].setStyleSheet(
                f"color:rgb({bgr[2]},{bgr[1]},{bgr[0]});font-family:monospace;"
                "font-size:11px;font-weight:bold;background:#111;border:1px solid #555;"
                "padding:2px 6px;border-radius:3px;")
            self._pt_dz_lbl[i].setText(f"Z: {depth_z:.3f}m")
            self._pt_dz_lbl[i].setStyleSheet(
                "color:#aaddff;font-family:monospace;font-size:11px;font-weight:bold;"
                "background:#0a0a1a;border:1px solid #4466aa;padding:2px 6px;border-radius:3px;")

        elif self._mode == 'ref':
            result = self._get_3d(u, v)
            if result is None:
                QtWidgets.QMessageBox.warning(self,"경고","먼저 호모그래피를 계산하세요.")
                return
            X, Y, Z = result
            if Z is None:
                QtWidgets.QMessageBox.warning(self,"경고",
                    f"픽셀({u},{v})에서 뎁스를 읽을 수 없습니다.\n기준점 설정 불가.")
                return
            self._ref_uvxyz = (u, v, X, Y, Z)
            self._ref_lbl.setText(
                f"기준점  픽셀({u},{v})  →  X={X:.3f}m  Y={Y:.3f}m  Z={Z:.3f}m")
            self._ref_lbl.setStyleSheet(
                "color:#44ccff;font-family:monospace;font-size:10px;font-weight:bold;")

    def _clear_floor(self):
        self._floor_pts.clear(); self._floor_abc = None; self._H = None
        for lbl in self._pt_px_lbl:
            lbl.setText("(미설정)")
            lbl.setStyleSheet("color:#666;font-family:monospace;font-size:11px;"
                             "background:#111;border:1px solid #333;padding:2px 6px;border-radius:3px;")
        for lbl in self._pt_dz_lbl:
            lbl.setText("Z: —")
            lbl.setStyleSheet("color:#88aaff;font-family:monospace;font-size:11px;"
                             "background:#0a0a1a;border:1px solid #333;padding:2px 6px;border-radius:3px;")
        self._H_lbl.setText("초기화됨"); self._H_lbl.setStyleSheet("color:#888;font-size:10px;")

    def _clear_ref(self):
        self._ref_uvxyz = None
        self._ref_lbl.setText("기준점: (미설정)")
        self._ref_lbl.setStyleSheet("color:#88ccff;font-family:monospace;font-size:10px;")

    # ── ROS2 연결 ─────────────────────────────────────────────────────────────
    def _connect(self):
        if not ROS2_AVAILABLE:
            QtWidgets.QMessageBox.warning(self,"경고","rclpy를 찾을 수 없습니다."); return
        self._disconnect()
        self.ros2_sub = Ros2DepthSub()
        self.ros2_sub.color_rx.connect(self._on_color)
        self.ros2_sub.depth_rx.connect(self._on_depth)
        self.ros2_sub.start()
        self._conn_btn.setEnabled(False); self._disc_btn.setEnabled(True)
        self._conn_lbl.setText("연결됨  ✅"); self._conn_lbl.setStyleSheet("color:#88ff88;font-size:10px;")
        self.timer.start(33)
        self._grid_timer.start(self._grid_interval_sp.value())

    def _disconnect(self):
        self.timer.stop()
        self._grid_timer.stop()
        if self.ros2_sub: self.ros2_sub.stop(); self.ros2_sub = None
        with self._clk: self._color_frame = None
        with self._dlk: self._depth_frame = None
        self._conn_btn.setEnabled(True); self._disc_btn.setEnabled(False)
        self._conn_lbl.setText("미연결"); self._conn_lbl.setStyleSheet("color:#888;font-size:10px;")
        self._img.clear(); self._img.setText("연결 해제됨")

    def _on_color(self, frame):
        with self._clk: self._color_frame = frame.copy()
        self._img.set_src(frame.shape[1], frame.shape[0])

    def _on_depth(self, depth):
        with self._dlk: self._depth_frame = depth.copy()

    def _on_conf(self, v):
        self.conf = v/100.0; self._conf_lbl.setText(f"{self.conf:.2f}")

    def _on_resize(self):
        self._img.setMinimumSize(self._dw_sp.value(), self._dh_sp.value())

    # ── 추론 루프 ─────────────────────────────────────────────────────────────
    def _tick(self):
        with self._clk:
            frame = self._color_frame
        if frame is None:
            return

        allowed = self._allowed()
        dets = []
        if self.model and allowed:
            try:
                for d in run_inference(self.model, frame, self.conf, allowed):
                    xyz = self._get_3d(d['cx'], d['cy'])
                    ht  = None
                    if xyz and xyz[2] is not None:
                        ht = self._height_above_floor(d['cx'], d['cy'], xyz[2])
                    rel = self._relative(xyz)
                    dets.append({**d, 'xyz': xyz, 'ht': ht, 'rel': rel})
            except Exception as e:
                print(f"[추론] {e}")
        self._detections = dets

        vis = self._draw_color(frame.copy(), dets)
        dw = max(self._img.width(), 640)
        dh = max(self._img.height(), 480)
        self._img.setPixmap(to_pixmap(vis, dw, dh))

        self._upd_table(dets)

    def _update_grid(self):
        grid_img = self._draw_depth_grid()
        gw, gh = self._grid_lbl.width(), self._grid_lbl.height()
        self._grid_lbl.setPixmap(to_pixmap(grid_img, gw, gh))

    # ── 컬러 영상 오버레이 ────────────────────────────────────────────────────
    def _draw_color(self, vis, dets):
        col = (0, 255, 160)
        for d in dets:
            if d['type'] == 'obb':
                cv2.polylines(vis, [d['corners']], True, col, 2)
            else:
                cv2.rectangle(vis,(int(d['x1']),int(d['y1'])),
                              (int(d['x2']),int(d['y2'])), col, 2)
            y0 = max(int(d['y1'])-22, 14)
            cv2.putText(vis, f"{d['label']} {d['conf']:.2f}",
                        (int(d['x1']),y0), cv2.FONT_HERSHEY_SIMPLEX, 0.5, col, 1)
            xyz = d['xyz']; ht = d['ht']
            if xyz:
                X,Y,Z = xyz
                line2 = (f"X:{X:.2f} Y:{Y:.2f}"
                         + (f" Z:{Z:.2f}m" if Z is not None else " Z:없음")
                         + (f"  높이:{ht*100:.1f}cm" if ht is not None else ""))
                cv2.putText(vis, line2,(int(d['x1']),y0+16),
                            cv2.FONT_HERSHEY_SIMPLEX,0.4,(180,255,180),1)

        for i,p in enumerate(self._floor_pts):
            bgr=PT_BGR[i]; u,v=p['u'],p['v']
            cv2.circle(vis,(u,v),9,bgr,-1)
            cv2.circle(vis,(u,v),11,(255,255,255),1)
            cv2.putText(vis, f"{PT_NAMES[i]} Z={p['depth_z']:.2f}m",
                        (u+12,v+5),cv2.FONT_HERSHEY_SIMPLEX,0.4,bgr,1)
        n = len(self._floor_pts)
        pts_px = [(p['u'],p['v']) for p in self._floor_pts]
        for j in range(n):
            cv2.line(vis, pts_px[j], pts_px[(j+1)%n], (200,200,60),1)

        if self._ref_uvxyz:
            ru,rv = self._ref_uvxyz[0], self._ref_uvxyz[1]
            cv2.drawMarker(vis,(ru,rv),(0,200,255),cv2.MARKER_CROSS,20,2)
            cv2.circle(vis,(ru,rv),12,(0,200,255),1)
            cv2.putText(vis,"REF",(ru+14,rv+5),cv2.FONT_HERSHEY_SIMPLEX,0.45,(0,200,255),1)

        if self._H is None:
            cv2.putText(vis,"[호모그래피 미계산]",(10,22),
                        cv2.FONT_HERSHEY_SIMPLEX,0.5,(80,80,255),1)
        hints={"floor":"▶ 바닥면 클릭 (P1→P4, 4점↑리셋)","ref":"▶ 기준점 클릭"}
        if self._mode in hints:
            cv2.putText(vis,hints[self._mode],(10,vis.shape[0]-10),
                        cv2.FONT_HERSHEY_SIMPLEX,0.55,(0,220,255),2)
        return vis

    # ── 뎁스 그리드 렌더링 ────────────────────────────────────────────────────
    def _draw_depth_grid(self):
        GW, GH = self._grid_lbl.width(), self._grid_lbl.height()
        if GW <= 0 or GH <= 0:
            GW, GH = 580, 480

        with self._dlk:
            depth = self._depth_frame

        # ── base: 실제 뎁스 이미지 컬러맵 (유효=TURBO, 무효=검정) ──────────
        base = np.zeros((GH, GW, 3), dtype=np.uint8)
        if depth is None:
            cv2.putText(base,"뎁스 미연결",(GW//4,GH//2),
                        cv2.FONT_HERSHEY_SIMPLEX,0.8,(100,100,200),2)
            return base

        dh, dw = depth.shape
        valid_mask = (depth > 0.05) & (depth < 30.0)
        d_norm = np.zeros((dh, dw), dtype=np.uint8)
        if valid_mask.any():
            d_min = float(depth[valid_mask].min())
            d_max = float(depth[valid_mask].max())
            if d_max > d_min:
                d_norm[valid_mask] = (
                    (depth[valid_mask] - d_min) / (d_max - d_min) * 255
                ).astype(np.uint8)
            else:
                d_norm[valid_mask] = 128
        colored = cv2.applyColorMap(d_norm, cv2.COLORMAP_TURBO)
        colored[~valid_mask] = 0  # 무효 = 검정
        base = cv2.resize(colored, (GW, GH), interpolation=cv2.INTER_LINEAR)

        # ── overlay: 높이 기반 색상 셀 (base 복사 후 셀만 채움) ─────────────
        overlay = base.copy()

        COLS = self._gcols.value()
        ROWS = self._grows.value()
        cw = GW // COLS
        ch = GH // ROWS
        has_floor = self._floor_abc is not None

        for row in range(ROWS):
            for col in range(COLS):
                u = int((col + 0.5) * dw / COLS)
                v = int((row + 0.5) * dh / ROWS)
                gx = col * cw
                gy = row * ch

                actual_z = read_depth_at(depth, u, v)
                floor_z  = self._floor_depth(u, v)

                if actual_z is None:
                    # 무효 — 검정 유지 (overlay도 base가 검정이므로 그대로)
                    pass
                else:
                    if has_floor and floor_z is not None:
                        height_m = floor_z - actual_z
                        ht_cm = height_m * 100
                        if height_m < -0.03:
                            cell_col, label, tc = (30,30,55), f"{ht_cm:.0f}?", (80,80,120)
                        elif height_m < 0.03:
                            cell_col, label, tc = (10,80,20), f"FL {actual_z:.2f}", (120,255,140)
                        elif height_m < 0.10:
                            t = int(height_m/0.10 * 200)
                            cell_col, label, tc = (0,80+t,10), f"{ht_cm:.0f}cm", (200,255,200)
                        elif height_m < 0.30:
                            t = int((height_m-0.10)/0.20 * 255)
                            cell_col, label, tc = (0,255-t,t), f"{ht_cm:.0f}cm", (255,255,200)
                        elif height_m < 0.50:
                            t = int((height_m-0.30)/0.20 * 200)
                            cell_col, label, tc = (0,50,130+t), f"{ht_cm:.0f}cm", (255,200,150)
                        else:
                            cell_col, label, tc = (20,20,200), f"{ht_cm:.0f}cm", (200,150,255)
                        cv2.rectangle(overlay,(gx+1,gy+1),(gx+cw-1,gy+ch-1),cell_col,-1)
                        cv2.putText(overlay,label,(gx+3,gy+ch//2+4),
                                    cv2.FONT_HERSHEY_SIMPLEX,0.32,tc,1)
                        cv2.putText(overlay,f"d{actual_z:.2f}",(gx+3,gy+ch-4),
                                    cv2.FONT_HERSHEY_SIMPLEX,0.28,(160,160,180),1)
                    else:
                        cv2.putText(overlay,f"{actual_z:.2f}m",(gx+3,gy+ch//2+4),
                                    cv2.FONT_HERSHEY_SIMPLEX,0.32,(220,220,220),1)

                cv2.rectangle(overlay,(gx,gy),(gx+cw,gy+ch),(50,55,75),1)

        # ── 블렌딩: 뎁스 컬러맵 50% + 높이오버레이 50% ───────────────────────
        img = cv2.addWeighted(base, 0.5, overlay, 0.5, 0)

        # ── 바닥 포인트 마커 ─────────────────────────────────────────────────
        for i,p in enumerate(self._floor_pts):
            bgr = PT_BGR[i]
            gx_dot = int(p['u'] / dw * GW)
            gy_dot = int(p['v'] / dh * GH)
            cv2.circle(img,(gx_dot,gy_dot),6,bgr,-1)
            cv2.circle(img,(gx_dot,gy_dot),8,(255,255,255),1)
            cv2.putText(img,PT_NAMES[i],(gx_dot+9,gy_dot+4),
                        cv2.FONT_HERSHEY_SIMPLEX,0.38,bgr,1)

        # ── 범례 ────────────────────────────────────────────────────────────
        legend_y = GH - 14
        items = [((10,80,20),"바닥"), ((0,200,100),"10cm"),
                 ((0,100,200),"30cm"), ((20,20,200),"50cm+")]
        lx = 4
        for c,lbl in items:
            cv2.rectangle(img,(lx,legend_y-10),(lx+12,legend_y),c,-1)
            cv2.putText(img,lbl,(lx+14,legend_y),cv2.FONT_HERSHEY_SIMPLEX,0.3,(200,200,200),1)
            lx += 60

        if not has_floor:
            cv2.putText(img,"바닥 4점 설정 후 호모그래피 계산 시 높이 표시",
                        (4,20),cv2.FONT_HERSHEY_SIMPLEX,0.38,(240,240,100),1)
        return img

    # ── 결과 테이블 ───────────────────────────────────────────────────────────
    def _upd_table(self, dets):
        self._tbl.setRowCount(len(dets))
        for r,d in enumerate(dets):
            xyz=d['xyz']; ht=d['ht']; rel=d['rel']
            X,Y,Z = xyz if xyz else (None,None,None)
            fd = self._floor_depth(d['cx'],d['cy']) if self._floor_abc else None
            for c,v in enumerate([
                d['label'],
                f"{d['conf']:.2f}",
                f"{X:.3f}" if X is not None else "—",
                f"{Y:.3f}" if Y is not None else "—",
                f"{Z:.3f}" if Z is not None else "뎁스없음",
                f"{fd:.3f}" if fd is not None else "—",
                f"{ht*100:.1f}" if ht is not None else "—",
                f"{rel[0]:+.3f}" if rel else "—",
                f"{rel[1]:+.3f}" if rel else "—",
            ]):
                it = QtWidgets.QTableWidgetItem(v)
                it.setTextAlignment(Qt.AlignCenter)
                # 높이 열 색상 강조
                if c == 6 and ht is not None:
                    if ht > 0.30: it.setForeground(QtGui.QColor(255,100,100))
                    elif ht > 0.10: it.setForeground(QtGui.QColor(255,200,100))
                    elif ht > 0.03: it.setForeground(QtGui.QColor(200,255,150))
                self._tbl.setItem(r,c,it)

    # ── 모델 관리 ─────────────────────────────────────────────────────────────
    def _refresh_models(self):
        files = list_pt_files()
        self._mdl_combo.clear(); self._mdl_combo.addItems(files)

    def _load_model(self):
        rel = self._mdl_combo.currentText()
        if not rel: return
        self.sig_mdl_st.emit("로드 중...","#888888")
        threading.Thread(target=self._do_load, args=(rel,), daemon=True).start()

    def _do_load(self, rel):
        from ultralytics import YOLO
        try:
            m = YOLO(str(WEIGHTS_DIR/rel))
            names = list(m.names.values())
            self.model = m
            self.sig_classes.emit(names)
            self.sig_mdl_st.emit(f"✅ {rel}  ({len(names)}cls)","#aaaaff")
        except Exception as e:
            self.sig_error.emit(str(e))

    def closeEvent(self, ev):
        self._disconnect(); ev.accept()


if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    win = InferenceDepthUI()
    win.showMaximized()
    sys.exit(app.exec_())
