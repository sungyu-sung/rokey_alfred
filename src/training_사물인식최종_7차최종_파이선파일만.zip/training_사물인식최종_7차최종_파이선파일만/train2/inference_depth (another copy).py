#!/usr/bin/env python3
"""inference_depth.py — YOLO 추론 + RGB-D 3D 좌표 계산

토픽 (고정):
  /camera/color/image_raw  — 컬러
  /camera/depth/image_raw  — 뎁스 (16UC1 mm / 32FC1 m)

좌표 계산:
  P1~P4 픽셀 좌표(마우스 클릭) + 실세계 X,Y(m) 입력
  → cv2.findHomography 로 픽셀→실세계 변환 행렬 계산
  → 감지된 사물 픽셀을 실세계 X,Y로 변환 + 뎁스에서 Z 추출
"""
import os, sys, threading
os.environ['QT_QPA_PLATFORM_PLUGIN_PATH'] = '/usr/lib/x86_64-linux-gnu/qt5/plugins'
os.environ['QT_QPA_PLATFORM'] = 'wayland'

import cv2
import numpy as np
from pathlib import Path
from threading import Lock

from PyQt5 import QtWidgets, QtCore, QtGui
from PyQt5.QtCore import Qt, pyqtSignal, QThread, QTimer

WEIGHTS_DIR = Path("/home/han3/turtlebot4_ws/src/training/weights")
COLOR_TOPIC = "/camera/color/image_raw"
DEPTH_TOPIC = "/camera/depth/image_raw"
PT_BGR   = [(0,255,80), (255,128,0), (0,200,255), (255,0,200)]
PT_NAMES = ["P1", "P2", "P3", "P4"]

try:
    import rclpy
    from sensor_msgs.msg import Image
    from cv_bridge import CvBridge
    ROS2_AVAILABLE = True
except ImportError:
    ROS2_AVAILABLE = False


# ── ROS2 구독 ──────────────────────────────────────────────────────────────────
class Ros2DepthSub(QThread):
    color_rx = pyqtSignal(object)
    depth_rx = pyqtSignal(object)

    def __init__(self):
        super().__init__()
        self._stop  = threading.Event()
        self.bridge = CvBridge()

    def run(self):
        if not rclpy.ok():
            rclpy.init()
        node = rclpy.create_node('inf_depth_node')
        node.create_subscription(Image, COLOR_TOPIC, self._cb_color, 10)
        node.create_subscription(Image, DEPTH_TOPIC, self._cb_depth, 10)
        while not self._stop.is_set() and rclpy.ok():
            rclpy.spin_once(node, timeout_sec=0.05)
        node.destroy_node()

    def _cb_color(self, msg):
        try:
            self.color_rx.emit(self.bridge.imgmsg_to_cv2(msg, 'bgr8'))
        except Exception:
            pass

    def _cb_depth(self, msg):
        try:
            if msg.encoding == '32FC1':
                d = np.frombuffer(msg.data, dtype=np.float32).reshape(
                    msg.height, msg.width).copy()
            else:
                d = np.frombuffer(msg.data, dtype=np.uint16).reshape(
                    msg.height, msg.width).astype(np.float32) / 1000.0
            self.depth_rx.emit(d)
        except Exception:
            pass

    def stop(self):
        self._stop.set(); self.wait(2000)


# ── 클릭 가능한 이미지 레이블 ─────────────────────────────────────────────────
class ClickableLabel(QtWidgets.QLabel):
    clicked_px = pyqtSignal(int, int)

    def __init__(self):
        super().__init__()
        self._sw = 640; self._sh = 480
        self.setCursor(Qt.CrossCursor)

    def set_src(self, w, h):
        self._sw, self._sh = max(1,w), max(1,h)

    def _map(self, lx, ly):
        lw, lh = self.width(), self.height()
        s = min(lw/self._sw, lh/self._sh)
        dw, dh = self._sw*s, self._sh*s
        rx, ry = lx-(lw-dw)/2, ly-(lh-dh)/2
        if 0 <= rx < dw and 0 <= ry < dh:
            return int(rx*self._sw/dw), int(ry*self._sh/dh)
        return None

    def mousePressEvent(self, ev):
        if ev.button() == Qt.LeftButton:
            r = self._map(ev.x(), ev.y())
            if r:
                self.clicked_px.emit(*r)
        super().mousePressEvent(ev)


# ── 유틸 ──────────────────────────────────────────────────────────────────────
def list_pt_files():
    if not WEIGHTS_DIR.exists():
        return []
    return [str(f.relative_to(WEIGHTS_DIR)) for f in sorted(WEIGHTS_DIR.rglob("*.pt"))]


def run_inference(model, frame, conf, allowed):
    out = []
    for r in model.predict(frame, conf=conf, verbose=False):
        if r.boxes is not None and len(r.boxes):
            for box in r.boxes:
                lbl = model.names[int(box.cls[0])]
                if lbl not in allowed:
                    continue
                x1,y1,x2,y2 = box.xyxy[0].tolist()
                out.append({'label':lbl,'conf':float(box.conf[0]),
                            'cx':int((x1+x2)/2),'cy':int((y1+y2)/2),
                            'x1':x1,'y1':y1,'x2':x2,'y2':y2,'type':'det'})
        elif r.obb is not None and len(r.obb):
            for box in r.obb:
                lbl = model.names[int(box.cls[0])]
                if lbl not in allowed:
                    continue
                corners = box.xyxyxyxy[0].cpu().numpy().astype(int)
                mn,mx = corners.min(0),corners.max(0)
                out.append({'label':lbl,'conf':float(box.conf[0]),
                            'cx':int((mn[0]+mx[0])/2),'cy':int((mn[1]+mx[1])/2),
                            'x1':mn[0],'y1':mn[1],'x2':mx[0],'y2':mx[1],
                            'corners':corners,'type':'obb'})
    return out


def to_pixmap(frame, w, h):
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    fh,fw,ch = rgb.shape
    qi = QtGui.QImage(rgb.data, fw,fh,ch*fw, QtGui.QImage.Format_RGB888)
    return QtGui.QPixmap.fromImage(qi).scaled(w,h,Qt.KeepAspectRatio,Qt.SmoothTransformation)


# ── 메인 UI ───────────────────────────────────────────────────────────────────
class InferenceDepthUI(QtWidgets.QWidget):
    sig_classes = pyqtSignal(list)
    sig_mdl_st  = pyqtSignal(str, str)
    sig_error   = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        self.model        = None
        self.ros2_sub     = None
        self._clk         = Lock()
        self._dlk         = Lock()
        self._color_frame = None
        self._depth_frame = None
        self.conf         = 0.40
        self._floor_pts   = []       # {u,v}  (최대 4)
        self._ref_uvxyz   = None     # (u,v,X,Y,Z)
        self._mode        = 'normal'
        self._H           = None     # 호모그래피 행렬
        self._class_checks: dict[str, QtWidgets.QCheckBox] = {}
        self._detections  = []

        self._init_ui()
        self.sig_classes.connect(self._rebuild_class_panel)
        self.sig_mdl_st.connect(lambda t,c:(
            self._mdl_lbl.setText(t),
            self._mdl_lbl.setStyleSheet(f"color:{c};font-size:10px;")))
        self.sig_error.connect(lambda m: QtWidgets.QMessageBox.critical(self,"오류",m))
        self._refresh_models()
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._tick)

    # ── UI ────────────────────────────────────────────────────────────────────
    def _init_ui(self):
        self.setWindowTitle("YOLO Depth 추론  [4점 호모그래피 + RGB-D]")
        self.setMinimumSize(1080, 980)
        root = QtWidgets.QVBoxLayout(self)
        root.setSpacing(4); root.setContentsMargins(5,5,5,5)
        root.addLayout(self._top_row())
        root.addWidget(self._class_panel())
        root.addWidget(self._floor_panel())
        root.addWidget(self._image_panel())
        root.addWidget(self._result_panel())

    # 행1: 연결 | 모델 | 설정
    def _top_row(self):
        row = QtWidgets.QHBoxLayout()

        # 연결
        cg = QtWidgets.QGroupBox("ROS2 연결 (고정 토픽)")
        cl = QtWidgets.QVBoxLayout(cg)
        cl.addWidget(QtWidgets.QLabel(f"색상: {COLOR_TOPIC}"))
        cl.addWidget(QtWidgets.QLabel(f"뎁스: {DEPTH_TOPIC}"))
        br = QtWidgets.QHBoxLayout()
        self._conn_btn = QtWidgets.QPushButton("연결")
        self._conn_btn.setStyleSheet(
            "QPushButton{background:#1a5a1a;color:#88ff88;font-weight:bold;"
            "border:1px solid #336633;border-radius:3px;}"
            "QPushButton:hover{background:#2a7a2a;}")
        self._conn_btn.clicked.connect(self._connect)
        self._disc_btn = QtWidgets.QPushButton("해제")
        self._disc_btn.setEnabled(False)
        self._disc_btn.clicked.connect(self._disconnect)
        br.addWidget(self._conn_btn); br.addWidget(self._disc_btn)
        cl.addLayout(br)
        self._conn_lbl = QtWidgets.QLabel("미연결")
        self._conn_lbl.setStyleSheet("color:#888;font-size:10px;")
        cl.addWidget(self._conn_lbl)
        cg.setFixedWidth(260)
        row.addWidget(cg)

        # 모델
        mg = QtWidgets.QGroupBox("모델")
        ml = QtWidgets.QVBoxLayout(mg)
        self._mdl_combo = QtWidgets.QComboBox()
        lb = QtWidgets.QPushButton("로드")
        lb.setStyleSheet(
            "QPushButton{background:#2a2a4a;color:#aaaaff;border:1px solid #6666ff;"
            "border-radius:3px;font-weight:bold;}"
            "QPushButton:hover{background:#3a3a6a;}")
        lb.clicked.connect(self._load_model)
        self._mdl_lbl = QtWidgets.QLabel("미로드")
        self._mdl_lbl.setStyleSheet("color:#888;font-size:10px;")
        self._mdl_lbl.setWordWrap(True)
        sr = QtWidgets.QHBoxLayout()
        sr.addWidget(QtWidgets.QLabel("감도:"))
        self._conf_sl = QtWidgets.QSlider(Qt.Horizontal)
        self._conf_sl.setRange(5,95); self._conf_sl.setValue(40)
        self._conf_sl.setStyleSheet(
            "QSlider::groove:horizontal{height:6px;background:#333;border-radius:3px;}"
            "QSlider::handle:horizontal{width:14px;height:14px;margin:-4px 0;"
            "background:#aaaaff;border-radius:7px;}"
            "QSlider::sub-page:horizontal{background:#aaaaff;border-radius:3px;}")
        self._conf_lbl = QtWidgets.QLabel("0.40")
        self._conf_lbl.setFixedWidth(34)
        self._conf_lbl.setStyleSheet("color:#aaaaff;font-weight:bold;")
        self._conf_sl.valueChanged.connect(self._on_conf)
        sr.addWidget(self._conf_sl); sr.addWidget(self._conf_lbl)
        ml.addWidget(self._mdl_combo); ml.addWidget(lb)
        ml.addWidget(self._mdl_lbl); ml.addLayout(sr)
        row.addWidget(mg)

        # 표시/기타
        og = QtWidgets.QGroupBox("표시 설정")
        ol = QtWidgets.QFormLayout(og)
        rb = QtWidgets.QPushButton("↺ 모델 목록")
        rb.clicked.connect(self._refresh_models)
        ol.addRow("", rb)
        self._h_sp = QtWidgets.QDoubleSpinBox()
        self._h_sp.setRange(1,500); self._h_sp.setValue(150)
        self._h_sp.setSuffix(" cm"); self._h_sp.setFixedWidth(90)
        self._h_sp.setToolTip("뎁스 이미지 없을 때 Z 추정에 사용")
        ol.addRow("카메라 높이(뎁스 없을때):", self._h_sp)
        self._dw_sp = QtWidgets.QSpinBox()
        self._dw_sp.setRange(320,1920); self._dw_sp.setSingleStep(32)
        self._dw_sp.setValue(900); self._dw_sp.valueChanged.connect(self._on_resize)
        ol.addRow("표시 너비:", self._dw_sp)
        self._dh_sp = QtWidgets.QSpinBox()
        self._dh_sp.setRange(240,1080); self._dh_sp.setSingleStep(32)
        self._dh_sp.setValue(600); self._dh_sp.valueChanged.connect(self._on_resize)
        ol.addRow("표시 높이:", self._dh_sp)
        row.addWidget(og)
        return row

    # 클래스 선택 패널
    def _class_panel(self):
        grp = QtWidgets.QGroupBox("사물 클래스 선택  (체크된 클래스만 인식)")
        grp.setStyleSheet("QGroupBox{font-weight:bold;color:#88ffcc;}")
        outer = QtWidgets.QVBoxLayout(grp)
        br = QtWidgets.QHBoxLayout()
        ab = QtWidgets.QPushButton("전체 선택"); ab.setFixedWidth(90)
        ab.setStyleSheet("QPushButton{background:#1a3a1a;color:#88ff88;"
                         "border:1px solid #336633;border-radius:3px;font-size:11px;}"
                         "QPushButton:hover{background:#2a5a2a;}")
        ab.clicked.connect(self._sel_all)
        nb = QtWidgets.QPushButton("전체 해제"); nb.setFixedWidth(90)
        nb.setStyleSheet("QPushButton{background:#3a1a1a;color:#ff8888;"
                         "border:1px solid #663333;border-radius:3px;font-size:11px;}"
                         "QPushButton:hover{background:#5a2a2a;}")
        nb.clicked.connect(self._sel_none)
        self._cls_info = QtWidgets.QLabel("모델 로드 후 표시")
        self._cls_info.setStyleSheet("color:#666;font-size:10px;")
        br.addWidget(ab); br.addWidget(nb); br.addWidget(self._cls_info); br.addStretch()
        outer.addLayout(br)
        scroll = QtWidgets.QScrollArea(); scroll.setWidgetResizable(True)
        scroll.setMaximumHeight(120)
        scroll.setStyleSheet("QScrollArea{border:1px solid #333;background:#0a0a0a;border-radius:4px;}")
        self._cls_cont = QtWidgets.QWidget()
        self._cls_cont.setStyleSheet("background:#0a0a0a;")
        self._cls_grid = QtWidgets.QGridLayout(self._cls_cont)
        self._cls_grid.setSpacing(8); self._cls_grid.setContentsMargins(8,6,8,6)
        scroll.setWidget(self._cls_cont)
        outer.addWidget(scroll)
        return grp

    # 바닥면 4점 + 실세계 좌표 입력 패널
    def _floor_panel(self):
        grp = QtWidgets.QGroupBox("바닥면 4점 & 기준점 설정  (픽셀→실세계 호모그래피 계산)")
        grp.setStyleSheet("QGroupBox{font-weight:bold;color:#ffcc88;}")
        vl = QtWidgets.QVBoxLayout(grp)

        # 모드 선택 + 초기화
        mr = QtWidgets.QHBoxLayout()
        mr.addWidget(QtWidgets.QLabel("클릭 모드:"))
        self._mode_bg = QtWidgets.QButtonGroup(self)
        for i,(label,val) in enumerate([("일반","normal"),("바닥면 4점","floor"),("기준점","ref")]):
            rb = QtWidgets.QRadioButton(label)
            rb.setChecked(val=='normal')
            rb.toggled.connect(lambda ck,v=val: ck and setattr(self,'_mode',v))
            self._mode_bg.addButton(rb,i)
            mr.addWidget(rb)
        fc = QtWidgets.QPushButton("바닥점 초기화"); fc.setFixedWidth(100)
        fc.setStyleSheet("QPushButton{background:#2a1a00;color:#ffaa44;"
                         "border:1px solid #aa6600;border-radius:3px;font-size:10px;}"
                         "QPushButton:hover{background:#4a2a00;}")
        fc.clicked.connect(self._clear_floor)
        rc = QtWidgets.QPushButton("기준점 초기화"); rc.setFixedWidth(100)
        rc.setStyleSheet("QPushButton{background:#001a2a;color:#44aaff;"
                         "border:1px solid #006699;border-radius:3px;font-size:10px;}"
                         "QPushButton:hover{background:#002a3a;}")
        rc.clicked.connect(self._clear_ref)
        mr.addWidget(fc); mr.addWidget(rc); mr.addStretch()
        vl.addLayout(mr)

        # 4점 테이블: 포인트명 | 픽셀 좌표(자동) | 실세계 X | 실세계 Y
        tbl = QtWidgets.QGridLayout()
        tbl.setSpacing(6)
        for c,txt in enumerate(["포인트","픽셀 좌표  (바닥면 모드에서 클릭)","실세계 X(m)","실세계 Y(m)"]):
            lbl = QtWidgets.QLabel(txt)
            lbl.setStyleSheet("color:#aaaaaa;font-size:11px;font-weight:bold;")
            tbl.addWidget(lbl, 0, c)

        self._pt_px_lbl  = []
        self._pt_wx_sp   = []
        self._pt_wy_sp   = []
        default_wx = [0.0, 1.0, 1.0, 0.0]
        default_wy = [0.0, 0.0, 1.0, 1.0]

        for i in range(4):
            bgr = PT_BGR[i]
            # 포인트명
            nl = QtWidgets.QLabel(PT_NAMES[i])
            nl.setStyleSheet(f"color:rgb({bgr[2]},{bgr[1]},{bgr[0]});"
                             "font-weight:bold;font-size:13px;")
            nl.setFixedWidth(28)
            tbl.addWidget(nl, i+1, 0)

            # 픽셀 좌표 (클릭으로 자동 채워짐)
            pl = QtWidgets.QLabel("(미설정)")
            pl.setStyleSheet("color:#666;font-family:monospace;font-size:11px;"
                             "background:#111;border:1px solid #333;padding:2px 6px;border-radius:3px;")
            pl.setFixedWidth(180)
            self._pt_px_lbl.append(pl)
            tbl.addWidget(pl, i+1, 1)

            # 실세계 X
            wx = QtWidgets.QDoubleSpinBox()
            wx.setRange(-999,999); wx.setValue(default_wx[i])
            wx.setDecimals(3); wx.setSuffix(" m"); wx.setFixedWidth(110)
            self._pt_wx_sp.append(wx)
            tbl.addWidget(wx, i+1, 2)

            # 실세계 Y
            wy = QtWidgets.QDoubleSpinBox()
            wy.setRange(-999,999); wy.setValue(default_wy[i])
            wy.setDecimals(3); wy.setSuffix(" m"); wy.setFixedWidth(110)
            self._pt_wy_sp.append(wy)
            tbl.addWidget(wy, i+1, 3)

        vl.addLayout(tbl)

        # 호모그래피 계산 버튼 + 상태
        hr = QtWidgets.QHBoxLayout()
        hb = QtWidgets.QPushButton("호모그래피 계산  (4점 픽셀 + 실세계 X,Y → 변환 행렬)")
        hb.setFixedHeight(30)
        hb.setStyleSheet(
            "QPushButton{background:#1a2a4a;color:#aaccff;border:1px solid #4466aa;"
            "border-radius:4px;font-weight:bold;font-size:11px;}"
            "QPushButton:hover{background:#2a3a5a;}")
        hb.clicked.connect(self._compute_H)
        self._H_lbl = QtWidgets.QLabel("미계산  (4점 클릭 후 실세계 좌표 입력 → 계산 버튼)")
        self._H_lbl.setStyleSheet("color:#888;font-size:10px;")
        hr.addWidget(hb); hr.addWidget(self._H_lbl); hr.addStretch()
        vl.addLayout(hr)

        # 기준점
        self._ref_lbl = QtWidgets.QLabel("기준점: (미설정)  — 기준점 설정 모드에서 이미지 클릭")
        self._ref_lbl.setStyleSheet("color:#88ccff;font-family:monospace;font-size:10px;")
        vl.addWidget(self._ref_lbl)
        return grp

    # 영상
    def _image_panel(self):
        grp = QtWidgets.QGroupBox("컬러 영상  (클릭 → 좌표 설정)")
        lay = QtWidgets.QVBoxLayout(grp)
        self._img = ClickableLabel()
        self._img.setFixedSize(900,600)
        self._img.setStyleSheet("background:#111;color:#555;")
        self._img.setAlignment(Qt.AlignCenter)
        self._img.setText("연결 대기 중...")
        self._img.clicked_px.connect(self._on_click)
        lay.addWidget(self._img, alignment=Qt.AlignCenter)
        return grp

    # 결과 테이블
    def _result_panel(self):
        grp = QtWidgets.QGroupBox("감지 결과  (실세계 좌표 + 상대좌표)")
        lay = QtWidgets.QVBoxLayout(grp)
        self._tbl = QtWidgets.QTableWidget(0,8)
        self._tbl.setHorizontalHeaderLabels(
            ["클래스","감도","X(m)","Y(m)","Z(m)","ΔX(m)","ΔY(m)","ΔZ(m)"])
        self._tbl.setMaximumHeight(150)
        self._tbl.setStyleSheet(
            "QTableWidget{background:#0e0e1e;color:#cccccc;"
            "gridline-color:#333;font-family:monospace;font-size:11px;}"
            "QHeaderView::section{background:#1a1a2e;color:#88aaff;border:1px solid #333;}")
        self._tbl.horizontalHeader().setStretchLastSection(True)
        self._tbl.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        lay.addWidget(self._tbl)
        return grp

    # ── 클래스 패널 ───────────────────────────────────────────────────────────
    def _rebuild_class_panel(self, names):
        prev = {k:cb.isChecked() for k,cb in self._class_checks.items()}
        for i in reversed(range(self._cls_grid.count())):
            w = self._cls_grid.itemAt(i).widget()
            if w: w.deleteLater()
        self._class_checks.clear()
        COLS = 5
        for idx, name in enumerate(names):
            cb = QtWidgets.QCheckBox(name)
            cb.setChecked(prev.get(name,True))
            cb.setMinimumWidth(100)
            cb.setStyleSheet(
                "QCheckBox{color:#e8ffe8;font-size:13px;font-weight:bold;"
                "padding:4px 8px;background:#141414;border:1px solid #333;border-radius:4px;}"
                "QCheckBox:hover{background:#1e2e1e;border:1px solid #44aa66;}"
                "QCheckBox::indicator{width:18px;height:18px;}"
                "QCheckBox::indicator:checked{background:#22aa44;border:2px solid #66dd88;border-radius:4px;}"
                "QCheckBox::indicator:unchecked{background:#1a1a1a;border:2px solid #555;border-radius:4px;}")
            self._cls_grid.addWidget(cb, idx//COLS, idx%COLS)
            self._class_checks[name] = cb
        self._cls_info.setText(f"총 {len(names)}개 클래스")
        self._cls_info.setStyleSheet("color:#88ffcc;font-size:11px;font-weight:bold;")

    def _allowed(self):
        return {k for k,cb in self._class_checks.items() if cb.isChecked()}

    def _sel_all(self):
        for cb in self._class_checks.values(): cb.setChecked(True)

    def _sel_none(self):
        for cb in self._class_checks.values(): cb.setChecked(False)

    # ── 호모그래피 계산 ───────────────────────────────────────────────────────
    def _compute_H(self):
        if len(self._floor_pts) < 4:
            self._H_lbl.setText(f"오류: 4점 필요 (현재 {len(self._floor_pts)}점)")
            self._H_lbl.setStyleSheet("color:#ff8888;font-size:10px;")
            return

        px_pts = np.array([[p['u'], p['v']] for p in self._floor_pts[:4]], dtype=np.float32)
        wx_pts = np.array([
            [self._pt_wx_sp[i].value(), self._pt_wy_sp[i].value()]
            for i in range(4)
        ], dtype=np.float32)

        H, mask = cv2.findHomography(px_pts, wx_pts, cv2.RANSAC)
        if H is None:
            self._H_lbl.setText("계산 실패 (4점이 공선이면 안됨)")
            self._H_lbl.setStyleSheet("color:#ff8888;font-size:10px;")
            return

        self._H = H
        # 재투영 오차
        proj = cv2.perspectiveTransform(px_pts.reshape(-1,1,2), H).reshape(-1,2)
        rms  = float(np.sqrt(((proj - wx_pts)**2).sum(axis=1).mean()))
        self._H_lbl.setText(f"✅ 계산 완료  RMS={rms:.4f}m  행렬 크기 3×3")
        self._H_lbl.setStyleSheet("color:#88ff88;font-size:10px;font-weight:bold;")

    # ── 3D 좌표 계산 ─────────────────────────────────────────────────────────
    def _get_3d(self, u: int, v: int):
        """픽셀(u,v) → (X,Y,Z) meters.
        X,Y: 호모그래피(바닥면 투영) / Z: 뎁스 이미지 (없으면 카메라 높이)."""
        # X, Y — 호모그래피
        if self._H is None:
            return None
        pt  = np.array([[[float(u), float(v)]]], dtype=np.float32)
        wpt = cv2.perspectiveTransform(pt, self._H)
        X, Y = float(wpt[0,0,0]), float(wpt[0,0,1])

        # Z — 뎁스 이미지 우선
        with self._dlk:
            depth = self._depth_frame
        if depth is not None and 0<=v<depth.shape[0] and 0<=u<depth.shape[1]:
            Z = float(depth[v,u])
            if not (0.05 < Z < 30.0):
                Z = self._h_sp.value() / 100.0
        else:
            Z = self._h_sp.value() / 100.0

        return (X, Y, Z)

    def _relative(self, xyz):
        if self._ref_uvxyz is None or xyz is None:
            return None
        rx,ry,rz = self._ref_uvxyz[2], self._ref_uvxyz[3], self._ref_uvxyz[4]
        return (xyz[0]-rx, xyz[1]-ry, xyz[2]-rz)

    # ── 클릭 핸들러 ───────────────────────────────────────────────────────────
    def _on_click(self, u: int, v: int):
        if self._mode == 'floor':
            if len(self._floor_pts) >= 4:
                # 4점 초과 → 리셋 후 P1부터 다시
                self._floor_pts.clear()
                for lbl in self._pt_px_lbl:
                    lbl.setText("(미설정)")
                    lbl.setStyleSheet("color:#666;font-family:monospace;font-size:11px;"
                                     "background:#111;border:1px solid #333;padding:2px 6px;border-radius:3px;")
            i = len(self._floor_pts)
            self._floor_pts.append({'u': u, 'v': v})
            bgr = PT_BGR[i]
            self._pt_px_lbl[i].setText(f"u={u},  v={v}")
            self._pt_px_lbl[i].setStyleSheet(
                f"color:rgb({bgr[2]},{bgr[1]},{bgr[0]});"
                "font-family:monospace;font-size:11px;font-weight:bold;"
                "background:#111;border:1px solid #555;padding:2px 6px;border-radius:3px;")

        elif self._mode == 'ref':
            xyz = self._get_3d(u, v)
            if xyz:
                self._ref_uvxyz = (u, v, *xyz)
                self._ref_lbl.setText(
                    f"기준점  픽셀({u},{v})  →  "
                    f"X={xyz[0]:.3f}m  Y={xyz[1]:.3f}m  Z={xyz[2]:.3f}m")
                self._ref_lbl.setStyleSheet(
                    "color:#44ccff;font-family:monospace;font-size:10px;font-weight:bold;")
            elif self._H is None:
                QtWidgets.QMessageBox.warning(self,"경고","먼저 호모그래피를 계산하세요.")
            else:
                QtWidgets.QMessageBox.warning(self,"경고","유효한 뎁스 값이 없습니다.")

    def _clear_floor(self):
        self._floor_pts.clear()
        for lbl in self._pt_px_lbl:
            lbl.setText("(미설정)")
            lbl.setStyleSheet("color:#666;font-family:monospace;font-size:11px;"
                             "background:#111;border:1px solid #333;padding:2px 6px;border-radius:3px;")
        self._H = None
        self._H_lbl.setText("미계산  (4점 초기화됨)")
        self._H_lbl.setStyleSheet("color:#888;font-size:10px;")

    def _clear_ref(self):
        self._ref_uvxyz = None
        self._ref_lbl.setText("기준점: (미설정)")
        self._ref_lbl.setStyleSheet("color:#88ccff;font-family:monospace;font-size:10px;")

    # ── ROS2 연결 ─────────────────────────────────────────────────────────────
    def _connect(self):
        if not ROS2_AVAILABLE:
            QtWidgets.QMessageBox.warning(self,"경고","rclpy를 찾을 수 없습니다."); return
        self._disconnect()
        self.ros2_sub = Ros2DepthSub()
        self.ros2_sub.color_rx.connect(self._on_color)
        self.ros2_sub.depth_rx.connect(self._on_depth)
        self.ros2_sub.start()
        self._conn_btn.setEnabled(False); self._disc_btn.setEnabled(True)
        self._conn_lbl.setText("연결됨  ✅")
        self._conn_lbl.setStyleSheet("color:#88ff88;font-size:10px;")
        self.timer.start(33)

    def _disconnect(self):
        self.timer.stop()
        if self.ros2_sub: self.ros2_sub.stop(); self.ros2_sub = None
        with self._clk: self._color_frame = None
        with self._dlk: self._depth_frame = None
        self._conn_btn.setEnabled(True); self._disc_btn.setEnabled(False)
        self._conn_lbl.setText("미연결")
        self._conn_lbl.setStyleSheet("color:#888;font-size:10px;")
        self._img.clear(); self._img.setText("연결 해제됨")

    def _on_color(self, frame):
        with self._clk: self._color_frame = frame.copy()
        self._img.set_src(frame.shape[1], frame.shape[0])

    def _on_depth(self, depth):
        with self._dlk: self._depth_frame = depth.copy()

    def _on_conf(self, v):
        self.conf = v/100.0
        self._conf_lbl.setText(f"{self.conf:.2f}")

    def _on_resize(self):
        self._img.setFixedSize(self._dw_sp.value(), self._dh_sp.value())

    # ── 추론 루프 ─────────────────────────────────────────────────────────────
    def _tick(self):
        with self._clk:
            frame = self._color_frame
        if frame is None:
            return

        allowed = self._allowed()
        dets = []
        if self.model and allowed:
            try:
                for d in run_inference(self.model, frame, self.conf, allowed):
                    xyz = self._get_3d(d['cx'], d['cy'])
                    dets.append({**d, 'xyz': xyz, 'rel': self._relative(xyz)})
            except Exception as e:
                print(f"[추론] {e}")
        self._detections = dets

        vis = self._draw(frame.copy(), dets)
        self._img.setPixmap(to_pixmap(vis, self._dw_sp.value(), self._dh_sp.value()))
        self._upd_table(dets)

    # ── 오버레이 ──────────────────────────────────────────────────────────────
    def _draw(self, vis, dets):
        col = (0, 255, 160)
        for d in dets:
            if d['type'] == 'obb':
                cv2.polylines(vis, [d['corners']], True, col, 2)
            else:
                cv2.rectangle(vis,(int(d['x1']),int(d['y1'])),(int(d['x2']),int(d['y2'])),col,2)
            y0 = max(int(d['y1'])-20, 14)
            cv2.putText(vis, f"{d['label']} {d['conf']:.2f}",
                        (int(d['x1']),y0), cv2.FONT_HERSHEY_SIMPLEX, 0.5, col, 1)
            xyz = d['xyz']; rel = d['rel']
            if xyz:
                coord = f"X:{xyz[0]:.2f} Y:{xyz[1]:.2f} Z:{xyz[2]:.2f}m"
                if rel:
                    coord += f"  Δ({rel[0]:+.2f},{rel[1]:+.2f},{rel[2]:+.2f})"
                cv2.putText(vis, coord, (int(d['x1']),y0+16),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.4, (180,255,180), 1)

        # 바닥 4점
        px_list = []
        for i, p in enumerate(self._floor_pts):
            bgr = PT_BGR[i]; u,v = p['u'],p['v']
            px_list.append((u,v))
            cv2.circle(vis,(u,v),9,bgr,-1)
            cv2.circle(vis,(u,v),11,(255,255,255),1)
            wx = self._pt_wx_sp[i].value(); wy = self._pt_wy_sp[i].value()
            cv2.putText(vis, f"{PT_NAMES[i]}({wx:.2f},{wy:.2f}m)",
                        (u+13,v+5), cv2.FONT_HERSHEY_SIMPLEX, 0.42, bgr, 1)
        n = len(px_list)
        for j in range(n):
            cv2.line(vis, px_list[j], px_list[(j+1)%n], (200,200,60), 1)

        # 기준점
        if self._ref_uvxyz:
            ru,rv = self._ref_uvxyz[0], self._ref_uvxyz[1]
            cv2.drawMarker(vis,(ru,rv),(0,200,255),cv2.MARKER_CROSS,20,2)
            cv2.circle(vis,(ru,rv),12,(0,200,255),1)
            cv2.putText(vis,"REF(0,0,0)",(ru+14,rv+5),cv2.FONT_HERSHEY_SIMPLEX,0.45,(0,200,255),1)

        # 호모그래피 상태 힌트
        if self._H is None:
            cv2.putText(vis,"[호모그래피 미계산 — 실세계 좌표 표시 불가]",
                        (10,25), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (80,80,255), 1)

        hints = {"floor":"▶ 바닥면 클릭 (P1→P4, 4점 후 자동 리셋)",
                 "ref":  "▶ 기준점 클릭 (상대좌표 원점)"}
        if self._mode in hints:
            cv2.putText(vis, hints[self._mode], (10,vis.shape[0]-10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0,220,255), 2)
        return vis

    # ── 결과 테이블 ───────────────────────────────────────────────────────────
    def _upd_table(self, dets):
        self._tbl.setRowCount(len(dets))
        for r,d in enumerate(dets):
            xyz=d['xyz']; rel=d['rel']
            for c,v in enumerate([
                d['label'], f"{d['conf']:.2f}",
                f"{xyz[0]:.3f}" if xyz else "—",
                f"{xyz[1]:.3f}" if xyz else "—",
                f"{xyz[2]:.3f}" if xyz else "—",
                f"{rel[0]:+.3f}" if rel else "—",
                f"{rel[1]:+.3f}" if rel else "—",
                f"{rel[2]:+.3f}" if rel else "—",
            ]):
                it = QtWidgets.QTableWidgetItem(v)
                it.setTextAlignment(Qt.AlignCenter)
                self._tbl.setItem(r,c,it)

    # ── 모델 관리 ─────────────────────────────────────────────────────────────
    def _refresh_models(self):
        files = list_pt_files()
        self._mdl_combo.clear(); self._mdl_combo.addItems(files)

    def _load_model(self):
        rel = self._mdl_combo.currentText()
        if not rel: return
        self.sig_mdl_st.emit("로드 중...","#888888")
        threading.Thread(target=self._do_load, args=(rel,), daemon=True).start()

    def _do_load(self, rel):
        from ultralytics import YOLO
        try:
            m = YOLO(str(WEIGHTS_DIR/rel))
            names = list(m.names.values())
            self.model = m
            self.sig_classes.emit(names)
            self.sig_mdl_st.emit(f"✅ {rel}  ({len(names)}cls)","#aaaaff")
        except Exception as e:
            self.sig_error.emit(str(e))

    def closeEvent(self, ev):
        self._disconnect(); ev.accept()


if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    win = InferenceDepthUI()
    win.show()
    sys.exit(app.exec_())
