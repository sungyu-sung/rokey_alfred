#!/usr/bin/env python3
"""inference_compare_sel_six.py — YOLO 6개 모델 비교 추론 (클래스 선택 + 전체 감도)"""
import os, sys, threading, json
os.environ['QT_QPA_PLATFORM_PLUGIN_PATH'] = '/usr/lib/x86_64-linux-gnu/qt5/plugins'
os.environ['QT_QPA_PLATFORM'] = 'wayland'

import cv2
import numpy as np
from pathlib import Path
from threading import Lock

from PyQt5 import QtWidgets, QtCore, QtGui
from PyQt5.QtCore import Qt, pyqtSignal, QThread, QTimer

WEIGHTS_DIR   = Path("/home/han3/turtlebot4_ws/src/training/weights")
SETTINGS_FILE = Path(__file__).parent / "inference_compare_sel_six_settings.json"
NUM_MODELS  = 6
GRID_COLS   = 3                       # 위 3개 / 아래 3개
BOX_COL     = (0, 255, 0)             # 감지 박스 색상 — 초록 고정
PALETTE     = ["#ff7800", "#00c8ff", "#ff44cc", "#ffe066", "#7c4dff", "#43e97b"]

ROS2_TOPIC_PRESETS = [
    "/robot2/oakd/rgb/image_raw/compressed",
    "/robot2/oakd/rgb/image_raw",
    "/robot4/oakd/rgb/image_raw/compressed",
    "/robot4/oakd/rgb/image_raw",
    "/camera/color/image_raw",
    "/camera/rgb/image_raw/compressed",
]

try:
    import rclpy
    from sensor_msgs.msg import Image, CompressedImage
    from cv_bridge import CvBridge
    ROS2_AVAILABLE = True
except ImportError:
    ROS2_AVAILABLE = False


# ── ROS2 구독 스레드 ──────────────────────────────────────────────────────────
class Ros2Subscriber(QThread):
    frame_received = pyqtSignal(object)

    def __init__(self, topic: str):
        super().__init__()
        self.topic         = topic
        self.is_compressed = topic.endswith("/compressed")
        self._stop         = threading.Event()
        self.bridge        = CvBridge()

    def run(self):
        if not rclpy.ok():
            rclpy.init()
        node = rclpy.create_node('inference_sel_six_sub')
        if self.is_compressed:
            node.create_subscription(CompressedImage, self.topic, self._cb_compressed, 10)
        else:
            node.create_subscription(Image, self.topic, self._cb_raw, 10)
        while not self._stop.is_set() and rclpy.ok():
            rclpy.spin_once(node, timeout_sec=0.05)
        node.destroy_node()

    def _cb_raw(self, msg):
        try:
            self.frame_received.emit(self.bridge.imgmsg_to_cv2(msg, 'bgr8'))
        except Exception:
            pass

    def _cb_compressed(self, msg):
        try:
            buf = np.frombuffer(msg.data, dtype=np.uint8)
            f   = cv2.imdecode(buf, cv2.IMREAD_COLOR)
            if f is not None:
                self.frame_received.emit(f)
        except Exception:
            pass

    def stop(self):
        self._stop.set()
        self.wait(2000)


# ── 유틸 ─────────────────────────────────────────────────────────────────────
def list_pt_files():
    if not WEIGHTS_DIR.exists():
        return []
    return [str(f.relative_to(WEIGHTS_DIR))
            for f in sorted(WEIGHTS_DIR.rglob("*.pt"))]


def run_inference(model, frame, conf, allowed: set):
    results   = model.predict(frame, conf=conf, verbose=False)
    positions = []
    for r in results:
        if r.boxes is not None and len(r.boxes):
            for box in r.boxes:
                lbl = model.names[int(box.cls[0])]
                if lbl not in allowed:
                    continue
                x1, y1, x2, y2 = box.xyxy[0].tolist()
                positions.append({'label': lbl, 'conf': float(box.conf[0]),
                                  'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2,
                                  'type': 'det'})
        elif r.obb is not None and len(r.obb):
            for box in r.obb:
                lbl = model.names[int(box.cls[0])]
                if lbl not in allowed:
                    continue
                corners = box.xyxyxyxy[0].cpu().numpy().astype(int)
                mn = corners.min(axis=0); mx = corners.max(axis=0)
                positions.append({'label': lbl, 'conf': float(box.conf[0]),
                                  'x1': mn[0], 'y1': mn[1], 'x2': mx[0], 'y2': mx[1],
                                  'corners': corners, 'type': 'obb'})
    return positions


def draw_boxes(frame, positions):
    """모든 모델 공통 — 감지 박스는 초록색으로 표시."""
    vis = frame.copy()
    for p in positions:
        if p['type'] == 'obb':
            cv2.polylines(vis, [p['corners']], True, BOX_COL, 2)
        else:
            cv2.rectangle(vis, (int(p['x1']), int(p['y1'])),
                               (int(p['x2']), int(p['y2'])), BOX_COL, 2)
        cv2.putText(vis, f"{p['label']} {p['conf']:.2f}",
                    (int(p['x1']), max(int(p['y1']) - 6, 14)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.55, BOX_COL, 2)
    return vis


def frame_to_pixmap(frame, w, h):
    """원본 비율 무관, w x h 크기로 채워서 표시."""
    sq  = cv2.resize(frame, (w, h), interpolation=cv2.INTER_LINEAR)
    rgb = cv2.cvtColor(sq, cv2.COLOR_BGR2RGB)
    fh, fw, ch = rgb.shape
    qi = QtGui.QImage(rgb.data, fw, fh, ch * fw, QtGui.QImage.Format_RGB888)
    return QtGui.QPixmap.fromImage(qi.copy())


# ── 메인 UI ───────────────────────────────────────────────────────────────────
class InferenceSelUI(QtWidgets.QWidget):
    # 백그라운드 스레드 → 메인 스레드 안전 통신용 시그널
    sig_classes = pyqtSignal(list)              # 클래스 목록 갱신
    sig_status  = pyqtSignal(int, str, str)     # (모델 인덱스, 텍스트, 색)
    sig_loaded  = pyqtSignal(int, str)          # (모델 인덱스, 가중치 파일명)
    sig_error   = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        self.models        = [None] * NUM_MODELS
        self.confs         = [0.40] * NUM_MODELS
        self.positions     = [[] for _ in range(NUM_MODELS)]

        self.combos         = [None] * NUM_MODELS
        self.status_labels  = [None] * NUM_MODELS
        self.img_labels     = [None] * NUM_MODELS
        self.video_cells    = [None] * NUM_MODELS

        self.cap         = None
        self.ros2_sub    = None
        self._cur_frame  = None
        self._frame_lock = Lock()
        self.disp_w      = 469   # 704의 2/3 크기 (가로)
        self.disp_h      = 469   # 704의 2/3 크기 (세로)
        self.results_h   = 160   # 감지 결과 스크롤 영역 높이
        self.result_labels = [None] * NUM_MODELS
        # 클래스명 → QCheckBox
        self._class_checks: dict[str, QtWidgets.QCheckBox] = {}
        self._saved_classes: dict = {}

        self._init_ui()
        self._connect_signals()
        self._refresh_models()

        self.display_timer = QTimer(self)
        self.display_timer.timeout.connect(self._tick)

        self._load_settings()

    def _connect_signals(self):
        self.sig_classes.connect(self._rebuild_class_panel)
        self.sig_status.connect(self._set_status)
        self.sig_loaded.connect(self._set_video_title)
        self.sig_error.connect(
            lambda msg: QtWidgets.QMessageBox.critical(self, "로드 실패", msg))

    def _set_status(self, idx, text, color):
        self.status_labels[idx].setText(text)
        self.status_labels[idx].setStyleSheet(f"color:{color};font-size:10px;")

    def _set_video_title(self, idx, rel):
        self.video_cells[idx].setTitle(f"모델 {idx + 1} : {rel}")

    # ── UI 구성 ───────────────────────────────────────────────────────────────
    def _init_ui(self):
        self.setWindowTitle("YOLO 6모델 비교  [클래스 선택 + 전체 감도]")
        self.setMinimumSize(1300, 900)
        outer = QtWidgets.QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)

        # 전체를 스크롤 영역에 담아 화면보다 큰 콘텐츠도 스크롤로 확인
        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        outer.addWidget(scroll)

        content = QtWidgets.QWidget()
        scroll.setWidget(content)
        root = QtWidgets.QVBoxLayout(content)
        root.setSpacing(5); root.setContentsMargins(5, 5, 5, 5)

        # ── 행1: 소스 + 설정 ─────────────────────────────────────────────────
        top = QtWidgets.QHBoxLayout()
        top.addWidget(self._make_src_panel())
        top.addWidget(self._make_opt_panel())
        top.addStretch()
        root.addLayout(top)

        # ── 행2: 클래스 선택 패널 ────────────────────────────────────────────
        root.addWidget(self._make_class_panel())

        # ── 행3: 모델 6개 설정 (3열 x 2행) ──────────────────────────────────
        root.addWidget(self._make_models_panel())

        # ── 행3-1: 전체 감도 (모델 설정 바로 아래) ──────────────────────────
        root.addWidget(self._make_master_conf_panel())

        # ── 행4: 감지 결과 — 모델별 개별, 영상 바로 위, 스크롤 ──────────────
        root.addWidget(self._make_results_panel())

        # ── 행5: 영상 6개 — 위 3개 / 아래 3개, 정사각형 ─────────────────────
        root.addWidget(self._make_video_grid())

    # ── 소스 패널 ─────────────────────────────────────────────────────────────
    def _make_src_panel(self):
        src_grp = QtWidgets.QGroupBox("영상 소스")
        lay = QtWidgets.QVBoxLayout(src_grp)

        row = QtWidgets.QHBoxLayout()
        row.addWidget(QtWidgets.QLabel("소스:"))
        self.src_combo = QtWidgets.QComboBox()
        items = ["웹캠", "동영상 파일"]
        if ROS2_AVAILABLE:
            items.append("ROS2 토픽")
        self.src_combo.addItems(items)
        self.src_combo.currentIndexChanged.connect(self._on_src_type)
        row.addWidget(self.src_combo)
        lay.addLayout(row)

        self.cam_w = QtWidgets.QWidget()
        cr = QtWidgets.QHBoxLayout(self.cam_w); cr.setContentsMargins(0,0,0,0)
        cr.addWidget(QtWidgets.QLabel("번호:"))
        self.cam_spin = QtWidgets.QSpinBox(); self.cam_spin.setRange(0,10)
        cr.addWidget(self.cam_spin)
        lay.addWidget(self.cam_w)

        self.file_w = QtWidgets.QWidget()
        fr = QtWidgets.QHBoxLayout(self.file_w); fr.setContentsMargins(0,0,0,0)
        self.file_edit = QtWidgets.QLineEdit()
        self.file_edit.setPlaceholderText("동영상 파일...")
        fb = QtWidgets.QPushButton("찾기"); fb.clicked.connect(self._browse_video)
        fr.addWidget(self.file_edit); fr.addWidget(fb)
        self.file_w.setVisible(False)
        lay.addWidget(self.file_w)

        self.ros2_w = QtWidgets.QWidget()
        rc = QtWidgets.QVBoxLayout(self.ros2_w); rc.setContentsMargins(0,0,0,0)
        pr = QtWidgets.QHBoxLayout()
        pr.addWidget(QtWidgets.QLabel("프리셋:"))
        self.topic_preset = QtWidgets.QComboBox()
        self.topic_preset.addItems(ROS2_TOPIC_PRESETS + ["직접 입력..."])
        self.topic_preset.currentIndexChanged.connect(self._on_topic_preset)
        pr.addWidget(self.topic_preset); rc.addLayout(pr)
        tr = QtWidgets.QHBoxLayout()
        tr.addWidget(QtWidgets.QLabel("토픽:"))
        self.topic_edit = QtWidgets.QLineEdit(ROS2_TOPIC_PRESETS[0])
        tr.addWidget(self.topic_edit); rc.addLayout(tr)
        self.ros2_w.setVisible(False)
        lay.addWidget(self.ros2_w)

        ob = QtWidgets.QHBoxLayout()
        self.open_btn = QtWidgets.QPushButton("열기")
        self.open_btn.setFixedHeight(30)
        self.open_btn.setStyleSheet(
            "QPushButton{background:#1a5a1a;color:#88ff88;font-weight:bold;"
            "border:1px solid #336633;border-radius:3px;}"
            "QPushButton:hover{background:#2a7a2a;}")
        self.open_btn.clicked.connect(self.open_source)
        self.close_btn = QtWidgets.QPushButton("닫기")
        self.close_btn.setFixedHeight(30); self.close_btn.setEnabled(False)
        self.close_btn.clicked.connect(self.close_source)
        ob.addWidget(self.open_btn); ob.addWidget(self.close_btn)
        lay.addLayout(ob)
        self.src_status = QtWidgets.QLabel("소스 없음")
        self.src_status.setStyleSheet("color:#888;font-size:10px;")
        lay.addWidget(self.src_status)
        src_grp.setFixedWidth(250)
        return src_grp

    # ── 설정 패널 ─────────────────────────────────────────────────────────────
    def _make_opt_panel(self):
        grp = QtWidgets.QGroupBox("설정")
        lay = QtWidgets.QFormLayout(grp)
        ref = QtWidgets.QPushButton("↺ 모델 목록")
        ref.clicked.connect(self._refresh_models)
        lay.addRow("", ref)
        self.disp_w_sp = QtWidgets.QSpinBox()
        self.disp_w_sp.setRange(80, 1920); self.disp_w_sp.setSingleStep(16)
        self.disp_w_sp.setValue(self.disp_w)
        self.disp_w_sp.valueChanged.connect(self._on_resize)
        lay.addRow("화면 가로(px):", self.disp_w_sp)
        self.disp_h_sp = QtWidgets.QSpinBox()
        self.disp_h_sp.setRange(80, 1080); self.disp_h_sp.setSingleStep(16)
        self.disp_h_sp.setValue(self.disp_h)
        self.disp_h_sp.valueChanged.connect(self._on_resize)
        lay.addRow("화면 세로(px):", self.disp_h_sp)

        self.results_h_sp = QtWidgets.QSpinBox()
        self.results_h_sp.setRange(60, 800); self.results_h_sp.setSingleStep(20)
        self.results_h_sp.setValue(self.results_h)
        self.results_h_sp.valueChanged.connect(self._on_results_resize)
        lay.addRow("감지창 높이(px):", self.results_h_sp)
        return grp

    # ── 전체 감도 패널 (모델 설정 패널 바로 아래) ────────────────────────────
    def _make_master_conf_panel(self):
        grp = QtWidgets.QGroupBox("전체 감도 (6개 모델 공통 적용)")
        grp.setStyleSheet("QGroupBox{font-weight:bold;color:#cccccc;}")
        lay = QtWidgets.QHBoxLayout(grp)
        lay.addWidget(QtWidgets.QLabel("전체 감도:"))
        self.master_slider = QtWidgets.QSlider(Qt.Horizontal)
        self.master_slider.setRange(5, 95); self.master_slider.setValue(40)
        self.master_slider.setTickInterval(5)
        self.master_slider.valueChanged.connect(self._on_master_slider)
        self.master_lbl = QtWidgets.QLabel("0.40")
        self.master_lbl.setFixedWidth(34)
        self.master_lbl.setStyleSheet("color:#ffffff;font-weight:bold;")
        lay.addWidget(self.master_slider)
        lay.addWidget(self.master_lbl)
        return grp

    def _on_master_slider(self, v):
        conf = v / 100.0
        self.master_lbl.setText(f"{conf:.2f}")
        self.confs = [conf] * NUM_MODELS

    def _on_results_resize(self):
        self.results_h = self.results_h_sp.value()
        self.results_scroll.setFixedHeight(self.results_h)

    # ── 클래스 선택 패널 ─────────────────────────────────────────────────────
    def _make_class_panel(self):
        grp = QtWidgets.QGroupBox("사물 클래스 선택  (체크된 클래스만 인식)")
        grp.setStyleSheet("QGroupBox{font-weight:bold;color:#88ffcc;}")
        outer = QtWidgets.QVBoxLayout(grp)

        # 전체선택 / 전체해제
        btn_row = QtWidgets.QHBoxLayout()
        all_btn = QtWidgets.QPushButton("전체 선택")
        all_btn.setFixedWidth(90)
        all_btn.setStyleSheet(
            "QPushButton{background:#1a3a1a;color:#88ff88;border:1px solid #336633;"
            "border-radius:3px;font-size:11px;}"
            "QPushButton:hover{background:#2a5a2a;}")
        all_btn.clicked.connect(self._select_all)
        none_btn = QtWidgets.QPushButton("전체 해제")
        none_btn.setFixedWidth(90)
        none_btn.setStyleSheet(
            "QPushButton{background:#3a1a1a;color:#ff8888;border:1px solid #663333;"
            "border-radius:3px;font-size:11px;}"
            "QPushButton:hover{background:#5a2a2a;}")
        none_btn.clicked.connect(self._select_none)
        self.cls_info_lbl = QtWidgets.QLabel("모델 로드 후 클래스 표시")
        self.cls_info_lbl.setStyleSheet("color:#666;font-size:10px;")
        btn_row.addWidget(all_btn)
        btn_row.addWidget(none_btn)
        btn_row.addWidget(self.cls_info_lbl)
        btn_row.addStretch()
        outer.addLayout(btn_row)

        # 체크박스 영역 — QGridLayout (4열)
        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setMaximumHeight(160)
        scroll.setStyleSheet(
            "QScrollArea{border:1px solid #333;background:#0a0a0a;border-radius:4px;}")
        self._cls_container = QtWidgets.QWidget()
        self._cls_container.setStyleSheet("background:#0a0a0a;")
        self._cls_grid = QtWidgets.QGridLayout(self._cls_container)
        self._cls_grid.setSpacing(8)
        self._cls_grid.setContentsMargins(8, 6, 8, 6)
        scroll.setWidget(self._cls_container)
        outer.addWidget(scroll)
        return grp

    # ── 클래스 체크리스트 (메인 스레드에서만 호출) ────────────────────────────
    def _rebuild_class_panel(self, all_names: list):
        prev = {k: cb.isChecked() for k, cb in self._class_checks.items()}
        if not prev and self._saved_classes:
            prev = self._saved_classes

        # 기존 위젯 제거
        for i in reversed(range(self._cls_grid.count())):
            w = self._cls_grid.itemAt(i).widget()
            if w:
                w.deleteLater()
        self._class_checks.clear()

        COLS = 4
        for idx, name in enumerate(all_names):
            cb = QtWidgets.QCheckBox(name)
            cb.setChecked(prev.get(name, True))
            cb.setMinimumWidth(110)
            cb.setStyleSheet(
                "QCheckBox{"
                "  color:#e8ffe8;"
                "  font-size:13px;"
                "  font-weight:bold;"
                "  padding:4px 8px;"
                "  background:#141414;"
                "  border:1px solid #333;"
                "  border-radius:4px;"
                "}"
                "QCheckBox:hover{"
                "  background:#1e2e1e;"
                "  border:1px solid #44aa66;"
                "}"
                "QCheckBox::indicator{"
                "  width:18px; height:18px;"
                "}"
                "QCheckBox::indicator:checked{"
                "  background:#22aa44;"
                "  border:2px solid #66dd88;"
                "  border-radius:4px;"
                "}"
                "QCheckBox::indicator:unchecked{"
                "  background:#1a1a1a;"
                "  border:2px solid #555;"
                "  border-radius:4px;"
                "}")
            row, col = divmod(idx, COLS)
            self._cls_grid.addWidget(cb, row, col)
            self._class_checks[name] = cb

        n = len(all_names)
        self.cls_info_lbl.setText(f"총 {n}개 클래스")
        self.cls_info_lbl.setStyleSheet("color:#88ffcc;font-size:11px;font-weight:bold;")

    def _allowed_classes(self) -> set:
        return {k for k, cb in self._class_checks.items() if cb.isChecked()}

    def _select_all(self):
        for cb in self._class_checks.values():
            cb.setChecked(True)

    def _select_none(self):
        for cb in self._class_checks.values():
            cb.setChecked(False)

    # ── 모델 6개 설정 패널 ────────────────────────────────────────────────────
    def _make_models_panel(self):
        grp = QtWidgets.QGroupBox("모델 설정 (6개)")
        grp.setStyleSheet("QGroupBox{font-weight:bold;color:#cccccc;}")
        grid = QtWidgets.QGridLayout(grp)
        grid.setSpacing(6)
        for idx in range(NUM_MODELS):
            r, c = divmod(idx, GRID_COLS)
            grid.addWidget(self._make_model_cell(idx), r, c)
        return grp

    def _make_model_cell(self, idx):
        col = PALETTE[idx]
        grp = QtWidgets.QGroupBox(f"모델 {idx + 1}")
        grp.setStyleSheet(
            f"QGroupBox{{color:{col};font-weight:bold;border:1px solid {col};"
            f"border-radius:4px;margin-top:6px;}}")
        lay = QtWidgets.QVBoxLayout(grp)

        combo = QtWidgets.QComboBox(); combo.setMinimumWidth(160)
        btn = QtWidgets.QPushButton("로드")
        btn.setStyleSheet(
            f"QPushButton{{background:#1a1a1a;color:{col};border:1px solid {col};"
            f"border-radius:3px;font-weight:bold;}}"
            f"QPushButton:hover{{background:#2a2a2a;}}")
        status = QtWidgets.QLabel("미로드")
        status.setStyleSheet("color:#888;font-size:10px;")
        status.setWordWrap(True)
        status.setMaximumHeight(34)

        lay.addWidget(combo); lay.addWidget(btn)
        lay.addWidget(status)

        self.combos[idx]        = combo
        self.status_labels[idx] = status
        btn.clicked.connect(lambda _, i=idx: self._load_model_slot(i))
        return grp

    # ── 영상 그리드 (위 3개 / 아래 3개, 정사각형) ────────────────────────────
    def _make_video_grid(self):
        grp = QtWidgets.QGroupBox("영상 비교  (위 3개 / 아래 3개)")
        grid = QtWidgets.QGridLayout(grp)
        grid.setSpacing(6)
        for idx in range(NUM_MODELS):
            r, c = divmod(idx, GRID_COLS)
            col = PALETTE[idx]
            cell = QtWidgets.QGroupBox(f"모델 {idx + 1}")
            cell.setStyleSheet(f"QGroupBox{{color:{col};font-weight:bold;}}")
            clay = QtWidgets.QVBoxLayout(cell)
            img = QtWidgets.QLabel(f"모델 {idx + 1} 대기")
            img.setFixedSize(self.disp_w, self.disp_h)
            img.setStyleSheet("background:#111;color:#555;")
            img.setAlignment(Qt.AlignCenter)
            clay.addWidget(img)
            self.img_labels[idx] = img
            self.video_cells[idx] = cell
            grid.addWidget(cell, r, c)
        return grp

    # ── 감지 결과 패널 (모델별 개별, 영상 위, 스크롤) ──────────────────────────
    def _make_results_panel(self):
        grp = QtWidgets.QGroupBox("감지 결과 (모델별)")
        grp.setStyleSheet("QGroupBox{font-weight:bold;color:#88ffcc;}")
        lay = QtWidgets.QVBoxLayout(grp)

        self.results_scroll = QtWidgets.QScrollArea()
        self.results_scroll.setWidgetResizable(True)
        self.results_scroll.setFixedHeight(self.results_h)
        self.results_scroll.setStyleSheet(
            "QScrollArea{border:1px solid #333;background:#0a0a0a;border-radius:4px;}")

        container = QtWidgets.QWidget()
        container.setStyleSheet("background:#0a0a0a;")
        grid = QtWidgets.QGridLayout(container)
        grid.setSpacing(6)
        for idx in range(NUM_MODELS):
            col = PALETTE[idx]
            lbl = QtWidgets.QLabel(f"모델 {idx + 1} : 대기 중...")
            lbl.setStyleSheet(
                f"color:{col};background:#141414;padding:6px;"
                f"border:1px solid {col};border-radius:4px;"
                f"font-family:monospace;font-size:12px;")
            lbl.setWordWrap(True)
            lbl.setAlignment(Qt.AlignTop | Qt.AlignLeft)
            r, c = divmod(idx, GRID_COLS)
            grid.addWidget(lbl, r, c)
            self.result_labels[idx] = lbl
        self.results_scroll.setWidget(container)

        lay.addWidget(self.results_scroll)
        return grp

    # ── 소스 관리 ─────────────────────────────────────────────────────────────
    def _on_src_type(self, idx):
        sel = ["cam","file","ros2"][min(idx,2)]
        self.cam_w.setVisible(sel=="cam")
        self.file_w.setVisible(sel=="file")
        self.ros2_w.setVisible(sel=="ros2")

    def _on_topic_preset(self, idx):
        if idx < len(ROS2_TOPIC_PRESETS):
            self.topic_edit.setText(ROS2_TOPIC_PRESETS[idx])
            self.topic_edit.setReadOnly(True)
        else:
            self.topic_edit.setReadOnly(False); self.topic_edit.clear()

    def _browse_video(self):
        p, _ = QtWidgets.QFileDialog.getOpenFileName(
            self, "동영상 파일", "", "Video (*.mp4 *.avi *.mkv *.mov);;All (*)")
        if p: self.file_edit.setText(p)

    def open_source(self):
        self.close_source()
        idx = self.src_combo.currentIndex()
        sel = ["cam","file","ros2"][min(idx,2)]
        if sel == "ros2":
            if not ROS2_AVAILABLE:
                QtWidgets.QMessageBox.warning(self,"경고","ROS2 없음"); return
            topic = self.topic_edit.text().strip()
            if not topic:
                QtWidgets.QMessageBox.warning(self,"경고","토픽 입력"); return
            self.ros2_sub = Ros2Subscriber(topic)
            self.ros2_sub.frame_received.connect(self._on_frame)
            self.ros2_sub.start()
            self.src_status.setText(f"ROS2: {topic}")
        else:
            src = self.cam_spin.value() if sel == "cam" else self.file_edit.text().strip()
            if sel == "file" and not src:
                QtWidgets.QMessageBox.warning(self,"경고","파일 경로 선택"); return
            self.cap = cv2.VideoCapture(src)
            if not self.cap.isOpened():
                QtWidgets.QMessageBox.critical(self,"오류",f"열기 실패: {src}")
                self.cap = None; return
            self.src_status.setText(f"열림: {src}")
        self.open_btn.setEnabled(False); self.close_btn.setEnabled(True)
        self.display_timer.start(33)

    def _auto_open_source(self):
        idx = self.src_combo.currentIndex()
        sel = ["cam","file","ros2"][min(idx,2)]
        if sel == "ros2" and self.topic_edit.text().strip():
            self.open_source()
        elif sel == "file" and self.file_edit.text().strip():
            self.open_source()

    def close_source(self):
        self.display_timer.stop()
        if self.cap: self.cap.release(); self.cap = None
        if self.ros2_sub: self.ros2_sub.stop(); self.ros2_sub = None
        with self._frame_lock: self._cur_frame = None
        self.open_btn.setEnabled(True); self.close_btn.setEnabled(False)
        self.src_status.setText("소스 없음")
        for idx, img in enumerate(self.img_labels):
            img.clear(); img.setText(f"모델 {idx + 1} 대기")

    def _on_frame(self, frame):
        with self._frame_lock:
            self._cur_frame = frame.copy()

    # ── 리사이즈 ──────────────────────────────────────────────────────────────
    def _on_resize(self):
        self.disp_w = self.disp_w_sp.value()
        self.disp_h = self.disp_h_sp.value()
        for img in self.img_labels:
            img.setFixedSize(self.disp_w, self.disp_h)

    # ── 추론 루프 ─────────────────────────────────────────────────────────────
    def _tick(self):
        if self.cap and self.cap.isOpened():
            ret, frame = self.cap.read()
            if not ret:
                self.cap.set(cv2.CAP_PROP_POS_FRAMES, 0); return
            with self._frame_lock:
                self._cur_frame = frame.copy()

        with self._frame_lock:
            frame = self._cur_frame
        if frame is None:
            return

        allowed = self._allowed_classes()

        for idx in range(NUM_MODELS):
            model = self.models[idx]
            if model and allowed:
                try:
                    pos = run_inference(model, frame, self.confs[idx], allowed)
                    vis = draw_boxes(frame, pos)
                except Exception as e:
                    pos, vis = [], frame
                    print(f"[모델{idx + 1}] {e}")
            else:
                pos, vis = [], frame
            self.positions[idx] = pos
            self.img_labels[idx].setPixmap(frame_to_pixmap(vis, self.disp_w, self.disp_h))

        self._update_results()

    # ── 모델 관리 ─────────────────────────────────────────────────────────────
    def _refresh_models(self):
        files = list_pt_files()
        for combo in self.combos:
            combo.clear(); combo.addItems(files)

    def _load_model(self, rel: str, idx: int):
        """백그라운드 스레드 — Qt 위젯 직접 접근 금지, 시그널만 사용."""
        from ultralytics import YOLO
        path = WEIGHTS_DIR / rel
        try:
            m = YOLO(str(path))
            names = list(m.names.values())
            self.models[idx] = m
            self.sig_status.emit(idx, f"✅ {rel}\n클래스 {len(names)}개", PALETTE[idx])
            self.sig_loaded.emit(idx, rel)

            # 6개 모델 클래스 합집합 계산
            all_names = []
            seen = set()
            for mdl in self.models:
                if mdl:
                    for n in mdl.names.values():
                        if n not in seen:
                            all_names.append(n); seen.add(n)
            self.sig_classes.emit(all_names)   # 메인 스레드에서 체크박스 재구성
        except Exception as e:
            self.sig_error.emit(str(e))

    def _load_model_slot(self, idx):
        rel = self.combos[idx].currentText()
        if rel:
            self.sig_status.emit(idx, "로드 중...", "#888")
            threading.Thread(target=self._load_model, args=(rel, idx), daemon=True).start()

    # ── 결과 표시 ─────────────────────────────────────────────────────────────
    def _update_results(self):
        for idx in range(NUM_MODELS):
            pos = self.positions[idx]
            if not self.models[idx]:
                body = "미로드"
            elif not pos:
                body = f"검출 없음  (conf={self.confs[idx]:.2f})"
            else:
                body = "  |  ".join(f"{p['label']} {p['conf']:.2f}" for p in pos)
                body = f"({len(pos)}개, conf={self.confs[idx]:.2f})  {body}"
            self.result_labels[idx].setText(f"모델 {idx + 1} : {body}")

    # ── 설정 저장/복원 ────────────────────────────────────────────────────────
    def _save_settings(self):
        try:
            s = {
                'disp_w':     self.disp_w,
                'disp_h':     self.disp_h,
                'results_h':  self.results_h,
                'src_type':   self.src_combo.currentIndex(),
                'cam_num':    self.cam_spin.value(),
                'video_file': self.file_edit.text(),
                'ros2_topic': self.topic_edit.text(),
                'models':     [c.currentText() for c in self.combos],
                'master_conf': self.confs[0],
                'classes':    {k: cb.isChecked() for k, cb in self._class_checks.items()},
            }
            SETTINGS_FILE.write_text(json.dumps(s, ensure_ascii=False, indent=2))
        except Exception as e:
            print(f"[설정 저장 오류] {e}")

    def _load_settings(self):
        if not SETTINGS_FILE.exists():
            return
        try:
            s = json.loads(SETTINGS_FILE.read_text())

            self.disp_w = s.get('disp_w', self.disp_w)
            self.disp_h = s.get('disp_h', self.disp_h)
            self.disp_w_sp.setValue(self.disp_w)
            self.disp_h_sp.setValue(self.disp_h)

            self.results_h = s.get('results_h', self.results_h)
            self.results_h_sp.setValue(self.results_h)

            si = s.get('src_type', 0)
            if si < self.src_combo.count():
                self.src_combo.setCurrentIndex(si)
            self.cam_spin.setValue(s.get('cam_num', 0))
            vf = s.get('video_file', '')
            if vf:
                self.file_edit.setText(vf)
            topic = s.get('ros2_topic', '')
            if topic:
                self.topic_edit.setText(topic)
                if topic in ROS2_TOPIC_PRESETS:
                    self.topic_preset.setCurrentIndex(ROS2_TOPIC_PRESETS.index(topic))

            for idx, rel in enumerate(s.get('models', [])[:NUM_MODELS]):
                combo = self.combos[idx]
                for i in range(combo.count()):
                    if combo.itemText(i) == rel:
                        combo.setCurrentIndex(i); break

            self.master_slider.setValue(int(round(s.get('master_conf', 0.40) * 100)))

            # 클래스 체크 상태 — 모델 로드 후 _rebuild_class_panel 에서 적용
            self._saved_classes = s.get('classes', {})

            # 저장된 모델 6개 자동 로드
            for idx, rel in enumerate(s.get('models', [])[:NUM_MODELS]):
                if rel:
                    self._load_model_slot(idx)

            # 저장된 영상 소스 자동 열기
            self._auto_open_source()
        except Exception as e:
            print(f"[설정 로드 오류] {e}")

    def closeEvent(self, event):
        self._save_settings()
        self.close_source(); event.accept()


if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    win = InferenceSelUI()
    win.show()
    sys.exit(app.exec_())
