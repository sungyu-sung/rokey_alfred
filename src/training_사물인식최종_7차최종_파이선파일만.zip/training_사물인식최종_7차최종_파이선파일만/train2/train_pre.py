"""train_ir.py — YOLOv8-OBB IR 학습 매니저 (위/아래/각도 판별)

labeler_ir.py 가 생성한 OBB 라벨(YOLO OBB 형식)로 yolov8*-obb.pt 를 학습.
라벨 형식: class_idx x1 y1 x2 y2 x3 y3 x4 y4  (정규화, 4꼭짓점)
"""
import sys
import os
os.environ['QT_QPA_PLATFORM_PLUGIN_PATH'] = '/usr/lib/x86_64-linux-gnu/qt5/plugins'
os.environ['QT_QPA_PLATFORM'] = 'wayland'
import cv2
import shutil
import random
import numpy as np
import yaml
import torch
from pathlib import Path
from threading import Thread

from PyQt5 import QtWidgets, QtCore, QtGui
from ultralytics import YOLO


class TrainManager(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.base_dir    = Path(__file__).parent
        self.src_dir     = self.base_dir / "train_img_ir"
        self.dataset_dir = self.base_dir / "yolo_dataset"
        self._init_ui()

    def _init_ui(self):
        self.setWindowTitle("YOLOv8-OBB IR 학습 매니저 — 위/아래/각도 판별")
        self.setFixedSize(620, 780)
        layout = QtWidgets.QVBoxLayout(self)

        # 1. 데이터 증강
        aug_grp = QtWidgets.QGroupBox("1. 데이터 증강(Augmentation) 설정  [OBB 좌표 자동 변환]")
        aug_lay = QtWidgets.QGridLayout()
        self.chk_flip   = QtWidgets.QCheckBox("좌우 반전 (x 좌표 미러링)")
        self.chk_flip.setChecked(True)
        self.chk_bright = QtWidgets.QCheckBox("밝기 변화")
        self.chk_bright.setChecked(True)
        self.chk_blur   = QtWidgets.QCheckBox("흐림 효과(Gaussian Blur)")
        self.chk_noise  = QtWidgets.QCheckBox("노이즈 추가")
        aug_lay.addWidget(self.chk_flip,   0, 0)
        aug_lay.addWidget(self.chk_bright, 0, 1)
        aug_lay.addWidget(self.chk_blur,   1, 0)
        aug_lay.addWidget(self.chk_noise,  1, 1)
        aug_grp.setLayout(aug_lay)
        layout.addWidget(aug_grp)

        # 2. 학습 설정
        trn_grp = QtWidgets.QGroupBox("2. 학습 설정 및 하드웨어")
        t_lay   = QtWidgets.QFormLayout()

        dev_row = QtWidgets.QHBoxLayout()
        self.radio_gpu = QtWidgets.QRadioButton("GPU (NVIDIA CUDA)")
        self.radio_cpu = QtWidgets.QRadioButton("CPU")
        if torch.cuda.is_available():
            self.radio_gpu.setText(f"GPU: {torch.cuda.get_device_name(0)}")
            self.radio_gpu.setChecked(True)
        else:
            self.radio_gpu.setEnabled(False)
            self.radio_cpu.setChecked(True)
        dev_row.addWidget(self.radio_gpu)
        dev_row.addWidget(self.radio_cpu)

        self.epoch_sp = QtWidgets.QSpinBox()
        self.epoch_sp.setRange(1, 500); self.epoch_sp.setValue(50)
        self.batch_sp = QtWidgets.QSpinBox()
        self.batch_sp.setRange(1, 64);  self.batch_sp.setValue(16)

        # OBB 전용 기본 모델
        self.model_combo = QtWidgets.QComboBox()
        self.model_combo.addItems([
            "yolov8n-obb.pt",
            "yolov8s-obb.pt",
            "yolov8m-obb.pt",
            "yolov8l-obb.pt",
        ])

        t_lay.addRow("연산 장치:", dev_row)
        t_lay.addRow("Epochs:",    self.epoch_sp)
        t_lay.addRow("Batch Size:", self.batch_sp)
        t_lay.addRow("Base Model (OBB):", self.model_combo)
        trn_grp.setLayout(t_lay)
        layout.addWidget(trn_grp)

        # 3. 로그
        self.log_area = QtWidgets.QTextEdit()
        self.log_area.setReadOnly(True)
        self.log_area.setStyleSheet(
            "background:#1e1e1e;color:#d4d4d4;"
            "font-family:'Consolas',monospace;font-size:10pt;")
        layout.addWidget(self.log_area)

        # 4. 버튼
        btn_row = QtWidgets.QHBoxLayout()
        self.prepare_btn = QtWidgets.QPushButton("데이터셋 생성 및 검증")
        self.train_btn   = QtWidgets.QPushButton("학습 시작 (OBB Train)")
        self.train_btn.setEnabled(False)
        self.prepare_btn.clicked.connect(self.prepare_dataset)
        self.train_btn.clicked.connect(self.start_training)
        btn_row.addWidget(self.prepare_btn)
        btn_row.addWidget(self.train_btn)
        layout.addLayout(btn_row)

    def log(self, text: str):
        self.log_area.append(text)
        self.log_area.verticalScrollBar().setValue(
            self.log_area.verticalScrollBar().maximum())

    # ── 데이터셋 준비 ─────────────────────────────────────────────────────────
    def prepare_dataset(self):
        if not self.src_dir.exists():
            self.log("⚠ train_img_ir 폴더가 없습니다. 먼저 labeler_ir.py 로 라벨링하세요.")
            return

        self.log("📂 YOLO OBB 데이터셋 구조 생성 중...")
        if self.dataset_dir.exists():
            shutil.rmtree(self.dataset_dir)
        for p in ['train/images', 'train/labels', 'val/images', 'val/labels']:
            (self.dataset_dir / p).mkdir(parents=True, exist_ok=True)

        images = list(self.src_dir.glob("*.jpg"))
        if not images:
            self.log("⚠ 학습 이미지가 없습니다."); return

        random.shuffle(images)
        split = int(len(images) * 0.8)
        train_imgs = images[:split]
        val_imgs   = images[split:]

        ok_train = ok_val = 0
        for mode, files in [("train", train_imgs), ("val", val_imgs)]:
            for img_path in files:
                lbl_path = img_path.with_suffix('.txt')
                if not lbl_path.exists():
                    continue
                # 라벨 형식 검증 (OBB: 9 토큰)
                lines = [l for l in lbl_path.read_text().splitlines() if l.strip()]
                if not all(len(l.split()) == 9 for l in lines):
                    self.log(f"⚠ OBB 형식 아님(9토큰 필요), 건너뜀: {lbl_path.name}")
                    continue
                shutil.copy(img_path, self.dataset_dir / mode / "images" / img_path.name)
                shutil.copy(lbl_path, self.dataset_dir / mode / "labels" / lbl_path.name)
                if mode == "train":
                    ok_train += 1
                    self._augment(img_path, lbl_path)
                else:
                    ok_val += 1

        self._create_yaml()
        total = len(list((self.dataset_dir / "train/images").glob("*.jpg")))
        self.log(f"✅ 준비 완료  train={ok_train}  val={ok_val}  증강 후 합계={total}장")
        self.train_btn.setEnabled(True)

    def _augment(self, img_path: Path, lbl_path: Path):
        img    = cv2.imread(str(img_path))
        labels = [l for l in lbl_path.read_text().splitlines() if l.strip()]
        base   = img_path.stem

        if self.chk_flip.isChecked():
            aug = cv2.flip(img, 1)
            new_lbl = []
            for line in labels:
                parts = line.split()
                if len(parts) != 9:
                    new_lbl.append(line); continue
                c     = parts[0]
                coords = list(map(float, parts[1:]))
                # x 좌표(짝수 인덱스) 미러링: x_new = 1 - x_old
                for j in range(0, 8, 2):
                    coords[j] = 1.0 - coords[j]
                new_lbl.append(f"{c} " + " ".join(f"{v:.6f}" for v in coords))
            self._save_aug(f"{base}_flip", aug, new_lbl)

        if self.chk_bright.isChecked():
            val = random.randint(-40, 40)
            aug = np.clip(img.astype(np.int32) + val, 0, 255).astype(np.uint8)
            self._save_aug(f"{base}_brt", aug, labels)

        if self.chk_blur.isChecked():
            aug = cv2.GaussianBlur(img, (5, 5), 0)
            self._save_aug(f"{base}_blur", aug, labels)

        if self.chk_noise.isChecked():
            noise = np.random.randint(-20, 21, img.shape, dtype=np.int32)
            aug   = np.clip(img.astype(np.int32) + noise, 0, 255).astype(np.uint8)
            self._save_aug(f"{base}_noise", aug, labels)

    def _save_aug(self, name: str, img: np.ndarray, labels: list):
        cv2.imwrite(str(self.dataset_dir / "train/images" / f"{name}.jpg"), img)
        (self.dataset_dir / "train/labels" / f"{name}.txt").write_text("\n".join(labels))

    def _create_yaml(self):
        cls_file = self.src_dir / "classes.txt"
        classes  = (cls_file.read_text().splitlines()
                    if cls_file.exists() else ["object"])
        classes  = [c.strip() for c in classes if c.strip()]
        content  = {
            'path':  str(self.dataset_dir.absolute()),
            'train': 'train/images',
            'val':   'val/images',
            'names': {i: name for i, name in enumerate(classes)},
        }
        with open(self.dataset_dir / "data.yaml", "w", encoding="utf-8") as f:
            yaml.dump(content, f, allow_unicode=True, sort_keys=False)
        self.log(f"📄 data.yaml 생성  classes({len(classes)}): {classes}")

    # ── 학습 ─────────────────────────────────────────────────────────────────
    def start_training(self):
        model_name   = self.model_combo.currentText()
        epochs       = self.epoch_sp.value()
        batch        = self.batch_sp.value()
        device       = 0 if self.radio_gpu.isChecked() else 'cpu'
        device_name  = "GPU" if device == 0 else "CPU"

        self.log(f"\n--- OBB 학습 시작 (모델: {model_name}  장치: {device_name}) ---")
        self.prepare_btn.setEnabled(False)
        self.train_btn.setEnabled(False)

        def _train():
            try:
                model = YOLO(model_name)   # yolov8n-obb.pt 자동 다운로드
                model.train(
                    data     = str(self.dataset_dir / "data.yaml"),
                    epochs   = epochs,
                    batch    = batch,
                    imgsz    = 640,
                    device   = device,
                    project  = str(self.base_dir / "runs"),
                    name     = "ir_label_train",
                    exist_ok = True,
                    task     = 'obb',   # OBB 학습 태스크
                )
                self.log("\n🎉 OBB 학습 완료! runs/ir_label_train/weights/best.pt 확인하세요.")
            except Exception as e:
                self.log(f"\n❌ 학습 오류: {e}")
            finally:
                self.prepare_btn.setEnabled(True)
                self.train_btn.setEnabled(True)

        Thread(target=_train, daemon=True).start()


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    ex  = TrainManager()
    ex.show()
    sys.exit(app.exec_())
