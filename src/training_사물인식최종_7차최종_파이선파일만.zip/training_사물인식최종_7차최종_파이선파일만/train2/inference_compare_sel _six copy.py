#!/usr/bin/env python3
"""inference_compare_sel.py — YOLO 두 모델 비교 추론 (클래스 선택 + 개별 감도)"""
import os, sys, threading
os.environ['QT_QPA_PLATFORM_PLUGIN_PATH'] = '/usr/lib/x86_64-linux-gnu/qt5/plugins'
os.environ['QT_QPA_PLATFORM'] = 'wayland'

import cv2
import numpy as np
from pathlib import Path
from threading import Lock

from PyQt5 import QtWidgets, QtCore, QtGui
from PyQt5.QtCore import Qt, pyqtSignal, QThread, QTimer

WEIGHTS_DIR = Path("/home/han3/turtlebot4_ws/src/training/weights")
COL_A = (255, 120,   0)
COL_B = (  0, 200, 255)

ROS2_TOPIC_PRESETS = [
    "/robot2/oakd/rgb/image_raw/compressed",
    "/robot2/oakd/rgb/image_raw",
    "/robot4/oakd/rgb/image_raw/compressed",
    "/robot4/oakd/rgb/image_raw",
    "/camera/color/image_raw",
]

try:
    import rclpy
    from sensor_msgs.msg import Image, CompressedImage
    from cv_bridge import CvBridge
    ROS2_AVAILABLE = True
except ImportError:
    ROS2_AVAILABLE = False


# ── ROS2 구독 스레드 ──────────────────────────────────────────────────────────
class Ros2Subscriber(QThread):
    frame_received = pyqtSignal(object)

    def __init__(self, topic: str):
        super().__init__()
        self.topic         = topic
        self.is_compressed = topic.endswith("/compressed")
        self._stop         = threading.Event()
        self.bridge        = CvBridge()

    def run(self):
        if not rclpy.ok():
            rclpy.init()
        node = rclpy.create_node('inference_sel_sub')
        if self.is_compressed:
            node.create_subscription(CompressedImage, self.topic, self._cb_compressed, 10)
        else:
            node.create_subscription(Image, self.topic, self._cb_raw, 10)
        while not self._stop.is_set() and rclpy.ok():
            rclpy.spin_once(node, timeout_sec=0.05)
        node.destroy_node()

    def _cb_raw(self, msg):
        try:
            self.frame_received.emit(self.bridge.imgmsg_to_cv2(msg, 'bgr8'))
        except Exception:
            pass

    def _cb_compressed(self, msg):
        try:
            buf = np.frombuffer(msg.data, dtype=np.uint8)
            f   = cv2.imdecode(buf, cv2.IMREAD_COLOR)
            if f is not None:
                self.frame_received.emit(f)
        except Exception:
            pass

    def stop(self):
        self._stop.set()
        self.wait(2000)


# ── 유틸 ─────────────────────────────────────────────────────────────────────
def list_pt_files():
    if not WEIGHTS_DIR.exists():
        return []
    return [str(f.relative_to(WEIGHTS_DIR))
            for f in sorted(WEIGHTS_DIR.rglob("*.pt"))]


def run_inference(model, frame, conf, allowed: set):
    results   = model.predict(frame, conf=conf, verbose=False)
    positions = []
    for r in results:
        if r.boxes is not None and len(r.boxes):
            for box in r.boxes:
                lbl = model.names[int(box.cls[0])]
                if lbl not in allowed:
                    continue
                x1, y1, x2, y2 = box.xyxy[0].tolist()
                positions.append({'label': lbl, 'conf': float(box.conf[0]),
                                  'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2,
                                  'type': 'det'})
        elif r.obb is not None and len(r.obb):
            for box in r.obb:
                lbl = model.names[int(box.cls[0])]
                if lbl not in allowed:
                    continue
                corners = box.xyxyxyxy[0].cpu().numpy().astype(int)
                mn = corners.min(axis=0); mx = corners.max(axis=0)
                positions.append({'label': lbl, 'conf': float(box.conf[0]),
                                  'x1': mn[0], 'y1': mn[1], 'x2': mx[0], 'y2': mx[1],
                                  'corners': corners, 'type': 'obb'})
    return positions


def draw_boxes(frame, positions, col):
    vis = frame.copy()
    for p in positions:
        if p['type'] == 'obb':
            cv2.polylines(vis, [p['corners']], True, col, 2)
        else:
            cv2.rectangle(vis, (int(p['x1']), int(p['y1'])),
                               (int(p['x2']), int(p['y2'])), col, 2)
        cv2.putText(vis, f"{p['label']} {p['conf']:.2f}",
                    (int(p['x1']), max(int(p['y1']) - 6, 14)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.55, col, 2)
    return vis


def frame_to_pixmap(frame, w, h):
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    fh, fw, ch = rgb.shape
    qi = QtGui.QImage(rgb.data, fw, fh, ch * fw, QtGui.QImage.Format_RGB888)
    return QtGui.QPixmap.fromImage(qi).scaled(
        w, h, Qt.KeepAspectRatio, Qt.SmoothTransformation)


# ── 메인 UI ───────────────────────────────────────────────────────────────────
class InferenceSelUI(QtWidgets.QWidget):
    # 백그라운드 스레드 → 메인 스레드 안전 통신용 시그널
    sig_classes   = pyqtSignal(list)          # 클래스 목록 갱신
    sig_status_a  = pyqtSignal(str, str)      # (텍스트, 색)
    sig_status_b  = pyqtSignal(str, str)
    sig_error     = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        self.model_a     = None
        self.model_b     = None
        self.cap         = None
        self.ros2_sub    = None
        self._cur_frame  = None
        self._frame_lock = Lock()
        self._pos_a: list = []
        self._pos_b: list = []
        self.disp_w = 704
        self.disp_h = 704
        self.conf_a = 0.40
        self.conf_b = 0.40
        # 클래스명 → QCheckBox
        self._class_checks: dict[str, QtWidgets.QCheckBox] = {}

        self._init_ui()
        self._connect_signals()
        self._refresh_models()

        self.display_timer = QTimer(self)
        self.display_timer.timeout.connect(self._tick)

    def _connect_signals(self):
        self.sig_classes.connect(self._rebuild_class_panel)
        self.sig_status_a.connect(lambda t, c: (
            self.status_a.setText(t),
            self.status_a.setStyleSheet(f"color:{c};font-size:10px;")))
        self.sig_status_b.connect(lambda t, c: (
            self.status_b.setText(t),
            self.status_b.setStyleSheet(f"color:{c};font-size:10px;")))
        self.sig_error.connect(
            lambda msg: QtWidgets.QMessageBox.critical(self, "로드 실패", msg))

    # ── UI 구성 ───────────────────────────────────────────────────────────────
    def _init_ui(self):
        self.setWindowTitle("YOLO 두 모델 비교  [클래스 선택 + 개별 감도]")
        self.setMinimumSize(1300, 980)
        root = QtWidgets.QVBoxLayout(self)
        root.setSpacing(5); root.setContentsMargins(5, 5, 5, 5)

        # ── 행1: 소스 + 모델A + 모델B + 설정 ────────────────────────────────
        top = QtWidgets.QHBoxLayout()
        top.addWidget(self._make_src_panel())
        top.addWidget(self._make_model_panel('A'))
        top.addWidget(self._make_model_panel('B'))
        top.addWidget(self._make_opt_panel())
        root.addLayout(top)

        # ── 행2: 클래스 선택 패널 ────────────────────────────────────────────
        root.addWidget(self._make_class_panel())

        # ── 행3: 영상 두 개 ──────────────────────────────────────────────────
        mid = QtWidgets.QHBoxLayout()

        a_grp = QtWidgets.QGroupBox("모델 A  추론")
        a_grp.setStyleSheet("QGroupBox{color:#ff7800;}")
        a_lay = QtWidgets.QVBoxLayout(a_grp)
        self.img_a = QtWidgets.QLabel("모델 A 미로드")
        self.img_a.setFixedSize(self.disp_w, self.disp_h)
        self.img_a.setStyleSheet("background:#111;color:#555;")
        self.img_a.setAlignment(Qt.AlignCenter)
        self.det_a = QtWidgets.QLabel("—")
        self.det_a.setStyleSheet(
            "color:#ff9944;background:#180a00;padding:4px;"
            "font-family:monospace;font-size:10px;")
        self.det_a.setWordWrap(True); self.det_a.setMaximumHeight(60)
        a_lay.addWidget(self.img_a); a_lay.addWidget(self.det_a)
        mid.addWidget(a_grp)

        sep = QtWidgets.QFrame()
        sep.setFrameShape(QtWidgets.QFrame.VLine)
        sep.setStyleSheet("color:#333;")
        mid.addWidget(sep)

        b_grp = QtWidgets.QGroupBox("모델 B  추론")
        b_grp.setStyleSheet("QGroupBox{color:#00c8ff;}")
        b_lay = QtWidgets.QVBoxLayout(b_grp)
        self.img_b = QtWidgets.QLabel("모델 B 미로드")
        self.img_b.setFixedSize(self.disp_w, self.disp_h)
        self.img_b.setStyleSheet("background:#111;color:#555;")
        self.img_b.setAlignment(Qt.AlignCenter)
        self.det_b = QtWidgets.QLabel("—")
        self.det_b.setStyleSheet(
            "color:#00c8ff;background:#000f18;padding:4px;"
            "font-family:monospace;font-size:10px;")
        self.det_b.setWordWrap(True); self.det_b.setMaximumHeight(60)
        b_lay.addWidget(self.img_b); b_lay.addWidget(self.det_b)
        mid.addWidget(b_grp)
        root.addLayout(mid)

        # ── 행4: 결과 요약 ───────────────────────────────────────────────────
        sum_grp = QtWidgets.QGroupBox("감지 결과  — ● 주황=모델A   ◆ 청록=모델B")
        s_lay = QtWidgets.QVBoxLayout(sum_grp)
        self.quad_lbl = QtWidgets.QLabel()
        self.quad_lbl.setStyleSheet("background:#0e0e18;")
        self.quad_lbl.setMinimumHeight(140)
        s_lay.addWidget(self.quad_lbl)
        root.addWidget(sum_grp)

    # ── 소스 패널 ─────────────────────────────────────────────────────────────
    def _make_src_panel(self):
        src_grp = QtWidgets.QGroupBox("영상 소스")
        lay = QtWidgets.QVBoxLayout(src_grp)

        row = QtWidgets.QHBoxLayout()
        row.addWidget(QtWidgets.QLabel("소스:"))
        self.src_combo = QtWidgets.QComboBox()
        items = ["웹캠", "동영상 파일"]
        if ROS2_AVAILABLE:
            items.append("ROS2 토픽")
        self.src_combo.addItems(items)
        self.src_combo.currentIndexChanged.connect(self._on_src_type)
        row.addWidget(self.src_combo)
        lay.addLayout(row)

        self.cam_w = QtWidgets.QWidget()
        cr = QtWidgets.QHBoxLayout(self.cam_w); cr.setContentsMargins(0,0,0,0)
        cr.addWidget(QtWidgets.QLabel("번호:"))
        self.cam_spin = QtWidgets.QSpinBox(); self.cam_spin.setRange(0,10)
        cr.addWidget(self.cam_spin)
        lay.addWidget(self.cam_w)

        self.file_w = QtWidgets.QWidget()
        fr = QtWidgets.QHBoxLayout(self.file_w); fr.setContentsMargins(0,0,0,0)
        self.file_edit = QtWidgets.QLineEdit()
        self.file_edit.setPlaceholderText("동영상 파일...")
        fb = QtWidgets.QPushButton("찾기"); fb.clicked.connect(self._browse_video)
        fr.addWidget(self.file_edit); fr.addWidget(fb)
        self.file_w.setVisible(False)
        lay.addWidget(self.file_w)

        self.ros2_w = QtWidgets.QWidget()
        rc = QtWidgets.QVBoxLayout(self.ros2_w); rc.setContentsMargins(0,0,0,0)
        pr = QtWidgets.QHBoxLayout()
        pr.addWidget(QtWidgets.QLabel("프리셋:"))
        self.topic_preset = QtWidgets.QComboBox()
        self.topic_preset.addItems(ROS2_TOPIC_PRESETS + ["직접 입력..."])
        self.topic_preset.currentIndexChanged.connect(self._on_topic_preset)
        pr.addWidget(self.topic_preset); rc.addLayout(pr)
        tr = QtWidgets.QHBoxLayout()
        tr.addWidget(QtWidgets.QLabel("토픽:"))
        self.topic_edit = QtWidgets.QLineEdit(ROS2_TOPIC_PRESETS[0])
        tr.addWidget(self.topic_edit); rc.addLayout(tr)
        self.ros2_w.setVisible(False)
        lay.addWidget(self.ros2_w)

        ob = QtWidgets.QHBoxLayout()
        self.open_btn = QtWidgets.QPushButton("열기")
        self.open_btn.setFixedHeight(30)
        self.open_btn.setStyleSheet(
            "QPushButton{background:#1a5a1a;color:#88ff88;font-weight:bold;"
            "border:1px solid #336633;border-radius:3px;}"
            "QPushButton:hover{background:#2a7a2a;}")
        self.open_btn.clicked.connect(self.open_source)
        self.close_btn = QtWidgets.QPushButton("닫기")
        self.close_btn.setFixedHeight(30); self.close_btn.setEnabled(False)
        self.close_btn.clicked.connect(self.close_source)
        ob.addWidget(self.open_btn); ob.addWidget(self.close_btn)
        lay.addLayout(ob)
        self.src_status = QtWidgets.QLabel("소스 없음")
        self.src_status.setStyleSheet("color:#888;font-size:10px;")
        lay.addWidget(self.src_status)
        src_grp.setFixedWidth(250)
        return src_grp

    # ── 모델 패널 (A 또는 B) ─────────────────────────────────────────────────
    def _make_model_panel(self, slot: str):
        is_a   = (slot == 'A')
        col    = "#ff7800" if is_a else "#00c8ff"
        bg     = "#4a2000" if is_a else "#001a2a"
        hover  = "#6a3000" if is_a else "#003a4a"
        grp    = QtWidgets.QGroupBox(f"모델 {slot}  ({'주황' if is_a else '청록'})")
        grp.setStyleSheet(f"QGroupBox{{color:{col};font-weight:bold;}}")
        lay    = QtWidgets.QVBoxLayout(grp)

        combo  = QtWidgets.QComboBox(); combo.setMinimumWidth(200)
        btn    = QtWidgets.QPushButton(f"로드 {slot}")
        btn.setStyleSheet(
            f"QPushButton{{background:{bg};color:{col};border:1px solid {col};"
            f"border-radius:3px;font-weight:bold;}}"
            f"QPushButton:hover{{background:{hover};}}")
        status = QtWidgets.QLabel("미로드")
        status.setStyleSheet("color:#888;font-size:10px;")
        status.setWordWrap(True)

        # conf 슬라이더
        srow = QtWidgets.QHBoxLayout()
        srow.addWidget(QtWidgets.QLabel(f"감도 {slot}:"))
        slider = QtWidgets.QSlider(Qt.Horizontal)
        slider.setRange(5, 95); slider.setValue(40); slider.setTickInterval(5)
        slider.setStyleSheet(
            f"QSlider::groove:horizontal{{height:6px;background:#333;border-radius:3px;}}"
            f"QSlider::handle:horizontal{{width:14px;height:14px;margin:-4px 0;"
            f"background:{col};border-radius:7px;}}"
            f"QSlider::sub-page:horizontal{{background:{col};border-radius:3px;}}")
        lbl_conf = QtWidgets.QLabel("0.40")
        lbl_conf.setFixedWidth(34)
        lbl_conf.setStyleSheet(f"color:{col};font-weight:bold;")
        srow.addWidget(slider); srow.addWidget(lbl_conf)

        lay.addWidget(combo); lay.addWidget(btn)
        lay.addWidget(status); lay.addLayout(srow)

        if is_a:
            self.combo_a  = combo;  self.status_a  = status
            self.slider_a = slider; self.lbl_conf_a = lbl_conf
            btn.clicked.connect(self._load_a)
            slider.valueChanged.connect(self._on_slider_a)
        else:
            self.combo_b  = combo;  self.status_b  = status
            self.slider_b = slider; self.lbl_conf_b = lbl_conf
            btn.clicked.connect(self._load_b)
            slider.valueChanged.connect(self._on_slider_b)

        return grp

    # ── 설정 패널 ─────────────────────────────────────────────────────────────
    def _make_opt_panel(self):
        grp = QtWidgets.QGroupBox("설정")
        lay = QtWidgets.QFormLayout(grp)
        ref = QtWidgets.QPushButton("↺ 모델 목록")
        ref.clicked.connect(self._refresh_models)
        lay.addRow("", ref)
        self.disp_w_sp = QtWidgets.QSpinBox()
        self.disp_w_sp.setRange(160,1920); self.disp_w_sp.setSingleStep(32)
        self.disp_w_sp.setValue(704); self.disp_w_sp.valueChanged.connect(self._on_resize)
        lay.addRow("표시 너비:", self.disp_w_sp)
        self.disp_h_sp = QtWidgets.QSpinBox()
        self.disp_h_sp.setRange(120,1080); self.disp_h_sp.setSingleStep(32)
        self.disp_h_sp.setValue(704); self.disp_h_sp.valueChanged.connect(self._on_resize)
        lay.addRow("표시 높이:", self.disp_h_sp)
        return grp

    # ── 클래스 선택 패널 ─────────────────────────────────────────────────────
    def _make_class_panel(self):
        grp = QtWidgets.QGroupBox("사물 클래스 선택  (체크된 클래스만 인식)")
        grp.setStyleSheet("QGroupBox{font-weight:bold;color:#88ffcc;}")
        outer = QtWidgets.QVBoxLayout(grp)

        # 전체선택 / 전체해제
        btn_row = QtWidgets.QHBoxLayout()
        all_btn = QtWidgets.QPushButton("전체 선택")
        all_btn.setFixedWidth(90)
        all_btn.setStyleSheet(
            "QPushButton{background:#1a3a1a;color:#88ff88;border:1px solid #336633;"
            "border-radius:3px;font-size:11px;}"
            "QPushButton:hover{background:#2a5a2a;}")
        all_btn.clicked.connect(self._select_all)
        none_btn = QtWidgets.QPushButton("전체 해제")
        none_btn.setFixedWidth(90)
        none_btn.setStyleSheet(
            "QPushButton{background:#3a1a1a;color:#ff8888;border:1px solid #663333;"
            "border-radius:3px;font-size:11px;}"
            "QPushButton:hover{background:#5a2a2a;}")
        none_btn.clicked.connect(self._select_none)
        self.cls_info_lbl = QtWidgets.QLabel("모델 로드 후 클래스 표시")
        self.cls_info_lbl.setStyleSheet("color:#666;font-size:10px;")
        btn_row.addWidget(all_btn)
        btn_row.addWidget(none_btn)
        btn_row.addWidget(self.cls_info_lbl)
        btn_row.addStretch()
        outer.addLayout(btn_row)

        # 체크박스 영역 — QGridLayout (4열)
        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setMaximumHeight(160)
        scroll.setStyleSheet(
            "QScrollArea{border:1px solid #333;background:#0a0a0a;border-radius:4px;}")
        self._cls_container = QtWidgets.QWidget()
        self._cls_container.setStyleSheet("background:#0a0a0a;")
        self._cls_grid = QtWidgets.QGridLayout(self._cls_container)
        self._cls_grid.setSpacing(8)
        self._cls_grid.setContentsMargins(8, 6, 8, 6)
        scroll.setWidget(self._cls_container)
        outer.addWidget(scroll)
        return grp

    # ── 클래스 체크리스트 (메인 스레드에서만 호출) ────────────────────────────
    def _rebuild_class_panel(self, all_names: list):
        prev = {k: cb.isChecked() for k, cb in self._class_checks.items()}

        # 기존 위젯 제거
        for i in reversed(range(self._cls_grid.count())):
            w = self._cls_grid.itemAt(i).widget()
            if w:
                w.deleteLater()
        self._class_checks.clear()

        COLS = 4
        for idx, name in enumerate(all_names):
            cb = QtWidgets.QCheckBox(name)
            cb.setChecked(prev.get(name, True))
            cb.setMinimumWidth(110)
            cb.setStyleSheet(
                "QCheckBox{"
                "  color:#e8ffe8;"
                "  font-size:13px;"
                "  font-weight:bold;"
                "  padding:4px 8px;"
                "  background:#141414;"
                "  border:1px solid #333;"
                "  border-radius:4px;"
                "}"
                "QCheckBox:hover{"
                "  background:#1e2e1e;"
                "  border:1px solid #44aa66;"
                "}"
                "QCheckBox::indicator{"
                "  width:18px; height:18px;"
                "}"
                "QCheckBox::indicator:checked{"
                "  background:#22aa44;"
                "  border:2px solid #66dd88;"
                "  border-radius:4px;"
                "}"
                "QCheckBox::indicator:unchecked{"
                "  background:#1a1a1a;"
                "  border:2px solid #555;"
                "  border-radius:4px;"
                "}")
            row, col = divmod(idx, COLS)
            self._cls_grid.addWidget(cb, row, col)
            self._class_checks[name] = cb

        n = len(all_names)
        self.cls_info_lbl.setText(f"총 {n}개 클래스")
        self.cls_info_lbl.setStyleSheet("color:#88ffcc;font-size:11px;font-weight:bold;")

    def _allowed_classes(self) -> set:
        return {k for k, cb in self._class_checks.items() if cb.isChecked()}

    def _select_all(self):
        for cb in self._class_checks.values():
            cb.setChecked(True)

    def _select_none(self):
        for cb in self._class_checks.values():
            cb.setChecked(False)

    # ── 슬라이더 ─────────────────────────────────────────────────────────────
    def _on_slider_a(self, v):
        self.conf_a = v / 100.0
        self.lbl_conf_a.setText(f"{self.conf_a:.2f}")

    def _on_slider_b(self, v):
        self.conf_b = v / 100.0
        self.lbl_conf_b.setText(f"{self.conf_b:.2f}")

    # ── 소스 관리 ─────────────────────────────────────────────────────────────
    def _on_src_type(self, idx):
        sel = ["cam","file","ros2"][min(idx,2)]
        self.cam_w.setVisible(sel=="cam")
        self.file_w.setVisible(sel=="file")
        self.ros2_w.setVisible(sel=="ros2")

    def _on_topic_preset(self, idx):
        if idx < len(ROS2_TOPIC_PRESETS):
            self.topic_edit.setText(ROS2_TOPIC_PRESETS[idx])
            self.topic_edit.setReadOnly(True)
        else:
            self.topic_edit.setReadOnly(False); self.topic_edit.clear()

    def _browse_video(self):
        p, _ = QtWidgets.QFileDialog.getOpenFileName(
            self, "동영상 파일", "", "Video (*.mp4 *.avi *.mkv *.mov);;All (*)")
        if p: self.file_edit.setText(p)

    def open_source(self):
        self.close_source()
        idx = self.src_combo.currentIndex()
        sel = ["cam","file","ros2"][min(idx,2)]
        if sel == "ros2":
            if not ROS2_AVAILABLE:
                QtWidgets.QMessageBox.warning(self,"경고","ROS2 없음"); return
            topic = self.topic_edit.text().strip()
            if not topic:
                QtWidgets.QMessageBox.warning(self,"경고","토픽 입력"); return
            self.ros2_sub = Ros2Subscriber(topic)
            self.ros2_sub.frame_received.connect(self._on_frame)
            self.ros2_sub.start()
            self.src_status.setText(f"ROS2: {topic}")
        else:
            src = self.cam_spin.value() if sel == "cam" else self.file_edit.text().strip()
            if sel == "file" and not src:
                QtWidgets.QMessageBox.warning(self,"경고","파일 경로 선택"); return
            self.cap = cv2.VideoCapture(src)
            if not self.cap.isOpened():
                QtWidgets.QMessageBox.critical(self,"오류",f"열기 실패: {src}")
                self.cap = None; return
            self.src_status.setText(f"열림: {src}")
        self.open_btn.setEnabled(False); self.close_btn.setEnabled(True)
        self.display_timer.start(33)

    def close_source(self):
        self.display_timer.stop()
        if self.cap: self.cap.release(); self.cap = None
        if self.ros2_sub: self.ros2_sub.stop(); self.ros2_sub = None
        with self._frame_lock: self._cur_frame = None
        self.open_btn.setEnabled(True); self.close_btn.setEnabled(False)
        self.src_status.setText("소스 없음")
        self.img_a.clear(); self.img_a.setText("소스 닫힘")
        self.img_b.clear(); self.img_b.setText("소스 닫힘")

    def _on_frame(self, frame):
        with self._frame_lock:
            self._cur_frame = frame.copy()

    # ── 리사이즈 ──────────────────────────────────────────────────────────────
    def _on_resize(self):
        self.disp_w = self.disp_w_sp.value()
        self.disp_h = self.disp_h_sp.value()
        self.img_a.setFixedSize(self.disp_w, self.disp_h)
        self.img_b.setFixedSize(self.disp_w, self.disp_h)

    # ── 추론 루프 ─────────────────────────────────────────────────────────────
    def _tick(self):
        if self.cap and self.cap.isOpened():
            ret, frame = self.cap.read()
            if not ret:
                self.cap.set(cv2.CAP_PROP_POS_FRAMES, 0); return
            with self._frame_lock:
                self._cur_frame = frame.copy()

        with self._frame_lock:
            frame = self._cur_frame
        if frame is None:
            return

        allowed = self._allowed_classes()
        pos_a = pos_b = []
        vis_a = vis_b = frame

        if self.model_a:
            if allowed:
                try:
                    pos_a = run_inference(self.model_a, frame, self.conf_a, allowed)
                    vis_a = draw_boxes(frame, pos_a, COL_A)
                except Exception as e:
                    print(f"[A] {e}")
            else:
                vis_a = frame.copy()

        if self.model_b:
            if allowed:
                try:
                    pos_b = run_inference(self.model_b, frame, self.conf_b, allowed)
                    vis_b = draw_boxes(frame, pos_b, COL_B)
                except Exception as e:
                    print(f"[B] {e}")
            else:
                vis_b = frame.copy()

        self._pos_a, self._pos_b = pos_a, pos_b
        self.img_a.setPixmap(frame_to_pixmap(vis_a, self.disp_w, self.disp_h))
        self.img_b.setPixmap(frame_to_pixmap(vis_b, self.disp_w, self.disp_h))
        self._update_labels()
        self._update_summary()

    # ── 모델 관리 ─────────────────────────────────────────────────────────────
    def _refresh_models(self):
        files = list_pt_files()
        for c in (self.combo_a, self.combo_b):
            c.clear(); c.addItems(files)

    def _load_model(self, rel: str, slot: str):
        """백그라운드 스레드 — Qt 위젯 직접 접근 금지, 시그널만 사용."""
        from ultralytics import YOLO
        path = WEIGHTS_DIR / rel
        try:
            m = YOLO(str(path))
            names = list(m.names.values())
            if slot == 'A':
                self.model_a = m
                self.sig_status_a.emit(f"✅ {rel}\n{names}", "#ff9944")
            else:
                self.model_b = m
                self.sig_status_b.emit(f"✅ {rel}\n{names}", "#00c8ff")

            # 두 모델 클래스 합집합 계산
            all_names = []
            seen = set()
            for mdl in (self.model_a, self.model_b):
                if mdl:
                    for n in mdl.names.values():
                        if n not in seen:
                            all_names.append(n); seen.add(n)
            self.sig_classes.emit(all_names)   # 메인 스레드에서 체크박스 재구성
        except Exception as e:
            self.sig_error.emit(str(e))

    def _load_a(self):
        rel = self.combo_a.currentText()
        if rel:
            self.sig_status_a.emit("로드 중...", "#888")
            threading.Thread(target=self._load_model, args=(rel,'A'), daemon=True).start()

    def _load_b(self):
        rel = self.combo_b.currentText()
        if rel:
            self.sig_status_b.emit("로드 중...", "#888")
            threading.Thread(target=self._load_model, args=(rel,'B'), daemon=True).start()

    # ── 결과 표시 ─────────────────────────────────────────────────────────────
    def _update_labels(self):
        def fmt(pos, tag):
            if not pos: return f"[{tag}] 검출 없음"
            return "  |  ".join(f"{p['label']} {p['conf']:.2f}" for p in pos)
        self.det_a.setText(fmt(self._pos_a, 'A'))
        self.det_b.setText(fmt(self._pos_b, 'B'))

    def _update_summary(self):
        W = self.quad_lbl.width()  or 1200
        H = self.quad_lbl.height() or 140
        img = np.full((H, W, 3), (14,14,24), dtype=np.uint8)
        mid = W // 2
        cv2.line(img, (mid,0), (mid,H), (60,60,80), 1)
        cv2.putText(img, "Model A", (10,24), cv2.FONT_HERSHEY_SIMPLEX, 0.7, COL_A, 2)
        cv2.putText(img, "Model B", (mid+10,24), cv2.FONT_HERSHEY_SIMPLEX, 0.7, COL_B, 2)
        cv2.putText(img, f"conf={self.conf_a:.2f}", (W//4,24),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (180,120,60), 1)
        cv2.putText(img, f"conf={self.conf_b:.2f}", (mid+W//4,24),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (60,160,200), 1)
        for col_offset, pos, col in [(0,self._pos_a,COL_A),(mid,self._pos_b,COL_B)]:
            y = 52
            if not pos:
                cv2.putText(img, "(검출 없음)", (col_offset+10,y),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (100,100,100), 1)
            for p in pos:
                cv2.putText(img, f"{p['label']}  {p['conf']:.2f}",
                            (col_offset+10,y), cv2.FONT_HERSHEY_SIMPLEX, 0.55, col, 1)
                y += 26
                if y > H - 10: break
        cnt = f"A: {len(self._pos_a)}개   B: {len(self._pos_b)}개"
        cv2.putText(img, cnt, (W-180,H-8), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (180,180,180), 1)
        rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        qi  = QtGui.QImage(rgb.data, W, H, 3*W, QtGui.QImage.Format_RGB888)
        self.quad_lbl.setPixmap(QtGui.QPixmap.fromImage(qi))

    def closeEvent(self, event):
        self.close_source(); event.accept()


if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    win = InferenceSelUI()
    win.show()
    sys.exit(app.exec_())
