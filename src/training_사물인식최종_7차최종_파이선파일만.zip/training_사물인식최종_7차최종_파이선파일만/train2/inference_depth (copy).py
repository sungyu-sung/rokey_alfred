#!/usr/bin/env python3
"""inference_depth.py — YOLO 추론 + RGB-D 3D 좌표 계산

토픽 (고정):
  /camera/color/image_raw  — 컬러
  /camera/depth/image_raw  — 뎁스 (16UC1 mm / 32FC1 m)

기능:
  - YOLO 단일 모델 + 클래스 선택 체크박스
  - 마우스 4점 바닥면 설정 → 픽셀 + 3D 좌표 표시
  - 기준점(원점) 설정 → 사물 상대좌표(ΔX,ΔY,ΔZ)
  - 기하학적 투영: X=(u-cx)*Z/fx, Y=(v-cy)*Z/fy
"""
import os, sys, threading
os.environ['QT_QPA_PLATFORM_PLUGIN_PATH'] = '/usr/lib/x86_64-linux-gnu/qt5/plugins'
os.environ['QT_QPA_PLATFORM'] = 'wayland'

import cv2
import numpy as np
from pathlib import Path
from threading import Lock

from PyQt5 import QtWidgets, QtCore, QtGui
from PyQt5.QtCore import Qt, pyqtSignal, QThread, QTimer

WEIGHTS_DIR = Path("/home/han3/turtlebot4_ws/src/training/weights")
COLOR_TOPIC = "/camera/color/image_raw"
DEPTH_TOPIC = "/camera/depth/image_raw"
PT_BGR      = [(0,255,80), (255,128,0), (0,200,255), (255,0,200)]
PT_NAMES    = ["P1", "P2", "P3", "P4"]

try:
    import rclpy
    from sensor_msgs.msg import Image
    from cv_bridge import CvBridge
    ROS2_AVAILABLE = True
except ImportError:
    ROS2_AVAILABLE = False


# ── ROS2 구독 (color + depth 동시) ───────────────────────────────────────────
class Ros2DepthSub(QThread):
    color_rx = pyqtSignal(object)   # np.ndarray BGR
    depth_rx = pyqtSignal(object)   # np.ndarray float32 meters

    def __init__(self):
        super().__init__()
        self._stop  = threading.Event()
        self.bridge = CvBridge()

    def run(self):
        if not rclpy.ok():
            rclpy.init()
        node = rclpy.create_node('inf_depth_node')
        node.create_subscription(Image, COLOR_TOPIC, self._cb_color, 10)
        node.create_subscription(Image, DEPTH_TOPIC, self._cb_depth, 10)
        while not self._stop.is_set() and rclpy.ok():
            rclpy.spin_once(node, timeout_sec=0.05)
        node.destroy_node()

    def _cb_color(self, msg):
        try:
            self.color_rx.emit(self.bridge.imgmsg_to_cv2(msg, 'bgr8'))
        except Exception:
            pass

    def _cb_depth(self, msg):
        try:
            if msg.encoding == '32FC1':
                d = np.frombuffer(msg.data, dtype=np.float32).reshape(
                    msg.height, msg.width).copy()
            else:  # 16UC1 (mm)
                d = np.frombuffer(msg.data, dtype=np.uint16).reshape(
                    msg.height, msg.width).astype(np.float32) / 1000.0
            self.depth_rx.emit(d)
        except Exception:
            pass

    def stop(self):
        self._stop.set(); self.wait(2000)


# ── 클릭 가능한 이미지 레이블 (KeepAspectRatio 보정) ──────────────────────────
class ClickableLabel(QtWidgets.QLabel):
    clicked_px = pyqtSignal(int, int)

    def __init__(self):
        super().__init__()
        self._sw = 640; self._sh = 480
        self.setCursor(Qt.CrossCursor)

    def set_src(self, w, h):
        self._sw, self._sh = max(1, w), max(1, h)

    def _map(self, lx, ly):
        lw, lh = self.width(), self.height()
        s = min(lw / self._sw, lh / self._sh)
        dw, dh = self._sw * s, self._sh * s
        rx = lx - (lw - dw) / 2
        ry = ly - (lh - dh) / 2
        if 0 <= rx < dw and 0 <= ry < dh:
            return int(rx * self._sw / dw), int(ry * self._sh / dh)
        return None

    def mousePressEvent(self, ev):
        if ev.button() == Qt.LeftButton:
            r = self._map(ev.x(), ev.y())
            if r:
                self.clicked_px.emit(*r)
        super().mousePressEvent(ev)


# ── 유틸 ─────────────────────────────────────────────────────────────────────
def list_pt_files():
    if not WEIGHTS_DIR.exists():
        return []
    return [str(f.relative_to(WEIGHTS_DIR)) for f in sorted(WEIGHTS_DIR.rglob("*.pt"))]


def run_inference(model, frame, conf, allowed: set):
    out = []
    for r in model.predict(frame, conf=conf, verbose=False):
        if r.boxes is not None and len(r.boxes):
            for box in r.boxes:
                lbl = model.names[int(box.cls[0])]
                if lbl not in allowed:
                    continue
                x1, y1, x2, y2 = box.xyxy[0].tolist()
                out.append({'label': lbl, 'conf': float(box.conf[0]),
                            'cx': int((x1+x2)/2), 'cy': int((y1+y2)/2),
                            'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2, 'type': 'det'})
        elif r.obb is not None and len(r.obb):
            for box in r.obb:
                lbl = model.names[int(box.cls[0])]
                if lbl not in allowed:
                    continue
                corners = box.xyxyxyxy[0].cpu().numpy().astype(int)
                mn, mx = corners.min(0), corners.max(0)
                out.append({'label': lbl, 'conf': float(box.conf[0]),
                            'cx': int((mn[0]+mx[0])/2), 'cy': int((mn[1]+mx[1])/2),
                            'x1': mn[0], 'y1': mn[1], 'x2': mx[0], 'y2': mx[1],
                            'corners': corners, 'type': 'obb'})
    return out


def to_pixmap(frame, w, h):
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    fh, fw, ch = rgb.shape
    qi = QtGui.QImage(rgb.data, fw, fh, ch*fw, QtGui.QImage.Format_RGB888)
    return QtGui.QPixmap.fromImage(qi).scaled(w, h, Qt.KeepAspectRatio, Qt.SmoothTransformation)


# ── 메인 UI ───────────────────────────────────────────────────────────────────
class InferenceDepthUI(QtWidgets.QWidget):
    sig_classes   = pyqtSignal(list)
    sig_mdl_st    = pyqtSignal(str, str)   # (text, color)
    sig_error     = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        self.model        = None
        self.ros2_sub     = None
        self._clk         = Lock()
        self._dlk         = Lock()
        self._color_frame = None
        self._depth_frame = None
        self.conf         = 0.40
        self._floor_pts   = []      # list of {u,v,xyz}
        self._ref_uvxyz   = None    # (u,v,X,Y,Z)
        self._mode        = 'normal'
        self._class_checks: dict[str, QtWidgets.QCheckBox] = {}
        self._detections  = []

        self._init_ui()
        self.sig_classes.connect(self._rebuild_class_panel)
        self.sig_mdl_st.connect(lambda t, c: (
            self._mdl_lbl.setText(t),
            self._mdl_lbl.setStyleSheet(f"color:{c};font-size:10px;")))
        self.sig_error.connect(lambda m: QtWidgets.QMessageBox.critical(self, "오류", m))
        self._refresh_models()
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._tick)

    # ── UI 구성 ───────────────────────────────────────────────────────────────
    def _init_ui(self):
        self.setWindowTitle("YOLO Depth 추론  [RGB-D 3D 좌표]")
        self.setMinimumSize(1100, 980)
        root = QtWidgets.QVBoxLayout(self)
        root.setSpacing(4); root.setContentsMargins(5,5,5,5)
        root.addLayout(self._top_row())
        root.addWidget(self._class_panel())
        root.addWidget(self._floor_panel())
        root.addWidget(self._image_panel())
        root.addWidget(self._result_panel())

    # 행1: 연결 | 모델 | 카메라 파라미터 | 표시설정
    def _top_row(self):
        row = QtWidgets.QHBoxLayout()

        # 연결
        cg = QtWidgets.QGroupBox("ROS2 연결 (고정 토픽)")
        cl = QtWidgets.QVBoxLayout(cg)
        cl.addWidget(QtWidgets.QLabel(f"색상: {COLOR_TOPIC}"))
        cl.addWidget(QtWidgets.QLabel(f"뎁스: {DEPTH_TOPIC}"))
        br = QtWidgets.QHBoxLayout()
        self._conn_btn = QtWidgets.QPushButton("연결")
        self._conn_btn.setStyleSheet(
            "QPushButton{background:#1a5a1a;color:#88ff88;font-weight:bold;"
            "border:1px solid #336633;border-radius:3px;}"
            "QPushButton:hover{background:#2a7a2a;}")
        self._conn_btn.clicked.connect(self._connect)
        self._disc_btn = QtWidgets.QPushButton("해제")
        self._disc_btn.setEnabled(False)
        self._disc_btn.clicked.connect(self._disconnect)
        br.addWidget(self._conn_btn); br.addWidget(self._disc_btn)
        cl.addLayout(br)
        self._conn_lbl = QtWidgets.QLabel("미연결")
        self._conn_lbl.setStyleSheet("color:#888;font-size:10px;")
        cl.addWidget(self._conn_lbl)
        cg.setFixedWidth(260)
        row.addWidget(cg)

        # 모델
        mg = QtWidgets.QGroupBox("모델")
        ml = QtWidgets.QVBoxLayout(mg)
        self._mdl_combo = QtWidgets.QComboBox()
        lb = QtWidgets.QPushButton("로드")
        lb.setStyleSheet(
            "QPushButton{background:#2a2a4a;color:#aaaaff;border:1px solid #6666ff;"
            "border-radius:3px;font-weight:bold;}"
            "QPushButton:hover{background:#3a3a6a;}")
        lb.clicked.connect(self._load_model)
        self._mdl_lbl = QtWidgets.QLabel("미로드")
        self._mdl_lbl.setStyleSheet("color:#888;font-size:10px;")
        self._mdl_lbl.setWordWrap(True)
        sr = QtWidgets.QHBoxLayout()
        sr.addWidget(QtWidgets.QLabel("감도:"))
        self._conf_sl = QtWidgets.QSlider(Qt.Horizontal)
        self._conf_sl.setRange(5,95); self._conf_sl.setValue(40)
        self._conf_sl.setStyleSheet(
            "QSlider::groove:horizontal{height:6px;background:#333;border-radius:3px;}"
            "QSlider::handle:horizontal{width:14px;height:14px;margin:-4px 0;"
            "background:#aaaaff;border-radius:7px;}"
            "QSlider::sub-page:horizontal{background:#aaaaff;border-radius:3px;}")
        self._conf_lbl = QtWidgets.QLabel("0.40")
        self._conf_lbl.setFixedWidth(34)
        self._conf_lbl.setStyleSheet("color:#aaaaff;font-weight:bold;")
        self._conf_sl.valueChanged.connect(self._on_conf)
        sr.addWidget(self._conf_sl); sr.addWidget(self._conf_lbl)
        ml.addWidget(self._mdl_combo); ml.addWidget(lb)
        ml.addWidget(self._mdl_lbl); ml.addLayout(sr)
        row.addWidget(mg)

        # 카메라 내부 파라미터
        pg = QtWidgets.QGroupBox("카메라 내부 파라미터 (Intrinsics)")
        pl = QtWidgets.QFormLayout(pg)
        def dsp(v, mn=1.0, mx=9999.0):
            w = QtWidgets.QDoubleSpinBox()
            w.setRange(mn, mx); w.setValue(v); w.setDecimals(1); w.setFixedWidth(90)
            return w
        self._fx = dsp(615.0); self._fy = dsp(615.0)
        self._cx = dsp(320.0); self._cy = dsp(240.0)
        pl.addRow("fx (초점거리 x):", self._fx)
        pl.addRow("fy (초점거리 y):", self._fy)
        pl.addRow("cx (주점 x):", self._cx)
        pl.addRow("cy (주점 y):", self._cy)
        # 기하학적 투영 보조 (뎁스 없을 때)
        self._h_sp = QtWidgets.QDoubleSpinBox()
        self._h_sp.setRange(1,500); self._h_sp.setValue(150)
        self._h_sp.setSuffix(" cm"); self._h_sp.setFixedWidth(90)
        self._tilt_sp = QtWidgets.QDoubleSpinBox()
        self._tilt_sp.setRange(0,90); self._tilt_sp.setValue(0)
        self._tilt_sp.setSuffix("°"); self._tilt_sp.setFixedWidth(90)
        pl.addRow("카메라 높이 h:", self._h_sp)
        pl.addRow("틸트 각도 θ:", self._tilt_sp)
        row.addWidget(pg)

        # 표시 설정
        og = QtWidgets.QGroupBox("표시 설정")
        ol = QtWidgets.QFormLayout(og)
        rb = QtWidgets.QPushButton("↺ 모델 목록")
        rb.clicked.connect(self._refresh_models)
        ol.addRow("", rb)
        self._dw_sp = QtWidgets.QSpinBox()
        self._dw_sp.setRange(320,1920); self._dw_sp.setSingleStep(32)
        self._dw_sp.setValue(900); self._dw_sp.valueChanged.connect(self._on_resize)
        ol.addRow("표시 너비:", self._dw_sp)
        self._dh_sp = QtWidgets.QSpinBox()
        self._dh_sp.setRange(240,1080); self._dh_sp.setSingleStep(32)
        self._dh_sp.setValue(600); self._dh_sp.valueChanged.connect(self._on_resize)
        ol.addRow("표시 높이:", self._dh_sp)
        row.addWidget(og)
        return row

    # 클래스 선택 패널
    def _class_panel(self):
        grp = QtWidgets.QGroupBox("사물 클래스 선택  (체크된 클래스만 인식)")
        grp.setStyleSheet("QGroupBox{font-weight:bold;color:#88ffcc;}")
        outer = QtWidgets.QVBoxLayout(grp)
        br = QtWidgets.QHBoxLayout()
        ab = QtWidgets.QPushButton("전체 선택"); ab.setFixedWidth(90)
        ab.setStyleSheet("QPushButton{background:#1a3a1a;color:#88ff88;"
                         "border:1px solid #336633;border-radius:3px;font-size:11px;}"
                         "QPushButton:hover{background:#2a5a2a;}")
        ab.clicked.connect(self._sel_all)
        nb = QtWidgets.QPushButton("전체 해제"); nb.setFixedWidth(90)
        nb.setStyleSheet("QPushButton{background:#3a1a1a;color:#ff8888;"
                         "border:1px solid #663333;border-radius:3px;font-size:11px;}"
                         "QPushButton:hover{background:#5a2a2a;}")
        nb.clicked.connect(self._sel_none)
        self._cls_info = QtWidgets.QLabel("모델 로드 후 표시")
        self._cls_info.setStyleSheet("color:#666;font-size:10px;")
        br.addWidget(ab); br.addWidget(nb); br.addWidget(self._cls_info); br.addStretch()
        outer.addLayout(br)
        scroll = QtWidgets.QScrollArea(); scroll.setWidgetResizable(True)
        scroll.setMaximumHeight(130)
        scroll.setStyleSheet("QScrollArea{border:1px solid #333;background:#0a0a0a;border-radius:4px;}")
        self._cls_cont = QtWidgets.QWidget()
        self._cls_cont.setStyleSheet("background:#0a0a0a;")
        self._cls_grid = QtWidgets.QGridLayout(self._cls_cont)
        self._cls_grid.setSpacing(8); self._cls_grid.setContentsMargins(8,6,8,6)
        scroll.setWidget(self._cls_cont)
        outer.addWidget(scroll)
        return grp

    # 바닥면/기준점 패널
    def _floor_panel(self):
        grp = QtWidgets.QGroupBox("바닥면 4점 & 기준점 설정")
        grp.setStyleSheet("QGroupBox{font-weight:bold;color:#ffcc88;}")
        vl = QtWidgets.QVBoxLayout(grp)

        # 모드 선택 + 초기화 버튼
        mr = QtWidgets.QHBoxLayout()
        mr.addWidget(QtWidgets.QLabel("클릭 모드:"))
        self._mode_bg = QtWidgets.QButtonGroup(self)
        for i,(label,val) in enumerate([("일반","normal"),("바닥면 4점 설정","floor"),("기준점 설정","ref")]):
            rb = QtWidgets.QRadioButton(label)
            rb.setChecked(val=='normal')
            rb.toggled.connect(lambda ck, v=val: ck and setattr(self,'_mode',v))
            self._mode_bg.addButton(rb,i)
            mr.addWidget(rb)

        fc = QtWidgets.QPushButton("바닥점 초기화"); fc.setFixedWidth(100)
        fc.setStyleSheet("QPushButton{background:#2a1a00;color:#ffaa44;"
                         "border:1px solid #aa6600;border-radius:3px;font-size:10px;}"
                         "QPushButton:hover{background:#4a2a00;}")
        fc.clicked.connect(self._clear_floor)
        rc = QtWidgets.QPushButton("기준점 초기화"); rc.setFixedWidth(100)
        rc.setStyleSheet("QPushButton{background:#001a2a;color:#44aaff;"
                         "border:1px solid #006699;border-radius:3px;font-size:10px;}"
                         "QPushButton:hover{background:#002a3a;}")
        rc.clicked.connect(self._clear_ref)
        mr.addWidget(fc); mr.addWidget(rc); mr.addStretch()
        vl.addLayout(mr)

        self._floor_lbl = QtWidgets.QLabel("바닥점: (없음)  — 바닥면 4점 설정 모드에서 이미지 클릭")
        self._floor_lbl.setStyleSheet("color:#ffcc88;font-family:monospace;font-size:10px;")
        self._floor_lbl.setWordWrap(True)
        vl.addWidget(self._floor_lbl)

        self._ref_lbl = QtWidgets.QLabel("기준점: (미설정)  — 기준점 설정 모드에서 이미지 클릭")
        self._ref_lbl.setStyleSheet("color:#88ccff;font-family:monospace;font-size:10px;")
        vl.addWidget(self._ref_lbl)
        return grp

    # 영상 패널
    def _image_panel(self):
        grp = QtWidgets.QGroupBox("컬러 영상  (클릭 → 좌표 설정)")
        lay = QtWidgets.QVBoxLayout(grp)
        self._img = ClickableLabel()
        self._img.setFixedSize(900, 600)
        self._img.setStyleSheet("background:#111;color:#555;")
        self._img.setAlignment(Qt.AlignCenter)
        self._img.setText("연결 대기 중...")
        self._img.clicked_px.connect(self._on_click)
        lay.addWidget(self._img, alignment=Qt.AlignCenter)
        return grp

    # 결과 테이블
    def _result_panel(self):
        grp = QtWidgets.QGroupBox("감지 결과  (3D 좌표 + 상대좌표)")
        lay = QtWidgets.QVBoxLayout(grp)
        self._tbl = QtWidgets.QTableWidget(0, 8)
        self._tbl.setHorizontalHeaderLabels(
            ["클래스","감도","X(m)","Y(m)","Z(m)","ΔX(m)","ΔY(m)","ΔZ(m)"])
        self._tbl.setMaximumHeight(150)
        self._tbl.setStyleSheet(
            "QTableWidget{background:#0e0e1e;color:#cccccc;"
            "gridline-color:#333;font-family:monospace;font-size:11px;}"
            "QHeaderView::section{background:#1a1a2e;color:#88aaff;border:1px solid #333;}")
        self._tbl.horizontalHeader().setStretchLastSection(True)
        self._tbl.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        lay.addWidget(self._tbl)
        return grp

    # ── 클래스 패널 (메인 스레드에서만 호출됨) ────────────────────────────────
    def _rebuild_class_panel(self, names: list):
        prev = {k: cb.isChecked() for k, cb in self._class_checks.items()}
        for i in reversed(range(self._cls_grid.count())):
            w = self._cls_grid.itemAt(i).widget()
            if w: w.deleteLater()
        self._class_checks.clear()
        COLS = 5
        for idx, name in enumerate(names):
            cb = QtWidgets.QCheckBox(name)
            cb.setChecked(prev.get(name, True))
            cb.setMinimumWidth(100)
            cb.setStyleSheet(
                "QCheckBox{color:#e8ffe8;font-size:13px;font-weight:bold;"
                "padding:4px 8px;background:#141414;border:1px solid #333;border-radius:4px;}"
                "QCheckBox:hover{background:#1e2e1e;border:1px solid #44aa66;}"
                "QCheckBox::indicator{width:18px;height:18px;}"
                "QCheckBox::indicator:checked{background:#22aa44;border:2px solid #66dd88;border-radius:4px;}"
                "QCheckBox::indicator:unchecked{background:#1a1a1a;border:2px solid #555;border-radius:4px;}")
            self._cls_grid.addWidget(cb, idx // COLS, idx % COLS)
            self._class_checks[name] = cb
        self._cls_info.setText(f"총 {len(names)}개 클래스")
        self._cls_info.setStyleSheet("color:#88ffcc;font-size:11px;font-weight:bold;")

    def _allowed(self) -> set:
        return {k for k, cb in self._class_checks.items() if cb.isChecked()}

    def _sel_all(self):
        for cb in self._class_checks.values(): cb.setChecked(True)

    def _sel_none(self):
        for cb in self._class_checks.values(): cb.setChecked(False)

    # ── 3D 좌표 계산 ─────────────────────────────────────────────────────────
    def _get_3d(self, u: int, v: int):
        """픽셀(u,v) → (X,Y,Z) meters.  뎁스 우선, 없으면 기하학적 투영."""
        fx = self._fx.value(); fy = self._fy.value()
        cx = self._cx.value(); cy = self._cy.value()

        with self._dlk:
            depth = self._depth_frame

        if depth is not None:
            if 0 <= v < depth.shape[0] and 0 <= u < depth.shape[1]:
                Z = float(depth[v, u])
                if 0.05 < Z < 30.0:
                    X = (u - cx) * Z / fx
                    Y = (v - cy) * Z / fy
                    return (X, Y, Z)
            return None
        else:
            # 기하학적 투영 (뎁스 없을 때): h, tilt 사용
            H = self._h_sp.value() / 100.0   # cm → m
            theta = np.radians(self._tilt_sp.value())
            # ray in camera frame
            rx = (u - cx) / fx
            ry = (v - cy) / fy
            rz = 1.0
            # 카메라 tilt (X축 회전): world_y = ry*cos(θ) - rz*sin(θ)
            wy = ry * np.cos(theta) - rz * np.sin(theta)
            wz = ry * np.sin(theta) + rz * np.cos(theta)
            wx = rx
            # 바닥면(world Y=0) 교차: 카메라 위치 (0, H, 0)
            # t = -H / wy  (H + t*wy = 0)
            if abs(wy) < 1e-6:
                return None
            t = -H / wy
            if t < 0:
                return None
            return (t * wx, 0.0, t * wz)   # Y=0 바닥면

    def _relative(self, xyz):
        if self._ref_uvxyz is None or xyz is None:
            return None
        rx, ry, rz = self._ref_uvxyz[2], self._ref_uvxyz[3], self._ref_uvxyz[4]
        return (xyz[0]-rx, xyz[1]-ry, xyz[2]-rz)

    # ── 클릭 핸들러 ───────────────────────────────────────────────────────────
    def _on_click(self, u: int, v: int):
        xyz = self._get_3d(u, v)
        if self._mode == 'floor':
            if len(self._floor_pts) >= 4:
                self._floor_pts.clear()
            self._floor_pts.append({'u': u, 'v': v, 'xyz': xyz})
            self._upd_floor_lbl()
        elif self._mode == 'ref':
            if xyz:
                self._ref_uvxyz = (u, v, *xyz)
                self._ref_lbl.setText(
                    f"기준점  픽셀({u},{v})  →  "
                    f"X={xyz[0]:.3f}m  Y={xyz[1]:.3f}m  Z={xyz[2]:.3f}m")
                self._ref_lbl.setStyleSheet(
                    "color:#44ccff;font-family:monospace;font-size:10px;font-weight:bold;")
            else:
                QtWidgets.QMessageBox.warning(self,"경고","유효한 뎁스 값이 없는 위치입니다.")

    def _upd_floor_lbl(self):
        if not self._floor_pts:
            self._floor_lbl.setText("바닥점: (없음)")
            return
        parts = []
        for i, p in enumerate(self._floor_pts):
            xyz = p['xyz']
            if xyz:
                parts.append(f"{PT_NAMES[i]}: 픽셀({p['u']},{p['v']}) "
                             f"→ X={xyz[0]:.3f} Y={xyz[1]:.3f} Z={xyz[2]:.3f}m")
            else:
                parts.append(f"{PT_NAMES[i]}: 픽셀({p['u']},{p['v']}) → Z없음")
        self._floor_lbl.setText("   ".join(parts))

    def _clear_floor(self):
        self._floor_pts.clear()
        self._floor_lbl.setText("바닥점: (없음)")

    def _clear_ref(self):
        self._ref_uvxyz = None
        self._ref_lbl.setText("기준점: (미설정)")
        self._ref_lbl.setStyleSheet("color:#88ccff;font-family:monospace;font-size:10px;")

    # ── ROS2 연결 ─────────────────────────────────────────────────────────────
    def _connect(self):
        if not ROS2_AVAILABLE:
            QtWidgets.QMessageBox.warning(self,"경고","rclpy를 찾을 수 없습니다."); return
        self._disconnect()
        self.ros2_sub = Ros2DepthSub()
        self.ros2_sub.color_rx.connect(self._on_color)
        self.ros2_sub.depth_rx.connect(self._on_depth)
        self.ros2_sub.start()
        self._conn_btn.setEnabled(False); self._disc_btn.setEnabled(True)
        self._conn_lbl.setText("연결됨  ✅")
        self._conn_lbl.setStyleSheet("color:#88ff88;font-size:10px;")
        self.timer.start(33)

    def _disconnect(self):
        self.timer.stop()
        if self.ros2_sub: self.ros2_sub.stop(); self.ros2_sub = None
        with self._clk: self._color_frame = None
        with self._dlk: self._depth_frame = None
        self._conn_btn.setEnabled(True); self._disc_btn.setEnabled(False)
        self._conn_lbl.setText("미연결")
        self._conn_lbl.setStyleSheet("color:#888;font-size:10px;")
        self._img.clear(); self._img.setText("연결 해제됨")

    def _on_color(self, frame):
        with self._clk:
            self._color_frame = frame.copy()
        self._img.set_src(frame.shape[1], frame.shape[0])

    def _on_depth(self, depth):
        with self._dlk:
            self._depth_frame = depth.copy()

    # ── 설정 ─────────────────────────────────────────────────────────────────
    def _on_conf(self, v):
        self.conf = v / 100.0
        self._conf_lbl.setText(f"{self.conf:.2f}")

    def _on_resize(self):
        self._img.setFixedSize(self._dw_sp.value(), self._dh_sp.value())

    # ── 추론 루프 ─────────────────────────────────────────────────────────────
    def _tick(self):
        with self._clk:
            frame = self._color_frame
        if frame is None:
            return

        allowed = self._allowed()
        dets = []
        if self.model and allowed:
            try:
                for d in run_inference(self.model, frame, self.conf, allowed):
                    xyz  = self._get_3d(d['cx'], d['cy'])
                    dets.append({**d, 'xyz': xyz, 'rel': self._relative(xyz)})
            except Exception as e:
                print(f"[추론] {e}")
        self._detections = dets

        vis = self._draw(frame.copy(), dets)
        dw, dh = self._dw_sp.value(), self._dh_sp.value()
        self._img.setPixmap(to_pixmap(vis, dw, dh))
        self._upd_table(dets)

    # ── 오버레이 렌더링 ───────────────────────────────────────────────────────
    def _draw(self, vis, dets):
        # 감지 박스 + 3D 좌표 레이블
        for d in dets:
            col = (0, 255, 160)
            if d['type'] == 'obb':
                cv2.polylines(vis, [d['corners']], True, col, 2)
            else:
                cv2.rectangle(vis, (int(d['x1']),int(d['y1'])),
                              (int(d['x2']),int(d['y2'])), col, 2)
            # 좌표 텍스트 (두 줄: 라벨+감도 / 3D좌표)
            xyz = d['xyz']
            rel = d['rel']
            y0 = max(int(d['y1'])-20, 14)
            cv2.putText(vis, f"{d['label']} {d['conf']:.2f}",
                        (int(d['x1']), y0), cv2.FONT_HERSHEY_SIMPLEX, 0.5, col, 1)
            if xyz:
                coord = f"X:{xyz[0]:.2f} Y:{xyz[1]:.2f} Z:{xyz[2]:.2f}m"
                if rel:
                    coord += f"  d({rel[0]:+.2f},{rel[1]:+.2f},{rel[2]:+.2f})"
                cv2.putText(vis, coord, (int(d['x1']), y0+16),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.4, (180,255,180), 1)

        # 바닥면 4점
        px_list = []
        for i, p in enumerate(self._floor_pts):
            col = PT_BGR[i]
            u, v = p['u'], p['v']
            px_list.append((u, v))
            cv2.circle(vis, (u,v), 9, col, -1)
            cv2.circle(vis, (u,v), 11, (255,255,255), 1)
            xyz = p['xyz']
            tag = (f"{PT_NAMES[i]} ({xyz[0]:.2f},{xyz[1]:.2f},{xyz[2]:.2f}m)"
                   if xyz else f"{PT_NAMES[i]} N/A")
            cv2.putText(vis, tag, (u+13, v+5),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.42, col, 1)
        # 연결선
        n = len(px_list)
        for j in range(n):
            cv2.line(vis, px_list[j], px_list[(j+1)%n], (200,200,60), 1)

        # 기준점 (원점)
        if self._ref_uvxyz:
            ru, rv = self._ref_uvxyz[0], self._ref_uvxyz[1]
            cv2.drawMarker(vis, (ru,rv), (0,200,255),
                           cv2.MARKER_CROSS, 20, 2)
            cv2.circle(vis, (ru,rv), 12, (0,200,255), 1)
            cv2.putText(vis, "REF(0,0,0)", (ru+14, rv+5),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0,200,255), 1)

        # 현재 모드 힌트
        hints = {"floor": "▶ 바닥면 클릭 (최대 4점, 4점 후 초기화됨)",
                 "ref":   "▶ 기준점 클릭 (상대좌표 원점)"}
        if self._mode in hints:
            cv2.putText(vis, hints[self._mode], (10, vis.shape[0]-10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0,220,255), 2)
        return vis

    # ── 결과 테이블 ───────────────────────────────────────────────────────────
    def _upd_table(self, dets):
        self._tbl.setRowCount(len(dets))
        for r, d in enumerate(dets):
            xyz = d['xyz']; rel = d['rel']
            for c, v in enumerate([
                d['label'],
                f"{d['conf']:.2f}",
                f"{xyz[0]:.3f}" if xyz else "—",
                f"{xyz[1]:.3f}" if xyz else "—",
                f"{xyz[2]:.3f}" if xyz else "—",
                f"{rel[0]:+.3f}" if rel else "—",
                f"{rel[1]:+.3f}" if rel else "—",
                f"{rel[2]:+.3f}" if rel else "—",
            ]):
                it = QtWidgets.QTableWidgetItem(v)
                it.setTextAlignment(Qt.AlignCenter)
                self._tbl.setItem(r, c, it)

    # ── 모델 관리 ─────────────────────────────────────────────────────────────
    def _refresh_models(self):
        files = list_pt_files()
        self._mdl_combo.clear(); self._mdl_combo.addItems(files)

    def _load_model(self):
        rel = self._mdl_combo.currentText()
        if not rel: return
        self.sig_mdl_st.emit("로드 중...", "#888888")
        threading.Thread(target=self._do_load, args=(rel,), daemon=True).start()

    def _do_load(self, rel: str):
        from ultralytics import YOLO
        try:
            m = YOLO(str(WEIGHTS_DIR / rel))
            names = list(m.names.values())
            self.model = m
            self.sig_classes.emit(names)
            self.sig_mdl_st.emit(f"✅ {rel}  ({len(names)}cls)", "#aaaaff")
        except Exception as e:
            self.sig_error.emit(str(e))

    def closeEvent(self, ev):
        self._disconnect(); ev.accept()


if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    win = InferenceDepthUI()
    win.show()
    sys.exit(app.exec_())
