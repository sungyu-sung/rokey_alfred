#!/usr/bin/env python3
import argparse
import cv2
import numpy as np
from datetime import datetime
from pathlib import Path
from typing import Optional


def decode_compressed(data: bytes) -> Optional[np.ndarray]:
    arr = np.frombuffer(data, dtype=np.uint8)
    frame = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    return frame  # None if decode fails


def main():
    import rclpy
    from rclpy.node import Node
    from sensor_msgs.msg import CompressedImage
    from collect.webcam_capture import save_frame

    class OakdCapture(Node):
        def __init__(self, namespace: str, output_dir: Path):
            super().__init__('oakd_capture')
            self._output_dir = output_dir
            self._output_dir.mkdir(parents=True, exist_ok=True)
            self._latest_frame: Optional[np.ndarray] = None
            self._count = 0
            self._running = True

            topic = f"{namespace}/oakd/rgb/image_raw/compressed"
            self.create_subscription(CompressedImage, topic, self._image_cb, 10)
            self.create_timer(1 / 30, self._display_cb)
            self.get_logger().info(f"구독: {topic}")
            self.get_logger().info("SPACE: 저장 | q: 종료")

        def _image_cb(self, msg: CompressedImage):
            frame = decode_compressed(bytes(msg.data))
            if frame is not None:
                self._latest_frame = frame

        def _display_cb(self):
            if self._latest_frame is None:
                return
            cv2.imshow("OAK-D Capture", self._latest_frame)
            key = cv2.waitKey(1) & 0xFF
            if key == ord(' '):
                try:
                    path = save_frame(self._latest_frame, self._output_dir)
                    self._count += 1
                    self.get_logger().info(f"[{self._count}] 저장: {path.name}")
                except RuntimeError as e:
                    self.get_logger().error(f"저장 실패: {e}")
            elif key == ord('q'):
                self._running = False

    parser = argparse.ArgumentParser(description='OAK-D 이미지 수집 (ROS2)')
    parser.add_argument('--namespace', type=str, default='/robot4')
    parser.add_argument('--output', type=str, default='../data/images/raw')
    args, ros_args = parser.parse_known_args()

    rclpy.init(args=ros_args)
    node = OakdCapture(args.namespace, Path(args.output))
    try:
        while rclpy.ok() and node._running:
            rclpy.spin_once(node, timeout_sec=0.033)
    finally:
        cv2.destroyAllWindows()
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
