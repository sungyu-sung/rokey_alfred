#!/usr/bin/env python3
import sys
import os
import threading
import time

# cv2 bundled Qt와 PyQt5 충돌 방지 — cv2 import 전에 설정
os.environ['QT_QPA_PLATFORM_PLUGIN_PATH'] = '/usr/lib/x86_64-linux-gnu/qt5/plugins'
os.environ['QT_QPA_PLATFORM'] = 'wayland'

import cv2
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QLabel, QPushButton,
    QLineEdit, QSpinBox, QDoubleSpinBox, QVBoxLayout, QHBoxLayout,
    QGroupBox, QFileDialog, QMessageBox, QComboBox, QStatusBar
)
from PyQt5.QtCore import Qt, QTimer, QThread, pyqtSignal
from PyQt5.QtGui import QImage, QPixmap, QFont

BASE_DIR = "/home/han3/turtlebot4_ws/src/training/label_image_saved"

# ROS2 optional import
try:
    import numpy as np
    import rclpy
    from rclpy.node import Node
    from sensor_msgs.msg import Image, CompressedImage
    from cv_bridge import CvBridge
    ROS2_AVAILABLE = True
except ImportError:
    ROS2_AVAILABLE = False

ROS2_TOPIC_PRESETS = [
    "/robot2/oakd/rgb/image_raw",
    "/robot2/oakd/rgb/image_raw/compressed",
    "/camera/color/image_raw",
]


class Ros2ImageSubscriber(QThread):
    """ROS2 이미지 토픽 구독 스레드. raw / compressed 자동 감지."""
    frame_received = pyqtSignal(object)  # numpy array

    def __init__(self, topic: str):
        super().__init__()
        self.topic = topic
        self.is_compressed = topic.endswith("/compressed")
        self._stop_event = threading.Event()
        self.bridge = CvBridge()
        self.node = None

    def run(self):
        if not rclpy.ok():
            rclpy.init()
        self.node = rclpy.create_node('label_capture_subscriber')
        if self.is_compressed:
            self.node.create_subscription(
                CompressedImage, self.topic, self._callback_compressed, 10
            )
        else:
            self.node.create_subscription(
                Image, self.topic, self._callback_raw, 10
            )
        while not self._stop_event.is_set() and rclpy.ok():
            rclpy.spin_once(self.node, timeout_sec=0.05)
        self.node.destroy_node()

    def _callback_raw(self, msg):
        try:
            frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
            self.frame_received.emit(frame)
        except Exception:
            pass

    def _callback_compressed(self, msg):
        try:
            buf = np.frombuffer(msg.data, dtype=np.uint8)
            frame = cv2.imdecode(buf, cv2.IMREAD_COLOR)
            if frame is not None:
                self.frame_received.emit(frame)
        except Exception:
            pass

    def stop(self):
        self._stop_event.set()
        self.wait(2000)


class CaptureWorker(QThread):
    progress = pyqtSignal(int, str)
    finished = pyqtSignal()
    error = pyqtSignal(str)

    def __init__(self, frame_getter, save_dir, interval, total):
        super().__init__()
        self.frame_getter = frame_getter   # callable → numpy array | None
        self.save_dir = save_dir
        self.interval = interval
        self.total = total
        self._stop = False

    def stop(self):
        self._stop = True

    def run(self):
        os.makedirs(self.save_dir, exist_ok=True)
        for i in range(self.total):
            if self._stop:
                break
            frame = self.frame_getter()
            if frame is None:
                self.error.emit("프레임 없음 — 영상 소스를 확인하세요")
                break
            timestamp = time.strftime("%Y%m%d_%H%M%S") + f"_{i:04d}"
            path = os.path.join(self.save_dir, f"{timestamp}.jpg")
            cv2.imwrite(path, frame)
            self.progress.emit(i + 1, path)
            if i < self.total - 1:
                time.sleep(self.interval)
        self.finished.emit()


class VideoLabel(QLabel):
    def __init__(self):
        super().__init__()
        self.setAlignment(Qt.AlignCenter)
        self.setMinimumSize(640, 480)
        self._set_idle()

    def _set_idle(self):
        self.clear()
        self.setText("영상 없음\n\n소스를 선택하고 [열기] 버튼을 누르세요")
        self.setFont(QFont("Arial", 14))
        self.setStyleSheet(
            "background-color: #1a1a1a; border: 2px solid #444; color: #888;"
        )

    def show_frame(self, frame):
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb.shape
        qimg = QImage(rgb.data, w, h, ch * w, QImage.Format_RGB888)
        pix = QPixmap.fromImage(qimg)
        self.setPixmap(
            pix.scaled(self.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
        )


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        # 영상 소스 상태
        self.cap = None              # OpenCV capture (webcam/file)
        self.ros2_sub = None         # Ros2ImageSubscriber thread
        self.current_frame = None    # 최신 프레임 (numpy array)
        self._frame_lock = threading.Lock()

        self.display_timer = QTimer()
        self.display_timer.timeout.connect(self._display_frame)

        self.worker = None
        self.burst_running = False

        self.setWindowTitle("Label Image Capture Tool")
        self.setMinimumSize(960, 680)
        self._build_ui()

    # ── UI 구성 ────────────────────────────────────────────────────────────
    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QHBoxLayout(central)
        root.setSpacing(10)
        root.setContentsMargins(10, 10, 10, 10)

        self.video_label = VideoLabel()
        root.addWidget(self.video_label, stretch=3)

        panel = QVBoxLayout()
        panel.setSpacing(10)
        root.addLayout(panel, stretch=1)

        # 소스 설정
        src_group = QGroupBox("영상 소스")
        src_layout = QVBoxLayout(src_group)

        src_type_row = QHBoxLayout()
        src_type_row.addWidget(QLabel("소스 타입:"))
        self.src_combo = QComboBox()
        items = ["웹캠", "동영상 파일"]
        if ROS2_AVAILABLE:
            items.append("ROS2 토픽")
        self.src_combo.addItems(items)
        self.src_combo.currentIndexChanged.connect(self._on_src_type_change)
        src_type_row.addWidget(self.src_combo)
        src_layout.addLayout(src_type_row)

        # 웹캠 행
        self.cam_widget = QWidget()
        cam_row = QHBoxLayout(self.cam_widget)
        cam_row.setContentsMargins(0, 0, 0, 0)
        cam_row.addWidget(QLabel("카메라 번호:"))
        self.cam_spin = QSpinBox()
        self.cam_spin.setRange(0, 10)
        cam_row.addWidget(self.cam_spin)
        src_layout.addWidget(self.cam_widget)

        # 파일 행
        self.file_widget = QWidget()
        file_row = QHBoxLayout(self.file_widget)
        file_row.setContentsMargins(0, 0, 0, 0)
        self.file_edit = QLineEdit()
        self.file_edit.setPlaceholderText("동영상 파일 경로...")
        file_btn = QPushButton("찾기")
        file_btn.clicked.connect(self._browse_video)
        file_row.addWidget(self.file_edit)
        file_row.addWidget(file_btn)
        self.file_widget.setVisible(False)
        src_layout.addWidget(self.file_widget)

        # ROS2 토픽 행
        self.ros2_widget = QWidget()
        ros2_col = QVBoxLayout(self.ros2_widget)
        ros2_col.setContentsMargins(0, 0, 0, 0)
        ros2_col.setSpacing(4)

        preset_row = QHBoxLayout()
        preset_row.addWidget(QLabel("프리셋:"))
        self.topic_preset = QComboBox()
        self.topic_preset.addItems(ROS2_TOPIC_PRESETS + ["직접 입력..."])
        self.topic_preset.currentIndexChanged.connect(self._on_topic_preset_change)
        preset_row.addWidget(self.topic_preset)
        ros2_col.addLayout(preset_row)

        custom_row = QHBoxLayout()
        custom_row.addWidget(QLabel("토픽:"))
        self.topic_edit = QLineEdit(ROS2_TOPIC_PRESETS[0])
        custom_row.addWidget(self.topic_edit)
        ros2_col.addLayout(custom_row)

        self.ros2_widget.setVisible(False)
        src_layout.addWidget(self.ros2_widget)

        open_row = QHBoxLayout()
        self.open_btn = QPushButton("열기")
        self.open_btn.setFixedHeight(36)
        self.open_btn.clicked.connect(self.open_source)
        self.close_btn = QPushButton("닫기")
        self.close_btn.setFixedHeight(36)
        self.close_btn.clicked.connect(self.close_source)
        self.close_btn.setEnabled(False)
        open_row.addWidget(self.open_btn)
        open_row.addWidget(self.close_btn)
        src_layout.addLayout(open_row)
        panel.addWidget(src_group)

        # 저장 폴더
        dir_group = QGroupBox("저장 폴더 설정")
        dir_layout = QVBoxLayout(dir_group)
        dir_layout.addWidget(QLabel(f"기본 경로: {BASE_DIR}/"))
        dir_layout.addWidget(QLabel("하위 폴더 이름:"))
        self.folder_edit = QLineEdit()
        self.folder_edit.setPlaceholderText("예: cat, dog, person ...")
        dir_layout.addWidget(self.folder_edit)
        self.save_path_label = QLabel("")
        self.save_path_label.setStyleSheet("color: #888; font-size: 10px;")
        self.save_path_label.setWordWrap(True)
        dir_layout.addWidget(self.save_path_label)
        self.folder_edit.textChanged.connect(self._update_path_label)
        panel.addWidget(dir_group)

        # 연속 저장
        burst_group = QGroupBox("연속 저장 설정")
        burst_layout = QVBoxLayout(burst_group)

        interval_row = QHBoxLayout()
        interval_row.addWidget(QLabel("간격 (초):"))
        self.interval_spin = QDoubleSpinBox()
        self.interval_spin.setRange(0.1, 60.0)
        self.interval_spin.setSingleStep(0.1)
        self.interval_spin.setValue(0.5)
        self.interval_spin.setDecimals(1)
        interval_row.addWidget(self.interval_spin)
        burst_layout.addLayout(interval_row)

        count_row = QHBoxLayout()
        count_row.addWidget(QLabel("총 장 수:"))
        self.count_spin = QSpinBox()
        self.count_spin.setRange(1, 9999)
        self.count_spin.setValue(10)
        count_row.addWidget(self.count_spin)
        burst_layout.addLayout(count_row)

        self.progress_label = QLabel("대기 중")
        self.progress_label.setAlignment(Qt.AlignCenter)
        burst_layout.addWidget(self.progress_label)

        self.burst_btn = QPushButton("연속 저장 시작")
        self.burst_btn.setFixedHeight(40)
        self.burst_btn.setStyleSheet(self._btn_style("#2a7a2a", "#3a9a3a"))
        self.burst_btn.clicked.connect(self.toggle_burst)
        self.burst_btn.setEnabled(False)
        burst_layout.addWidget(self.burst_btn)
        panel.addWidget(burst_group)

        # 단일 저장
        single_group = QGroupBox("한 장 저장")
        single_layout = QVBoxLayout(single_group)
        self.single_btn = QPushButton("지금 저장 (스냅샷)")
        self.single_btn.setFixedHeight(40)
        self.single_btn.setStyleSheet(self._btn_style("#2a4a8a", "#3a6aaa"))
        self.single_btn.clicked.connect(self.save_single)
        self.single_btn.setEnabled(False)
        single_layout.addWidget(self.single_btn)
        panel.addWidget(single_group)

        panel.addStretch()

        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("준비")

    def _btn_style(self, base, hover):
        return (
            f"QPushButton {{ background-color: {base}; color: white; font-weight: bold; border-radius: 4px; }}"
            f"QPushButton:hover {{ background-color: {hover}; }}"
            "QPushButton:disabled { background-color: #555; color: #999; }"
        )

    # ── 소스 타입 전환 ────────────────────────────────────────────────────
    def _on_src_type_change(self, idx):
        labels = ["cam", "file", "ros2"]
        sel = labels[idx] if idx < len(labels) else "cam"
        self.cam_widget.setVisible(sel == "cam")
        self.file_widget.setVisible(sel == "file")
        self.ros2_widget.setVisible(sel == "ros2")

    def _on_topic_preset_change(self, idx):
        presets = ROS2_TOPIC_PRESETS
        if idx < len(presets):
            self.topic_edit.setText(presets[idx])
            self.topic_edit.setReadOnly(True)
        else:
            self.topic_edit.setReadOnly(False)
            self.topic_edit.clear()
            self.topic_edit.setFocus()

    def _browse_video(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "동영상 파일 선택", "",
            "Video Files (*.mp4 *.avi *.mkv *.mov *.wmv);;All Files (*)"
        )
        if path:
            self.file_edit.setText(path)

    def _update_path_label(self, text):
        if text.strip():
            self.save_path_label.setText(f"→ {os.path.join(BASE_DIR, text.strip())}")
        else:
            self.save_path_label.setText("")

    def _get_save_dir(self):
        folder = self.folder_edit.text().strip()
        if not folder:
            QMessageBox.warning(self, "경고", "하위 폴더 이름을 입력하세요.")
            return None
        return os.path.join(BASE_DIR, folder)

    # ── 소스 열기/닫기 ────────────────────────────────────────────────────
    def open_source(self):
        self.close_source()
        idx = self.src_combo.currentIndex()
        labels = ["cam", "file", "ros2"]
        sel = labels[idx] if idx < len(labels) else "cam"

        if sel == "ros2":
            self._open_ros2()
        else:
            self._open_opencv(sel)

    def _open_opencv(self, sel):
        src = self.cam_spin.value() if sel == "cam" else self.file_edit.text().strip()
        if sel == "file" and not src:
            QMessageBox.warning(self, "경고", "동영상 파일을 선택하세요.")
            return
        self.cap = cv2.VideoCapture(src)
        if not self.cap.isOpened():
            QMessageBox.critical(self, "오류", f"영상 열기 실패: {src}")
            self.cap = None
            return
        self.display_timer.start(33)
        self._set_open_ui(f"열림: {src}")

    def _open_ros2(self):
        topic = self.topic_edit.text().strip()
        if not topic:
            QMessageBox.warning(self, "경고", "토픽 이름을 입력하세요.")
            return
        self.ros2_sub = Ros2ImageSubscriber(topic)
        self.ros2_sub.frame_received.connect(self._on_ros2_frame)
        self.ros2_sub.start()
        self.display_timer.start(33)
        self._set_open_ui(f"ROS2 구독 중: {topic}")

    def close_source(self):
        if self.burst_running:
            self._stop_burst()
        self.display_timer.stop()
        if self.cap:
            self.cap.release()
            self.cap = None
        if self.ros2_sub:
            self.ros2_sub.stop()
            self.ros2_sub = None
        with self._frame_lock:
            self.current_frame = None
        self.video_label._set_idle()
        self._set_closed_ui()

    def _set_open_ui(self, msg):
        self.open_btn.setEnabled(False)
        self.close_btn.setEnabled(True)
        self.burst_btn.setEnabled(True)
        self.single_btn.setEnabled(True)
        self.status_bar.showMessage(msg)

    def _set_closed_ui(self):
        self.open_btn.setEnabled(True)
        self.close_btn.setEnabled(False)
        self.burst_btn.setEnabled(False)
        self.single_btn.setEnabled(False)
        self.status_bar.showMessage("영상 닫힘")

    # ── 프레임 수신/표시 ──────────────────────────────────────────────────
    def _on_ros2_frame(self, frame):
        with self._frame_lock:
            self.current_frame = frame.copy()

    def _display_frame(self):
        if self.cap and self.cap.isOpened():
            ret, frame = self.cap.read()
            if not ret:
                if self.src_combo.currentIndex() == 1:
                    self.cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                return
            with self._frame_lock:
                self.current_frame = frame.copy()

        with self._frame_lock:
            frame = self.current_frame
        if frame is not None:
            self.video_label.show_frame(frame)

    def _get_current_frame(self):
        with self._frame_lock:
            f = self.current_frame
            return f.copy() if f is not None else None

    # ── 저장 기능 ─────────────────────────────────────────────────────────
    def save_single(self):
        frame = self._get_current_frame()
        if frame is None:
            QMessageBox.warning(self, "경고", "저장할 프레임이 없습니다.")
            return
        save_dir = self._get_save_dir()
        if not save_dir:
            return
        os.makedirs(save_dir, exist_ok=True)
        path = os.path.join(save_dir, f"{time.strftime('%Y%m%d_%H%M%S')}.jpg")
        cv2.imwrite(path, frame)
        self.status_bar.showMessage(f"저장됨: {path}")

    def toggle_burst(self):
        if self.burst_running:
            self._stop_burst()
        else:
            self._start_burst()

    def _start_burst(self):
        save_dir = self._get_save_dir()
        if not save_dir:
            return
        if self._get_current_frame() is None:
            QMessageBox.warning(self, "경고", "영상 소스에서 프레임을 받지 못했습니다.")
            return
        self.worker = CaptureWorker(
            self._get_current_frame, save_dir,
            self.interval_spin.value(), self.count_spin.value()
        )
        self.worker.progress.connect(self._on_burst_progress)
        self.worker.finished.connect(self._on_burst_finished)
        self.worker.error.connect(self._on_burst_error)
        self.worker.start()
        self.burst_running = True
        self.burst_btn.setText("연속 저장 중지")
        self.burst_btn.setStyleSheet(self._btn_style("#8a2a2a", "#aa3a3a"))
        self.single_btn.setEnabled(False)
        self.progress_label.setText(f"0 / {self.count_spin.value()} 장")
        self.status_bar.showMessage(f"연속 저장 시작 → {save_dir}")

    def _stop_burst(self):
        if self.worker:
            self.worker.stop()
            self.worker.wait()
        self._reset_burst_ui()

    def _on_burst_progress(self, count, path):
        self.progress_label.setText(f"{count} / {self.count_spin.value()} 장")
        self.status_bar.showMessage(f"저장: {os.path.basename(path)}")

    def _on_burst_finished(self):
        self._reset_burst_ui()
        total = self.count_spin.value()
        self.status_bar.showMessage(f"연속 저장 완료: {total}장")
        QMessageBox.information(self, "완료", f"연속 저장 완료!\n{total}장 저장됨")

    def _on_burst_error(self, msg):
        self._reset_burst_ui()
        QMessageBox.critical(self, "오류", msg)

    def _reset_burst_ui(self):
        self.burst_running = False
        self.burst_btn.setText("연속 저장 시작")
        self.burst_btn.setStyleSheet(self._btn_style("#2a7a2a", "#3a9a3a"))
        self.single_btn.setEnabled(True if (self.cap or self.ros2_sub) else False)

    def closeEvent(self, event):
        self.close_source()
        if ROS2_AVAILABLE and rclpy.ok():
            rclpy.shutdown()
        event.accept()


def main():
    if ROS2_AVAILABLE:
        rclpy.init()
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    win = MainWindow()
    win.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
