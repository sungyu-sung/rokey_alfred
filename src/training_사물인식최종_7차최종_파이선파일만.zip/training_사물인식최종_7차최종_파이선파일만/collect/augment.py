#!/usr/bin/env python3
import argparse
import cv2
import numpy as np
from pathlib import Path
from typing import List, Tuple


def load_label(label_path: Path) -> List[List[float]]:
    if not label_path.exists():
        return []
    boxes = []
    with open(label_path) as f:
        for line in f:
            line = line.strip()
            if line:
                boxes.append(list(map(float, line.split())))
    return boxes


def save_label(label_path: Path, boxes: List[List[float]]):
    with open(label_path, 'w') as f:
        for box in boxes:
            f.write(' '.join(f'{v:.6f}' for v in box) + '\n')


def flip_horizontal(
    image: np.ndarray,
    boxes: List[List[float]]
) -> Tuple[np.ndarray, List[List[float]]]:
    flipped = cv2.flip(image, 1)
    new_boxes = [[cls, 1.0 - cx, cy, w, h] for cls, cx, cy, w, h in boxes]
    return flipped, new_boxes


def rotate_image(
    image: np.ndarray,
    boxes: List[List[float]],
    angle: float
) -> Tuple[np.ndarray, List[List[float]]]:
    h, w = image.shape[:2]
    M = cv2.getRotationMatrix2D((w / 2, h / 2), angle, 1.0)
    rotated = cv2.warpAffine(image, M, (w, h))
    new_boxes = []
    for cls, cx, cy, bw, bh in boxes:
        pt = np.array([[[cx * w, cy * h]]], dtype=np.float32)
        pr = cv2.transform(pt, M)[0][0]
        new_cx = float(np.clip(pr[0] / w, 0.0, 1.0))
        new_cy = float(np.clip(pr[1] / h, 0.0, 1.0))
        new_boxes.append([cls, new_cx, new_cy, bw, bh])
    return rotated, new_boxes


def adjust_brightness(image: np.ndarray, delta: float) -> np.ndarray:
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV).astype(np.float32)
    hsv[:, :, 2] = np.clip(hsv[:, :, 2] + delta, 0, 255)
    return cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2BGR)


def get_label_path(img_path: Path, images_root: Path, labels_root: Path) -> Path:
    rel = img_path.relative_to(images_root)
    return (labels_root / rel).with_suffix('.txt')


def augment_one(
    img_path: Path,
    images_root: Path,
    labels_root: Path,
    factor: int,
):
    image = cv2.imread(str(img_path))
    if image is None:
        print(f"  SKIP (읽기 실패): {img_path.name}")
        return

    label_path = get_label_path(img_path, images_root, labels_root)
    boxes = load_label(label_path)

    augmentations = [
        ('flip',    lambda img, b: flip_horizontal(img, b)),
        ('rot+15',  lambda img, b: rotate_image(img, b, 15.0)),
        ('rot-15',  lambda img, b: rotate_image(img, b, -15.0)),
        ('bright+', lambda img, b: (adjust_brightness(img, 50), b)),
        ('bright-', lambda img, b: (adjust_brightness(img, -50), b)),
    ]

    saved = 0
    for suffix, fn in augmentations[:factor]:
        aug_img, aug_boxes = fn(image, boxes)
        aug_name = f"{img_path.stem}_{suffix}{img_path.suffix}"
        out_img = img_path.parent / aug_name
        out_lbl = label_path.parent / f"{img_path.stem}_{suffix}.txt"
        if not cv2.imwrite(str(out_img), aug_img):
            print(f"  WARN: 이미지 저장 실패 - {out_img.name}")
            continue
        if aug_boxes:
            out_lbl.parent.mkdir(parents=True, exist_ok=True)
            save_label(out_lbl, aug_boxes)
        saved += 1

    print(f"  {img_path.name}: {saved}개 증강")


def main():
    parser = argparse.ArgumentParser(description='이미지 데이터 증강')
    parser.add_argument('--images', type=str, required=True,
                        help='이미지 폴더 (예: ../data/images/train)')
    parser.add_argument('--labels', type=str, required=True,
                        help='라벨 폴더 (예: ../data/labels/train)')
    parser.add_argument('--factor', type=int, default=3, choices=range(1, 6),
                        help='증강 종류 수 (1~5, 기본: 3)')
    args = parser.parse_args()

    images_root = Path(args.images)
    labels_root = Path(args.labels)

    AUG_SUFFIXES = {'_flip', '_rot+15', '_rot-15', '_bright+', '_bright-'}
    all_files = sorted(images_root.glob('*.jpg')) + sorted(images_root.glob('*.png'))
    img_files = [p for p in all_files if not any(p.stem.endswith(s) for s in AUG_SUFFIXES)]
    original_count = len(img_files)
    print(f"원본 이미지: {original_count}장 | factor: {args.factor}")

    for img_path in img_files:
        augment_one(img_path, images_root, labels_root, args.factor)

    final_count = len(list(images_root.glob('*.jpg'))) + len(list(images_root.glob('*.png')))
    print(f"완료: {original_count} → {final_count}장")


if __name__ == '__main__':
    main()
