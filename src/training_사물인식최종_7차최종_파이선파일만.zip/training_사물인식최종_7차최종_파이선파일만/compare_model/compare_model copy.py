import sys
import pandas as pd
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                             QPushButton, QFileDialog, QListWidget, QTableWidget, 
                             QTableWidgetItem, QHeaderView)

class ModelComparisonUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("YOLO 모델 성능 비교 도구 (mAP50 & mAP50-95)")
        self.setGeometry(100, 100, 900, 600)
        
        self.model_folders = []
        
        # UI 구성
        main_widget = QWidget()
        layout = QVBoxLayout(main_widget)
        
        self.btn_add = QPushButton("모델 폴더 추가 (2~8개)")
        self.btn_add.clicked.connect(self.add_folders)
        layout.addWidget(self.btn_add)
        
        self.list_widget = QListWidget()
        layout.addWidget(self.list_widget)
        
        self.btn_compare = QPushButton("성능 비교 분석 (mAP50, mAP50-95)")
        self.btn_compare.clicked.connect(self.compare_models)
        layout.addWidget(self.btn_compare)
        
        # 테이블 설정
        self.table = QTableWidget()
        self.table.setColumnCount(3)
        self.table.setHorizontalHeaderLabels(["Model Name", "mAP50", "mAP50-95"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.table)
        
        self.setCentralWidget(main_widget)

    def add_folders(self):
        folder = QFileDialog.getExistingDirectory(self, "학습 결과 폴더 선택")
        if folder and len(self.model_folders) < 8:
            # 중복 방지
            if folder not in self.model_folders:
                self.model_folders.append(folder)
                self.list_widget.addItem(folder)

    def compare_models(self):
        if len(self.model_folders) < 2:
            return

        results = []
        for folder in self.model_folders:
            try:
                # 결과 파일 경로
                csv_path = f"{folder}/results.csv"
                df = pd.read_csv(csv_path)
                
                # YOLOv8/v11 공통 컬럼명 기반 데이터 추출
                # 공백 제거 (일부 환경에서 CSV 컬럼명에 공백이 있을 수 있음)
                df.columns = df.columns.str.strip()
                
                last_row = df.iloc[-1]
                map50 = last_row.get('metrics/mAP50(B)', 0.0)
                map50_95 = last_row.get('metrics/mAP50-95(B)', 0.0)
                
                results.append({
                    "Model": folder.split('/')[-1], 
                    "mAP50": f"{map50:.4f}", 
                    "mAP50-95": f"{map50_95:.4f}"
                })
            except Exception as e:
                print(f"Error loading {folder}: {e}")

        # 테이블 표시
        self.table.setRowCount(len(results))
        for i, res in enumerate(results):
            self.table.setItem(i, 0, QTableWidgetItem(res["Model"]))
            self.table.setItem(i, 1, QTableWidgetItem(res["mAP50"]))
            self.table.setItem(i, 2, QTableWidgetItem(res["mAP50-95"]))

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ModelComparisonUI()
    window.show()
    sys.exit(app.exec())