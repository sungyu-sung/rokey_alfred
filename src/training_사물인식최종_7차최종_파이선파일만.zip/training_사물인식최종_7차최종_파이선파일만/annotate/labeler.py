"""labeler.py — YOLO AABB 라벨링 툴

조작:
  [라벨 박스 그리기] ON → 좌클릭 드래그로 박스 생성
  [라벨 박스 그리기] OFF:
      우클릭       → 박스 선택
      선택 후 드래그 → 박스 이동
      선택 후 모서리 드래그 → 박스 크기조정
  [자동 라벨링]    → temp_model.pt 로 박스 자동 생성
  Del / [선택 박스 지우기] → 선택 박스 삭제
  C → 전체 삭제  /  S → 저장  /  ←→ → 이미지 탐색

저장 형식 (YOLO Detection):  class_idx cx/W cy/H w/W h/H
"""
import sys
import os

os.environ['QT_QPA_PLATFORM_PLUGIN_PATH'] = '/usr/lib/x86_64-linux-gnu/qt5/plugins'
os.environ['QT_QPA_PLATFORM'] = 'wayland'

import cv2
import numpy as np
from pathlib import Path

from PyQt5 import QtWidgets, QtCore, QtGui

SRC_ROOT   = Path("/home/han3/turtlebot4_ws/src/training/label_image_saved")
DATA_DIR   = Path("/home/han3/turtlebot4_ws/src/training/data")
IMG_DIR    = DATA_DIR / "images"
LBL_DIR    = DATA_DIR / "labels"
MODEL_PATH = Path("/home/han3/turtlebot4_ws/src/training/weights/temp_model.pt")
IMG_EXTS   = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}
DISP_W, DISP_H = 640, 480
HANDLE_R   = 7   # 모서리 핸들 반경 (픽셀)


# ── 헬퍼 ─────────────────────────────────────────────────────────────────────
def point_in_rect(x, y, b) -> bool:
    return b['x1'] <= x <= b['x2'] and b['y1'] <= y <= b['y2']


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


def next_seq(save_dir: Path) -> int:
    existing = [int(f.stem) for f in save_dir.glob("*.jpg") if f.stem.isdigit()]
    return max(existing) + 1 if existing else 1


def corners(b) -> list:
    """박스의 4개 모서리 [(x,y), ...] TL TR BR BL."""
    return [
        (b['x1'], b['y1']), (b['x2'], b['y1']),
        (b['x2'], b['y2']), (b['x1'], b['y2']),
    ]


def hit_handle(mx, my, b) -> int:
    """마우스가 어떤 핸들에 있는지 반환. -1=없음, 0=TL,1=TR,2=BR,3=BL."""
    for i, (hx, hy) in enumerate(corners(b)):
        if abs(mx - hx) <= HANDLE_R and abs(my - hy) <= HANDLE_R:
            return i
    return -1


# ── 메인 UI ───────────────────────────────────────────────────────────────────
class LabelerUI(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        QtCore.QCoreApplication.setAttribute(QtCore.Qt.AA_DisableHighDpiScaling)
        IMG_DIR.mkdir(parents=True, exist_ok=True)
        LBL_DIR.mkdir(parents=True, exist_ok=True)

        self.img_paths:  list[Path]      = []
        self.img_idx:    int             = 0
        self.orig_frame: np.ndarray|None = None
        self.disp_frame: np.ndarray|None = None

        self.boxes: list[dict] = []   # {cls, x1, y1, x2, y2}
        self.sel:   int        = -1

        # 드로우
        self.draw_mode = False
        self._p0: tuple|None = None
        self._p1: tuple|None = None

        # 편집 (이동/리사이즈)
        self._edit_op:     str|None = None   # 'move' | 'resize'
        self._handle_idx:  int      = -1     # 0~3
        self._mouse_prev:  tuple    = (0, 0)

        self.yolo_model = None
        self.file_seq   = next_seq(IMG_DIR)
        self._init_ui()
        self._refresh_folders()

    # ── UI 구성 ───────────────────────────────────────────────────────────────
    def _init_ui(self):
        self.setWindowTitle("YOLO AABB Labeling Tool")
        self.setMinimumSize(980, 560)
        main = QtWidgets.QHBoxLayout(self)

        self.image_label = QtWidgets.QLabel()
        self.image_label.setFixedSize(DISP_W, DISP_H)
        self.image_label.setStyleSheet("border:2px solid #333;background:black;")
        self.image_label.setMouseTracking(True)
        main.addWidget(self.image_label)

        pnl = QtWidgets.QVBoxLayout()
        pnl.setSpacing(6)

        # 1. 폴더 선택
        pnl.addWidget(QtWidgets.QLabel("<b>1. 라벨 폴더 선택</b>"))
        fr = QtWidgets.QHBoxLayout()
        self.folder_combo = QtWidgets.QComboBox()
        self.folder_combo.currentIndexChanged.connect(self._on_folder_change)
        fr.addWidget(self.folder_combo)
        rb = QtWidgets.QPushButton("↺")
        rb.setFixedWidth(28)
        rb.clicked.connect(self._refresh_folders)
        fr.addWidget(rb)
        pnl.addLayout(fr)

        # 2. 이미지 탐색
        pnl.addWidget(QtWidgets.QLabel("<b>2. 이미지 탐색</b>"))
        nr = QtWidgets.QHBoxLayout()
        self.prev_btn = QtWidgets.QPushButton("◀ 이전")
        self.prev_btn.clicked.connect(self._prev_image)
        self.next_btn = QtWidgets.QPushButton("다음 ▶")
        self.next_btn.clicked.connect(self._next_image)
        nr.addWidget(self.prev_btn)
        nr.addWidget(self.next_btn)
        pnl.addLayout(nr)
        self.nav_label = QtWidgets.QLabel("- / -")
        self.nav_label.setAlignment(QtCore.Qt.AlignCenter)
        self.nav_label.setStyleSheet("color:#aaa;font-size:11px;")
        pnl.addWidget(self.nav_label)
        self.img_name_label = QtWidgets.QLabel("")
        self.img_name_label.setAlignment(QtCore.Qt.AlignCenter)
        self.img_name_label.setStyleSheet("color:#88ccff;font-size:10px;")
        self.img_name_label.setWordWrap(True)
        pnl.addWidget(self.img_name_label)

        # 3. 박스 편집
        pnl.addWidget(QtWidgets.QLabel("<b>3. 박스 편집</b>"))

        self.draw_btn = QtWidgets.QPushButton("라벨 박스 그리기")
        self.draw_btn.setFixedHeight(36)
        self.draw_btn.setCheckable(True)
        self.draw_btn.clicked.connect(self._toggle_draw_mode)
        self.draw_btn.setStyleSheet(self._draw_btn_css(False))
        pnl.addWidget(self.draw_btn)

        self.del_btn = QtWidgets.QPushButton("선택한 박스 지우기  (Del)")
        self.del_btn.setFixedHeight(32)
        self.del_btn.clicked.connect(self._delete_selected)
        self.del_btn.setStyleSheet(
            "QPushButton{background:#5a1a1a;color:#ffaaaa;font-weight:bold;"
            "border:2px solid #aa3333;border-radius:4px;}"
            "QPushButton:hover{background:#7a2a2a;color:#fff;}")
        pnl.addWidget(self.del_btn)

        clr_btn = QtWidgets.QPushButton("전체 박스 삭제  (C)")
        clr_btn.setFixedHeight(28)
        clr_btn.clicked.connect(self._clear_all)
        clr_btn.setStyleSheet(
            "QPushButton{background:#3a1a1a;color:#cc8888;"
            "border:1px solid #883333;border-radius:3px;}"
            "QPushButton:hover{background:#5a2a2a;}")
        pnl.addWidget(clr_btn)

        # 4. 자동 라벨링
        pnl.addWidget(QtWidgets.QLabel("<b>4. 자동 라벨링</b>"))

        conf_row = QtWidgets.QHBoxLayout()
        conf_row.addWidget(QtWidgets.QLabel("신뢰도:"))
        self.conf_slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.conf_slider.setRange(10, 90)
        self.conf_slider.setValue(40)
        self.conf_slider.setTickInterval(10)
        self.conf_slider.valueChanged.connect(
            lambda v: self.conf_val_lbl.setText(f"{v/100:.1f}"))
        conf_row.addWidget(self.conf_slider)
        self.conf_val_lbl = QtWidgets.QLabel("0.40")
        self.conf_val_lbl.setFixedWidth(32)
        conf_row.addWidget(self.conf_val_lbl)
        pnl.addLayout(conf_row)

        self.auto_btn = QtWidgets.QPushButton("자동 라벨링 실행")
        self.auto_btn.setFixedHeight(36)
        self.auto_btn.clicked.connect(self._auto_label)
        self.auto_btn.setStyleSheet(
            "QPushButton{background:#4a2a7a;color:#ccaaff;font-weight:bold;"
            "border:2px solid #8855cc;border-radius:4px;}"
            "QPushButton:hover{background:#6a3a9a;color:#fff;}"
            "QPushButton:disabled{background:#333;color:#777;}")
        pnl.addWidget(self.auto_btn)

        self.model_status_lbl = QtWidgets.QLabel("")
        self.model_status_lbl.setStyleSheet("color:#888;font-size:10px;")
        self.model_status_lbl.setWordWrap(True)
        self._update_model_status()
        pnl.addWidget(self.model_status_lbl)

        # 5. 박스 정보
        pnl.addWidget(QtWidgets.QLabel("<b>5. 선택 박스 정보</b>"))
        self.info_label = QtWidgets.QLabel("대기 중")
        self.info_label.setStyleSheet(
            "color:#00ff88;background:#111;padding:4px;"
            "font-family:monospace;min-height:44px;")
        self.info_label.setWordWrap(True)
        pnl.addWidget(self.info_label)

        pnl.addStretch()

        self.status_label = QtWidgets.QLabel(f"저장 번호: {self.file_seq:04d}")
        self.status_label.setStyleSheet("color:#aaa;font-size:11px;")
        pnl.addWidget(self.status_label)

        self.save_btn = QtWidgets.QPushButton(f"저장  (S)\n→ {self.file_seq:04d}.jpg")
        self.save_btn.setFixedHeight(60)
        self.save_btn.setStyleSheet(
            "QPushButton{background:#2E7D32;color:white;"
            "font-size:14px;font-weight:bold;border-radius:5px;}"
            "QPushButton:hover{background:#388E3C;}")
        self.save_btn.clicked.connect(self.save_data)
        pnl.addWidget(self.save_btn)

        pw = QtWidgets.QWidget()
        pw.setLayout(pnl)
        pw.setFixedWidth(300)
        main.addWidget(pw)

    def _draw_btn_css(self, active: bool) -> str:
        if active:
            return ("QPushButton{background:#1a5a8a;color:#88ddff;font-weight:bold;"
                    "border:2px solid #44aaff;border-radius:4px;}"
                    "QPushButton:hover{background:#2a6a9a;}")
        return ("QPushButton{background:#1e3a1e;color:#88ff88;font-weight:bold;"
                "border:2px solid #336633;border-radius:4px;}"
                "QPushButton:hover{background:#2a4a2a;}")

    def _update_model_status(self):
        if MODEL_PATH.exists():
            self.model_status_lbl.setText(f"✅ 모델 있음\n{MODEL_PATH.name}")
            self.auto_btn.setEnabled(True)
        else:
            self.model_status_lbl.setText("❌ 모델 없음\ntrain_temp_model.py 먼저 실행")
            self.auto_btn.setEnabled(False)

    # ── 폴더 ─────────────────────────────────────────────────────────────────
    def _refresh_folders(self):
        self.folder_combo.blockSignals(True)
        prev = self.folder_combo.currentText()
        self.folder_combo.clear()
        folders = sorted([d.name for d in SRC_ROOT.iterdir() if d.is_dir()])
        self.folder_combo.addItems(folders)
        if prev in folders:
            self.folder_combo.setCurrentText(prev)
        self.folder_combo.blockSignals(False)
        self._on_folder_change()

    def _on_folder_change(self):
        folder = self.folder_combo.currentText()
        if not folder:
            self.img_paths = []
            self._update_nav()
            return
        self.img_paths = sorted(
            [p for p in (SRC_ROOT / folder).iterdir()
             if p.suffix.lower() in IMG_EXTS])
        self.img_idx = 0
        self.boxes = []; self.sel = -1
        self._load_current_image()

    def _current_class(self) -> str:
        return self.folder_combo.currentText() or "object"

    # ── 이미지 탐색 ───────────────────────────────────────────────────────────
    def _load_current_image(self):
        self.boxes = []; self.sel = -1
        if not self.img_paths:
            self.orig_frame = self.disp_frame = None
            self._update_nav(); self.draw_and_show(); return
        img = cv2.imread(str(self.img_paths[self.img_idx]))
        if img is None:
            self.orig_frame = self.disp_frame = None
        else:
            self.orig_frame = img
            self.disp_frame = cv2.resize(img, (DISP_W, DISP_H))
        self._update_nav(); self._update_info(); self.draw_and_show()

    def _update_nav(self):
        total = len(self.img_paths)
        if total == 0:
            self.nav_label.setText("- / -")
            self.img_name_label.setText("")
        else:
            self.nav_label.setText(f"{self.img_idx+1} / {total}")
            self.img_name_label.setText(self.img_paths[self.img_idx].name)
        self.prev_btn.setEnabled(self.img_idx > 0)
        self.next_btn.setEnabled(self.img_idx < total - 1)

    def _prev_image(self):
        if self.img_idx > 0:
            self.img_idx -= 1; self._load_current_image()

    def _next_image(self):
        if self.img_idx < len(self.img_paths) - 1:
            self.img_idx += 1; self._load_current_image()

    # ── 드로우 모드 ───────────────────────────────────────────────────────────
    def _toggle_draw_mode(self, checked: bool):
        self.draw_mode = checked
        self.draw_btn.setStyleSheet(self._draw_btn_css(checked))
        self.draw_btn.setText(
            "✏ 그리는 중 (다시 클릭해제)" if checked else "라벨 박스 그리기")
        if checked:
            self.sel = -1
        self._update_info()

    # ── 박스 편집 ─────────────────────────────────────────────────────────────
    def _delete_selected(self):
        if 0 <= self.sel < len(self.boxes):
            self.boxes.pop(self.sel)
            self.sel = -1
            self._update_info(); self.draw_and_show()

    def _clear_all(self):
        self.boxes = []; self.sel = -1
        self._update_info(); self.draw_and_show()

    def _update_info(self):
        if self.draw_mode:
            self.info_label.setText("✏ 그리기 모드\n드래그로 박스 생성")
        elif 0 <= self.sel < len(self.boxes):
            b = self.boxes[self.sel]
            w = int(b['x2'] - b['x1']); h = int(b['y2'] - b['y1'])
            hint = "드래그: 이동  |  모서리 드래그: 크기조정"
            self.info_label.setText(
                f"[{self.sel}] {b['cls']}  {w}×{h}px\n{hint}")
        elif self.boxes:
            self.info_label.setText(f"박스 {len(self.boxes)}개\n우클릭으로 선택")
        else:
            self.info_label.setText("박스 없음\n[라벨 박스 그리기] 후 드래그")

    # ── 자동 라벨링 ───────────────────────────────────────────────────────────
    def _auto_label(self):
        if self.orig_frame is None:
            QtWidgets.QMessageBox.warning(self, "경고", "이미지가 없습니다.")
            return
        if not MODEL_PATH.exists():
            QtWidgets.QMessageBox.warning(self, "경고",
                "모델 파일이 없습니다.\ntrain_temp_model.py 를 먼저 실행하세요.")
            return

        self.auto_btn.setEnabled(False)
        self.auto_btn.setText("추론 중...")
        QtWidgets.QApplication.processEvents()

        try:
            if self.yolo_model is None:
                from ultralytics import YOLO
                self.yolo_model = YOLO(str(MODEL_PATH))

            conf = self.conf_slider.value() / 100.0
            results = self.yolo_model(self.orig_frame, conf=conf, verbose=False)

            oh, ow = self.orig_frame.shape[:2]
            sx, sy = DISP_W / ow, DISP_H / oh   # 원본→표시 스케일

            added = 0
            cls_name = self._current_class()
            for r in results:
                for box in r.boxes:
                    x1, y1, x2, y2 = box.xyxy[0].tolist()
                    self.boxes.append({
                        'cls': cls_name,
                        'x1': clamp(x1 * sx, 0, DISP_W),
                        'y1': clamp(y1 * sy, 0, DISP_H),
                        'x2': clamp(x2 * sx, 0, DISP_W),
                        'y2': clamp(y2 * sy, 0, DISP_H),
                    })
                    added += 1

            self.info_label.setText(f"자동 라벨링: {added}개 박스 생성\n수정 후 저장하세요")
            self.draw_and_show()
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "오류", str(e))
        finally:
            self.auto_btn.setEnabled(True)
            self.auto_btn.setText("자동 라벨링 실행")

    # ── 이미지 좌표 ───────────────────────────────────────────────────────────
    def _img_xy(self):
        gp = QtGui.QCursor.pos()
        lo = self.image_label.mapToGlobal(QtCore.QPoint(0, 0))
        x  = clamp(gp.x() - lo.x(), 0, DISP_W - 1)
        y  = clamp(gp.y() - lo.y(), 0, DISP_H - 1)
        return x, y

    def _in_image(self) -> bool:
        gp = QtGui.QCursor.pos()
        lo = self.image_label.mapToGlobal(QtCore.QPoint(0, 0))
        return 0 <= gp.x() - lo.x() < DISP_W and 0 <= gp.y() - lo.y() < DISP_H

    # ── 마우스 이벤트 ─────────────────────────────────────────────────────────
    def mousePressEvent(self, event):
        if not self._in_image() or self.disp_frame is None:
            return
        x, y = self._img_xy()

        if event.button() == QtCore.Qt.LeftButton:
            if self.draw_mode:
                self._p0 = (x, y); self._p1 = (x, y)
            elif 0 <= self.sel < len(self.boxes):
                b = self.boxes[self.sel]
                h = hit_handle(x, y, b)
                if h >= 0:
                    self._edit_op    = 'resize'
                    self._handle_idx = h
                    self._mouse_prev = (x, y)
                elif point_in_rect(x, y, b):
                    self._edit_op    = 'move'
                    self._mouse_prev = (x, y)

        elif event.button() == QtCore.Qt.RightButton:
            self.sel = -1
            for i in range(len(self.boxes) - 1, -1, -1):
                if point_in_rect(x, y, self.boxes[i]):
                    self.sel = i; break
            self._update_info(); self.draw_and_show()

    def mouseMoveEvent(self, event):
        if not self._in_image() or self.disp_frame is None:
            return
        x, y = self._img_xy()

        if self.draw_mode and self._p0:
            self._p1 = (x, y); self.draw_and_show(); return

        if self._edit_op and 0 <= self.sel < len(self.boxes):
            b  = self.boxes[self.sel]
            dx = x - self._mouse_prev[0]
            dy = y - self._mouse_prev[1]
            self._mouse_prev = (x, y)

            if self._edit_op == 'move':
                b['x1'] = clamp(b['x1'] + dx, 0, DISP_W)
                b['y1'] = clamp(b['y1'] + dy, 0, DISP_H)
                b['x2'] = clamp(b['x2'] + dx, 0, DISP_W)
                b['y2'] = clamp(b['y2'] + dy, 0, DISP_H)

            elif self._edit_op == 'resize':
                # 0=TL 1=TR 2=BR 3=BL
                h = self._handle_idx
                if h == 0:   # TL
                    b['x1'] = clamp(x, 0, b['x2'] - 6)
                    b['y1'] = clamp(y, 0, b['y2'] - 6)
                elif h == 1: # TR
                    b['x2'] = clamp(x, b['x1'] + 6, DISP_W)
                    b['y1'] = clamp(y, 0, b['y2'] - 6)
                elif h == 2: # BR
                    b['x2'] = clamp(x, b['x1'] + 6, DISP_W)
                    b['y2'] = clamp(y, b['y1'] + 6, DISP_H)
                elif h == 3: # BL
                    b['x1'] = clamp(x, 0, b['x2'] - 6)
                    b['y2'] = clamp(y, b['y1'] + 6, DISP_H)

            self._update_info(); self.draw_and_show()

    def mouseReleaseEvent(self, event):
        if event.button() == QtCore.Qt.LeftButton:
            if self.draw_mode and self._p0:
                x, y   = self._img_xy()
                x0, y0 = self._p0
                x1, x2 = min(x0, x), max(x0, x)
                y1, y2 = min(y0, y), max(y0, y)
                if (x2 - x1) > 6 and (y2 - y1) > 6:
                    self.boxes.append({
                        'cls': self._current_class(),
                        'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2,
                    })
                    self.sel = len(self.boxes) - 1
                self._p0 = self._p1 = None
                self._update_info(); self.draw_and_show()
            self._edit_op = None

    # ── 그리기 ────────────────────────────────────────────────────────────────
    def draw_and_show(self):
        if self.disp_frame is None:
            self.image_label.clear()
            self.image_label.setText("이미지 없음")
            self.image_label.setAlignment(QtCore.Qt.AlignCenter)
            self.image_label.setStyleSheet(
                "border:2px solid #333;background:black;color:#666;font-size:14px;")
            return

        img = self.disp_frame.copy()

        for i, b in enumerate(self.boxes):
            sel = (i == self.sel)
            col = (0, 140, 255) if sel else (0, 220, 60)
            cv2.rectangle(img, (int(b['x1']), int(b['y1'])),
                               (int(b['x2']), int(b['y2'])), col, 2)

            # 라벨 배경
            txt = f"[{i}] {b['cls']}"
            (tw, th), _ = cv2.getTextSize(txt, cv2.FONT_HERSHEY_SIMPLEX, 0.48, 1)
            ty = max(int(b['y1']) - 4, th + 2)
            cv2.rectangle(img, (int(b['x1']), ty - th - 2),
                               (int(b['x1']) + tw + 4, ty + 2), col, -1)
            cv2.putText(img, txt, (int(b['x1']) + 2, ty),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.48, (0, 0, 0), 1)

            # 선택 박스 → 4개 핸들
            if sel:
                for hx, hy in corners(b):
                    cv2.rectangle(img,
                                  (int(hx) - HANDLE_R, int(hy) - HANDLE_R),
                                  (int(hx) + HANDLE_R, int(hy) + HANDLE_R),
                                  (255, 255, 0), -1)
                    cv2.rectangle(img,
                                  (int(hx) - HANDLE_R, int(hy) - HANDLE_R),
                                  (int(hx) + HANDLE_R, int(hy) + HANDLE_R),
                                  (0, 0, 0), 1)

        # 드래그 미리보기
        if self.draw_mode and self._p0 and self._p1:
            x0, y0 = self._p0; x1, y1 = self._p1
            cv2.rectangle(img, (min(x0,x1), min(y0,y1)),
                               (max(x0,x1), max(y0,y1)), (0, 255, 255), 1)

        rgb  = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb.shape
        qimg = QtGui.QImage(rgb.data, w, h, ch * w, QtGui.QImage.Format_RGB888)
        self.image_label.setPixmap(QtGui.QPixmap.fromImage(qimg))
        self.image_label.setStyleSheet("border:2px solid #333;background:black;")

    # ── 키 이벤트 ─────────────────────────────────────────────────────────────
    def keyPressEvent(self, event):
        k = event.key()
        if   k == QtCore.Qt.Key_S:         self.save_data()
        elif k == QtCore.Qt.Key_C:         self._clear_all()
        elif k in (QtCore.Qt.Key_Delete,
                   QtCore.Qt.Key_Backspace): self._delete_selected()
        elif k == QtCore.Qt.Key_Left:      self._prev_image()
        elif k == QtCore.Qt.Key_Right:     self._next_image()

    # ── 저장 ─────────────────────────────────────────────────────────────────
    def _classes_path(self) -> Path:
        return DATA_DIR / "classes.txt"

    def _load_classes_txt(self) -> list[str]:
        p = self._classes_path()
        return ([l.strip() for l in p.read_text().splitlines() if l.strip()]
                if p.exists() else [])

    def save_data(self):
        if self.orig_frame is None:
            QtWidgets.QMessageBox.warning(self, "경고", "이미지가 없습니다."); return
        if not self.boxes:
            QtWidgets.QMessageBox.warning(self, "경고", "박스가 없습니다."); return

        classes = self._load_classes_txt()
        for b in self.boxes:
            if b['cls'] not in classes:
                classes.append(b['cls'])
        self._classes_path().write_text("\n".join(classes) + "\n")

        oh, ow = self.orig_frame.shape[:2]
        sx, sy = ow / DISP_W, oh / DISP_H   # 표시→원본

        fname = f"{self.file_seq:04d}"
        cv2.imwrite(str(IMG_DIR / f"{fname}.jpg"), self.orig_frame)

        with open(LBL_DIR / f"{fname}.txt", "w") as f:
            for b in self.boxes:
                idx = classes.index(b['cls'])
                x1o, y1o = b['x1']*sx, b['y1']*sy
                x2o, y2o = b['x2']*sx, b['y2']*sy
                cx = (x1o+x2o)/2/ow;  cy = (y1o+y2o)/2/oh
                w  = (x2o-x1o)/ow;    h  = (y2o-y1o)/oh
                f.write(f"{idx} {cx:.6f} {cy:.6f} {w:.6f} {h:.6f}\n")

        print(f"[저장] {fname}.jpg  ({len(self.boxes)}개 박스)")
        self.file_seq += 1
        self.status_label.setText(f"저장 번호: {self.file_seq:04d}")
        self.save_btn.setText(f"저장  (S)\n→ {self.file_seq:04d}.jpg")
        self.boxes = []; self.sel = -1
        self._update_info()
        if self.img_idx < len(self.img_paths) - 1:
            self._next_image()
        else:
            self.draw_and_show()


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    ex  = LabelerUI()
    ex.show()
    sys.exit(app.exec_())
