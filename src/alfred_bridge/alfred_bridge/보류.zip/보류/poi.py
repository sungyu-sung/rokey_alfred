#!/usr/bin/env python3
"""POI 테이블 조회 헬퍼 — poi_id → goal(좌표/층) 변환 (fms_server/poi.py에서 이식).

fms_server 폐기로 POI 테이블의 단일 출처가 이 패키지로 옮겨왔다 — 각 robot_manager가
자체적으로 same/cross-floor 판정과 handover/standby/final 좌표 조회에 쓴다
(이전: FMS의 mission_manager가 전담 → 지금: 호출한 로봇이 직접 전담).

값은 config/poi_table.yaml(ament_python data_files로 share에 설치)에서 로드한다.
IF-03 goal 형식과 동일하게 유지: {poi_id, floor, pose:{x,y,theta}}.
"""

from __future__ import annotations

from pathlib import Path

import yaml
from ament_index_python.packages import get_package_share_directory

_table: dict[str, dict] | None = None


def _table_path() -> Path:
    share = get_package_share_directory("alfred_bridge")
    return Path(share) / "config" / "poi_table.yaml"


def table() -> dict[str, dict]:
    global _table
    if _table is None:
        path = _table_path()
        if not path.exists():
            _table = {}
        else:
            with path.open("r", encoding="utf-8") as f:
                data = yaml.safe_load(f) or {}
            pois = data.get("pois", {})
            _table = pois if isinstance(pois, dict) else {}
    return _table


def reload() -> None:
    """테스트/맵 갱신용 — 캐시 무효화."""
    global _table
    _table = None


def get(poi_id: str) -> dict | None:
    return table().get(poi_id)


def by_type(poi_type: str) -> dict[str, dict]:
    return {pid: p for pid, p in table().items() if p.get("type") == poi_type}


def first_of_type(poi_type: str) -> str | None:
    items = by_type(poi_type)
    return next(iter(items), None)


def goal_for(poi_id: str | None) -> dict | None:
    """poi_id → IF-03 goal dict. 없으면 None."""
    if not poi_id:
        return None
    p = get(poi_id)
    if not p:
        return None
    return {"poi_id": poi_id, "floor": p.get("floor"), "pose": p.get("pose", {})}
