#!/usr/bin/env python3
"""all_robot_manager — 순수 모니터 노드 (fms_server 폐기 후 유일하게 남는 "전체를
보는" 곳이지만, fms_server처럼 중앙 처리는 절대 하지 않는다).

robot2/robot4의 RobotState/Event/MissionSignal을 구독해 상태 변화·이벤트·신호를
ROS2 로그(get_logger)로만 남긴다. **이 노드는 어떤 robotX/* 토픽에도 publish하지
않는다** — 두 로봇은 서로의 상태를 직접 구독해 스스로 판단하므로(분산 두뇌는
robot2_manager/robot4_manager 쪽), 여기서는 "관찰해서 로그로 남기는" 역할만으로
책임이 끝난다. 운영 중 상태 확인은 `ros2 topic echo`나 launch 콘솔 로그로 충분하므로
Flask/HTTP 같은 외부 노출 인터페이스는 일부러 두지 않는다.

실행:
  ros2 run alfred_bridge all_robot_manager
"""
from __future__ import annotations

import rclpy
from rclpy.executors import ExternalShutdownException
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data

from alfred_interfaces.msg import Event, MissionSignal, RobotState

# ── 감시 대상 namespace 목록 — robotX_manager의 partner 설정과 무관하게
# "구독해서 로그로 남길 대상"일 뿐이라 순서·개수에 제약이 없다(로봇 추가 시 여기만 늘리면 됨).
ROBOT_NAMESPACES = ['/robot2', '/robot4']


class AllRobotManager(Node):
    """로봇 상태/이벤트/미션 신호를 구독해 로그로만 남기는 순수 관찰자.

    publisher가 단 하나도 없다 — robot2_manager/robot4_manager(분산 두뇌)와
    달리 이 노드가 만들어내는 ROS2 출력은 전혀 없다. 명령·재발행은 절대 금지이며,
    이는 fms_server의 "중앙 처리"를 옮겨오지 않기로 한 결정의 직접적 결과다.
    """

    def __init__(self, namespaces: list[str] | None = None) -> None:
        super().__init__('all_robot_manager')
        self._namespaces = list(namespaces or ROBOT_NAMESPACES)

        # 상태 "변화" 시에만 로그를 남기기 위한 최소한의 직전 상태 기억
        # (rclpy.spin은 기본 SingleThreadedExecutor → 콜백이 순차 실행, 락 불필요)
        self._last_state: dict[str, str] = {}

        for ns in self._namespaces:
            # /state는 robotX_manager 쪽 발행 QoS(best-effort, 0.5s 주기)와 맞춘다
            self.create_subscription(
                RobotState, f'{ns}/state', self._make_state_cb(ns), qos_profile_sensor_data)
            self.create_subscription(
                Event, f'{ns}/event', self._make_event_cb(ns), 10)
            self.create_subscription(
                MissionSignal, f'{ns}/mission_signal', self._make_signal_cb(ns), 10)

        self.get_logger().info(
            f'all_robot_manager ready — 순수 모니터 (관찰: {self._namespaces}, '
            f'명령·발행 없음, 상태 변화/이벤트/신호는 로그로만 출력)')

    # ── 구독 콜백 — 로그만 남긴다. 캐시·재발행·판단 일절 없음 ──────────────
    def _make_state_cb(self, namespace: str):
        def _cb(msg: RobotState) -> None:
            prev = self._last_state.get(namespace)
            if msg.state == prev:
                return  # 0.5s 주기로 같은 상태가 계속 들어옴 — 변화 없으면 로그 생략
            self._last_state[namespace] = msg.state
            self.get_logger().info(
                f'[state] {namespace} {prev or "?"} → {msg.state} '
                f'(task={msg.current_task_id or "-"}/{msg.task_status or "-"}, '
                f'battery={msg.battery}%)')
        return _cb

    def _make_event_cb(self, namespace: str):
        def _cb(msg: Event) -> None:
            self.get_logger().warning(
                f'[event] {namespace} {msg.event_type} '
                f'(confidence={msg.confidence:.2f}, floor={msg.floor})')
        return _cb

    def _make_signal_cb(self, namespace: str):
        def _cb(msg: MissionSignal) -> None:
            self.get_logger().info(
                f'[signal] {namespace} {msg.signal} mission={msg.mission_id} '
                f'reason={msg.reason!r}')
        return _cb


def main(args=None):
    rclpy.init(args=args)
    node = AllRobotManager()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():   # ExternalShutdownException 시 rclpy가 이미 컨텍스트를 내렸을 수 있음
            rclpy.shutdown()


if __name__ == '__main__':
    main()
