#!/usr/bin/env python3
"""robot2 Manager — 상태 머신 + 분산 릴레이 두뇌(core.RobotStateManager) 실행 진입점.

fms_server 폐기로 mqtt_host/port/client_id는 사라지고, 대신 partner(=robot4)를
직접 알아야 한다 — 더 이상 중앙이 "내 상대가 누군지" 알려주지 않기 때문이다
(옛 fms_server/config.py의 partner_of(robot_id) 역할을 각자 자기 설정으로 가짐).

실행:
  ros2 run alfred_bridge robot2_manager
"""
import rclpy
from rclpy.executors import ExternalShutdownException

from alfred_bridge.core import RobotStateManager

# ── robot2 설정 (1층 담당, station 복귀, partner=robot4) ──────────────────
ROBOT2_CONFIG = {
    'namespace':         '/robot2',
    'partner_id':        'robot4',
    'partner_namespace': '/robot4',
    'base_poi':          'station',   # 복귀(순찰 홈) 지점 — poi_table.yaml 기준
    'initial_battery':   100,
    # 자율 PATROL 경로 — task 없을 때 이 좌표를 순서대로 순환 주행한다(절대 규칙 8:
    # 명령 주체가 사라져도 이 동작의 자율성은 유지된다 — 전적으로 로봇 쪽 설정).
    # 비워두면([])  patrol 주행 없이 가만히 대기만 한다.
    # 1층 맵 기준 좌표 (x, y[m], theta[rad]) — TurtleBot4Directions 기준 deg→rad 변환
    'patrol_waypoints': [
        {'x': -7.0, 'y': 2.7,  'theta': 1.57},   # WEST
        {'x': -7.0, 'y': 1.3,  'theta': 3.14},   # SOUTH
        {'x': -2.7, 'y': 2.12, 'theta': -1.57},  # EAST
        {'x': -2.7, 'y': 3.3,  'theta': 0.0},    # NORTH
    ],
}


def main(args=None):
    rclpy.init(args=args)
    node = RobotStateManager('robot2', ROBOT2_CONFIG)
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():   # ExternalShutdownException 시 rclpy가 이미 컨텍스트를 내렸을 수 있음
            rclpy.shutdown()


if __name__ == '__main__':
    main()
