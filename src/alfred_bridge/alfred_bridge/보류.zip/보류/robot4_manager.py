#!/usr/bin/env python3
"""robot4 Manager — 상태 머신 + 분산 릴레이 두뇌(core.RobotStateManager) 실행 진입점.

robot2_manager와 거울상 설정 — partner=robot2, base_poi/순찰 좌표만 2층 기준으로
바뀐다(분산 두뇌 로직 자체는 robot_id에 무관하게 core.py 한 곳에 있다).

실행:
  ros2 run alfred_bridge robot4_manager
"""
import rclpy
from rclpy.executors import ExternalShutdownException

from alfred_bridge.core import RobotStateManager

# ── robot4 설정 (2층 담당, station2 복귀, partner=robot2) ─────────────────
ROBOT4_CONFIG = {
    'namespace':         '/robot4',
    'partner_id':        'robot2',
    'partner_namespace': '/robot2',
    'base_poi':          'station2',  # 복귀(순찰 홈) 지점 — poi_table.yaml 기준
    'initial_battery':   100,
    # 자율 PATROL 경로 — task 없을 때 이 좌표를 순서대로 순환 주행한다(절대 규칙 8:
    # 명령 주체가 사라져도 이 동작의 자율성은 유지된다 — 전적으로 로봇 쪽 설정).
    # 비워두면([])  patrol 주행 없이 가만히 대기만 한다.
    # 2층 맵 기준 좌표 (x, y[m], theta[rad])
    'patrol_waypoints': [
        {'x': -2.5, 'y': 3.0,  'theta': 3.14},   # SOUTH
        {'x': -2.5, 'y': 2.5,  'theta': 0.0},    # NORTH
    ],
}


def main(args=None):
    rclpy.init(args=args)
    node = RobotStateManager('robot4', ROBOT4_CONFIG)
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():   # ExternalShutdownException 시 rclpy가 이미 컨텍스트를 내렸을 수 있음
            rclpy.shutdown()


if __name__ == '__main__':
    main()
