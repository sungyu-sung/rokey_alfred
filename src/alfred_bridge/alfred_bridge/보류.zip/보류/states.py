#!/usr/bin/env python3
"""상태·타입 enum 상수 (fms_server/states.py에서 이식 — fms_server 폐기로 더 이상
import할 곳이 없어 알파드 코드를 옮겨온다. 단일 출처가 fms_server에서 여기로 바뀐 것뿐,
값 자체는 인터페이스 정의서 §1·§4 그대로 — 분산 전환 후에도 Robot State 계약은 불변이다.

Mission State(옛 FMS 단독 소유)는 이식하지 않는다 — 중앙 소유자가 사라졌고, 새
구조에서는 각 로봇이 자기 segment의 Robot State + 가벼운 미션 플래그만으로 충분하다
(설계: docs 플랜 "분산 두뇌" 절 참고).
"""

from __future__ import annotations

# ── Robot State (로봇 소유, RobotState.msg로 보고) — 10종 ─────────────────
ROBOT_IDLE = "IDLE"
ROBOT_PATROL = "PATROL"
ROBOT_INTERACTING = "INTERACTING"
ROBOT_RESERVED = "RESERVED"
ROBOT_HANDOVER_READY = "HANDOVER_READY"
ROBOT_ESCORTING = "ESCORTING"
ROBOT_WAITING_HANDOVER = "WAITING_HANDOVER"
ROBOT_RETURNING = "RETURNING"
ROBOT_EMERGENCY = "EMERGENCY"
ROBOT_ERROR = "ERROR"

ROBOT_STATES = {
    ROBOT_IDLE, ROBOT_PATROL, ROBOT_INTERACTING, ROBOT_RESERVED,
    ROBOT_HANDOVER_READY, ROBOT_ESCORTING, ROBOT_WAITING_HANDOVER,
    ROBOT_RETURNING, ROBOT_EMERGENCY, ROBOT_ERROR,
}

# ── task_type (Task.msg, 4종 — PATROL 없음: 절대 규칙 8과 같은 결) ────────
TASK_MOVE_TO_STANDBY = "MOVE_TO_STANDBY"
TASK_ESCORT_TO_HANDOVER = "ESCORT_TO_HANDOVER"
TASK_ESCORT_TO_FINAL = "ESCORT_TO_FINAL"
TASK_RETURN_TO_BASE = "RETURN_TO_BASE"

TASK_TYPES = {
    TASK_MOVE_TO_STANDBY, TASK_ESCORT_TO_HANDOVER,
    TASK_ESCORT_TO_FINAL, TASK_RETURN_TO_BASE,
}

# ── task_status (RobotState.msg) ─────────────────────────────────────────
TS_ACCEPTED = "ACCEPTED"
TS_RUNNING = "RUNNING"
TS_SUCCEEDED = "SUCCEEDED"
TS_FAILED = "FAILED"
TASK_STATUS = {TS_ACCEPTED, TS_RUNNING, TS_SUCCEEDED, TS_FAILED}

# ── task_ack / relay_ack result ───────────────────────────────────────────
ACK_ACCEPT = "ACCEPT"
ACK_REJECT = "REJECT"

# ── Event.msg event_type ──────────────────────────────────────────────────
EVENT_FIRE = "FIRE"
EVENT_SUSPICIOUS_PERSON = "SUSPICIOUS_PERSON"
EVENT_TYPES = {EVENT_FIRE, EVENT_SUSPICIOUS_PERSON}

# ── mission_signal (신규 — partner 간 예외 전파 전용, FMS의 _terminate 대체) ──
SIGNAL_ABORT = "ABORT"            # CANCEL — Interaction이 취소 요청
SIGNAL_EMERGENCY = "EMERGENCY"    # 한쪽 EMERGENCY → 상대에게 즉시 전파
SIGNAL_TASK_FAILED = "TASK_FAILED"  # 한쪽 task 실패 → 상대에게 전파
SIGNAL_TYPES = {SIGNAL_ABORT, SIGNAL_EMERGENCY, SIGNAL_TASK_FAILED}

# ESCORT 계열 task (거절 규칙 §6.2: PATROL/IDLE이면 거절 대상)
ESCORT_TASK_TYPES = {TASK_ESCORT_TO_HANDOVER, TASK_ESCORT_TO_FINAL}

# 거절 판단 기준(계약 §6.2): "지금 임무 없이 대기 중인가" — PATROL/IDLE만 해당.
IDLE_LIKE = (ROBOT_PATROL, ROBOT_IDLE)

# ── task_type → 진행 중 / 완료 시 robot state ─────────────────────────────
# 출처: docs/INTERFACE_CONTRACT.md §6.1 "도착 후 로봇 동작" — FMS가 기대하던
# robot state 전이를 그대로 보존한다(이 표가 핵심 계약 — 분산 전환과 무관).
TASK_PROGRESS_STATE: dict[str, str] = {
    TASK_MOVE_TO_STANDBY:    ROBOT_RESERVED,
    TASK_ESCORT_TO_HANDOVER: ROBOT_ESCORTING,
    TASK_ESCORT_TO_FINAL:    ROBOT_ESCORTING,
    TASK_RETURN_TO_BASE:     ROBOT_RETURNING,
}
TASK_DONE_STATE: dict[str, str] = {
    TASK_MOVE_TO_STANDBY:    ROBOT_HANDOVER_READY,   # 후속 task(ESCORT_TO_FINAL) 대기
    TASK_ESCORT_TO_HANDOVER: ROBOT_WAITING_HANDOVER, # 핸드오버 지점 도착, 대기
    TASK_ESCORT_TO_FINAL:    ROBOT_ESCORTING,        # 곧 RETURN_TO_BASE를 스스로 셀프 디스패치
    TASK_RETURN_TO_BASE:     ROBOT_PATROL,           # task 완전 종료 → 순찰(기본 동작)
}
