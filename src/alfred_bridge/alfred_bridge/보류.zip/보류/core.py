#!/usr/bin/env python3
"""RobotStateManager — robot2/robot4 공용 상태 머신 + 분산 릴레이 두뇌(본체).

fms_server 폐기로 "FMS가 명령 → 로봇이 따른다"는 전제가 사라졌다. 이제 각 로봇은
스스로 두 가지만 관찰해서 행동을 정한다 — "승인자 없는 대칭적 자기-전이"
(설계 원본: docs 플랜 "분산 두뇌" 절):
  ① 자기 상태(Nav2 도착 결과 등 — 지금까지와 동일한 입력으로 결정)
  ② partner의 마지막 보고 상태(`/{partner}/state` 상호 구독으로 직접 관찰)
둘이 같은 두 사실을 보고 같은 결론에 독립적으로 도달해 각자 자기 자신에게만
다음 task를 self-dispatch한다 — 합의·승인 절차도, 명령을 주고받는 일도 없다
(따라서 race condition도 없다). 유일한 진짜 "상대에게 보내는 명령"은 교차층
미션 시작 시 next_robot에게 보내는 `relay_task`(MOVE_TO_STANDBY) 1회뿐이다.

state(및 IF-02 보고)는 다음 입력들의 '취합'으로만 바뀐다(자기 stage는 절대
스스로 정하지 않는다는 옛 원칙은 유지하되, "stage를 누가 알려주는가"만 FMS→자기
자신/partner로 바뀌었다):
  ① escort_request(IF-01, Interaction이 직접) / relay_task(partner의 유일한 명령)
                                    → 무엇을 해야 하는가 (state/task_status 결정)
  ② Nav2 주행 결과(성공/실패)        → 그 일이 어떻게 됐는가
  ③ map→base_link TF(localization)  → 지금 어디에 있는가 (pose만 갱신)
  ④ partner의 보고 상태(`/{partner}/state`) → 합 조건 충족 시 다음 task 자기-결정
유일한 예외는 여전히 PATROL(절대 규칙 8 — task가 없을 때만 알아서 순찰한다).

직접 실행하지 말고 robot2_manager / robot4_manager를 사용하세요.
"""
from __future__ import annotations

import logging
import threading
import uuid
from datetime import datetime, timezone

from geometry_msgs.msg import Pose2D
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from std_msgs.msg import String

from alfred_interfaces.msg import MissionSignal, RobotState, Request, Task, TaskAck

from . import poi
from .states import (
    ACK_ACCEPT, ACK_REJECT, ESCORT_TASK_TYPES, IDLE_LIKE,
    ROBOT_EMERGENCY, ROBOT_ERROR, ROBOT_HANDOVER_READY, ROBOT_INTERACTING,
    ROBOT_PATROL, ROBOT_WAITING_HANDOVER,
    SIGNAL_ABORT, SIGNAL_EMERGENCY, SIGNAL_TASK_FAILED,
    TASK_DONE_STATE, TASK_ESCORT_TO_FINAL, TASK_ESCORT_TO_HANDOVER,
    TASK_MOVE_TO_STANDBY, TASK_PROGRESS_STATE, TASK_RETURN_TO_BASE,
    TS_ACCEPTED, TS_FAILED, TS_RUNNING, TS_SUCCEEDED,
)
from .docking import DockController
from .localization import Localizer
from .navigator import Nav2Readiness, Navigator


logger = logging.getLogger('robot_sm.core')

_STATUS_PERIOD_SEC = 0.5        # /{ns}/state 주기 보고 = 2Hz (계약 §6 "1~2Hz" 충족)
_POSE_PERIOD_SEC = 0.2          # map→base_link TF 폴링 주기 — 주행 여부와 무관하게 항상 갱신
_PATROL_RETRY_PERIOD_SEC = 2.0  # 자율 PATROL 시작/재개 점검 주기(액션 서버 미준비 시 재시도 포함)
# 옛 fms_server/config.py의 STATUS_WATCH_INTERVAL/STATUS_TIMEOUT 값을 그대로 재사용
# (중앙 감시 스레드 → 각 로봇이 "교차층 미션 진행 중일 때만" 자가 점검하는 형태로 분산).
_PARTNER_CHECK_PERIOD_SEC = 1.0
_PARTNER_TIMEOUT_SEC = 10.0


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec='milliseconds')


def _pose2d(pose: dict | None) -> Pose2D:
    p = Pose2D()
    pose = pose or {}
    p.x = float(pose.get('x', 0.0))
    p.y = float(pose.get('y', 0.0))
    p.theta = float(pose.get('theta', 0.0))
    return p


class RobotStateManager(Node):
    def __init__(self, robot_id: str, config: dict) -> None:
        namespace = config['namespace']
        # tf2_ros(Buffer/TransformListener)는 절대경로 /tf, /tf_static을 구독하도록
        # 고정돼 있다. 그런데 이 로봇의 실제 TF는 /robot2/tf, /robot2/tf_static처럼
        # 네임스페이스 하위에 발행된다(`ros2 topic list`로 확인) — 리매핑 없이는
        # 빈 전역 /tf만 보게 되어 lookup_transform이 항상 실패하고 pose가 (0,0)에
        # 고정된다. 노드 단위 리매핑으로 실제 발행 토픽을 보게 한다.
        tf_remap_args = [
            '--ros-args',
            '--remap', f'/tf:={namespace}/tf',
            '--remap', f'/tf_static:={namespace}/tf_static',
        ]
        super().__init__(f'robot_state_manager_{robot_id}', cli_args=tf_remap_args)
        self._robot_id = robot_id
        self._namespace = namespace
        self._battery = config.get('initial_battery')  # 보고용 자리값 — 실배터리 연동은 범위 밖

        # ── 상태 — 계약 값만 사용. ROS2 콜백들이 함께 건드리므로 락 보호 ──
        self._lock = threading.Lock()
        self._state        = ROBOT_PATROL   # task 없을 때 기본 동작 (계약 §6.1: "순찰은 task 아님")
        self._task_id      = None
        self._task_type    = None
        self._mission_id   = None
        self._task_status  = None
        self._error_code   = None
        self._pose         = {'x': 0.0, 'y': 0.0, 'theta': 0.0}

        # ── 자율 PATROL — task 없을 때 로봇이 알아서 도는 유일한 예외 동작
        # (절대 규칙 8: 명령 주체가 사라져도 이 동작의 자율성은 그대로 유지된다 —
        # 좌표는 ROBOT{2,4}_CONFIG['patrol_waypoints']에서만 온다). 비어 있으면 대기만.
        self._patrol_waypoints = config.get('patrol_waypoints') or []
        self._patrol_index = 0
        self._patrolling   = False   # True인 동안만 _on_patrol_result가 다음 목표로 이어감

        # ── 도킹 — 기동 시 도크에 있으면 PATROL보다 undock이 먼저 (전적으로 로봇 쪽 판단)
        self._undocking = False
        self._dock = DockController(self, self._namespace, on_undock_result=self._on_undock_result)

        # ── 주행 실행기 (Nav2) — task용/자율 PATROL용 분리(결과 콜백 혼선 차단) ──
        self._nav_ready = Nav2Readiness(self, self._namespace)
        self._nav = Navigator(self, self._namespace, on_result=self._on_nav_result,
                              ready=self._nav_ready)
        self._patrol_nav = Navigator(self, self._namespace, on_result=self._on_patrol_result,
                                     ready=self._nav_ready)

        # ── 위치 추적 — map→base_link TF 폴링 ──
        self._localizer = Localizer(self,
                                    map_frame=config.get('map_frame', 'map'),
                                    base_frame=config.get('base_frame', 'base_link'))

        # ── 분산 두뇌 — partner 관찰 + 합 조건 자기-전이 (FMS의
        # _maybe_approve_handover를 "승인자 없는 대칭적 자기-전이"로 대체) ──
        self._partner_id = config['partner_id']
        self._partner_namespace = config['partner_namespace']
        self._base_poi = config['base_poi']           # poi.first_of_type 대신 — 복귀 지점은 로봇별 고정
        self._partner_state: str | None = None
        self._partner_last_seen = None                # rclpy.time.Time — 마지막 partner state 수신 시각
        self._cross_mission_active = False            # True인 동안만 partner 타임아웃 자가 점검
        # next_robot 역할일 때 relay_task(MOVE_TO_STANDBY)에 함께 실려 온 "최종 목적지"
        # — Task.msg에 전용 필드가 없어 goal_* 필드를 빌려 보낸다(_on_relay_task 설명 참고).
        self._relay_final_goal: dict | None = None

        # ── ROS2 단일 통신 계층 (fms_server/MQTT 폐기 — 메시지 스키마는 그대로 재사용,
        #    바뀐 건 전송 계층과 명령 발신 주체뿐이다) ──
        # state: 2Hz 주기 보고, 유실 허용(IF-02 §9.1과 같은 결) → best-effort QoS
        self._state_pub = self.create_publisher(
            RobotState, f'{namespace}/state', qos_profile_sensor_data)
        self.create_subscription(
            RobotState, f'{self._partner_namespace}/state',
            self._on_partner_state, qos_profile_sensor_data)
        # relay_task/relay_ack — 유일한 진짜 피어투피어 명령(MOVE_TO_STANDBY) 채널, 보장 필요
        self._relay_task_pub = self.create_publisher(
            Task, f'{self._partner_namespace}/relay_task', 10)
        self.create_subscription(Task, f'{namespace}/relay_task', self._on_relay_task, 10)
        self._relay_ack_pub = self.create_publisher(TaskAck, f'{namespace}/relay_ack', 10)
        self.create_subscription(
            TaskAck, f'{self._partner_namespace}/relay_ack', self._on_relay_ack, 10)
        # escort_request — Interaction → 호출된 로봇 직접 (FMS 경유 없음, 옛 IF-01)
        self.create_subscription(Request, f'{namespace}/escort_request', self._on_escort_request, 10)
        # mission_signal — partner 간 예외 전파 전용(ABORT/EMERGENCY/TASK_FAILED), FMS의 _terminate 대체
        self._signal_pub = self.create_publisher(
            MissionSignal, f'{self._partner_namespace}/mission_signal', 10)
        self.create_subscription(
            MissionSignal, f'{namespace}/mission_signal', self._on_mission_signal, 10)
        # 테스트 전용 제어 채널(계약 외, mock/{robot_id}/cmd) — 고객 호출 등 로봇 자체
        # 전이를 재현한다. 토픽 이름은 MQTT 시절과 동일하게 유지(mock_robot.py와 호환
        # 의도는 아니고 — 이미 알려진 이름이라 재사용). 페이로드만 dict→문자열로 단순화.
        self.create_subscription(String, f'mock/{robot_id}/cmd', self._on_test_cmd, 10)

        self.create_timer(_POSE_PERIOD_SEC, self._update_pose)
        self.create_timer(_STATUS_PERIOD_SEC, self._publish_state)
        self.create_timer(_PATROL_RETRY_PERIOD_SEC, self._maybe_start_patrol)
        self.create_timer(_PARTNER_CHECK_PERIOD_SEC, self._check_partner_timeout)
        self.get_logger().info(
            f'[{robot_id}] 준비 완료 — partner={self._partner_id} 상태 구독 중, '
            f'escort_request 대기')

    # ════════════════════════════════════════════════════════════════
    # ① 입력: task 시작 — escort_request(IF-01 직접 수신)·relay_task(유일한
    #    피어투피어 명령)·자기 자신의 합-조건 판단, 세 경로 모두 결국 여기로 모인다
    # ════════════════════════════════════════════════════════════════
    def _start_task_locked(self, task_id: str, task_type: str,
                           mission_id: str | None, goal: dict | None) -> dict | None:
        """task 시작 부기(state 전이·즉시 보고)만 수행하고 Nav2로 보낼 목표를 반환한다.

        호출자가 self._lock을 보유한 상태에서 호출해야 한다 — Nav2 송신은
        반환값을 들고 락 밖에서 _send_nav_goal로 한다(액션 콜백이 다시 락을
        잡으므로 보유 중 호출 금지 — 옛 _on_task와 같은 규칙)."""
        if task_type not in TASK_PROGRESS_STATE:
            self.get_logger().error(f'[TASK] 알 수 없는 task_type "{task_type}" — 무시')
            return None
        self._patrolling = False  # task 시작 — 자율 PATROL 중단(끝나면 타이머가 재개)
        self._task_id     = task_id
        self._task_type   = task_type
        self._mission_id  = mission_id
        self._task_status = TS_ACCEPTED
        self._set_state_locked(TASK_PROGRESS_STATE[task_type])
        self._task_status = TS_RUNNING
        self._publish_state_locked()   # 전이 즉시 보고(계약 §6: 변화 시 즉시)
        return goal

    def _self_dispatch_locked(self, task_type: str, mission_id: str | None,
                              goal: dict | None) -> dict | None:
        return self._start_task_locked(self._gen_task_id(), task_type, mission_id, goal)

    def _self_dispatch(self, task_type: str, mission_id: str | None, goal: dict | None) -> None:
        """self._lock을 보유하지 않은 호출자용 — 자기 자신에게 task를 셀프 디스패치한다.

        "명령"이 아니다 — 누가 시켜서가 아니라, 관찰한 사실(escort_request·합 조건
        충족 등)로부터 스스로 다음 행동을 정해 자기 자신의 task 큐에 넣는 것뿐이다."""
        with self._lock:
            goal_to_send = self._self_dispatch_locked(task_type, mission_id, goal)
        self._send_nav_goal(goal_to_send)

    def _send_nav_goal(self, goal: dict | None) -> None:
        """_start_task_locked가 돌려준 목표를 Nav2로 전송한다 — 반드시 락 밖에서."""
        if goal is None:
            return
        self._patrol_nav.cancel()  # 순찰 중이던 목표 선점 취소 — task 주행에 집중
        pose = (goal or {}).get('pose') or {}
        if not self._nav.send_goal(pose.get('x', 0.0), pose.get('y', 0.0), pose.get('theta', 0.0)):
            with self._lock:
                self._fail_current_task_locked('NAV_SERVER_NOT_READY')

    def _gen_task_id(self) -> str:
        return f'TASK_{self._robot_id}_{uuid.uuid4().hex[:8]}'

    def _gen_mission_id(self) -> str:
        return f'MISSION_{self._robot_id}_{uuid.uuid4().hex[:8]}'

    # ════════════════════════════════════════════════════════════════
    # ①-a 입력: escort_request(IF-01, Interaction → 호출된 로봇 직접) — ESCORT/CANCEL
    #     예전엔 FMS가 same/cross-floor를 가려 task를 배정했지만, 이제 호출받은
    #     로봇 자신이 자기 POI 테이블로 직접 판단한다(달라진 건 "판단 주체"뿐,
    #     판단 기준 자체는 옛 mission_manager._create_escort와 동일).
    # ════════════════════════════════════════════════════════════════
    def _on_escort_request(self, msg: Request) -> None:
        if msg.request_type == 'CANCEL':
            self._on_cancel_request(msg)
            return
        if msg.request_type != 'ESCORT':
            self.get_logger().info(f'[REQUEST] 미지원 request_type "{msg.request_type}" — 무시')
            return

        dest_poi_id = msg.dest_poi_id
        if poi.get(dest_poi_id) is None:
            self.get_logger().error(f'[REQUEST] 알 수 없는 목적지 poi_id="{dest_poi_id}" — 무시')
            return

        same_floor = (msg.dest_floor == msg.origin_floor)
        mission_id = self._gen_mission_id()

        if same_floor:
            self.get_logger().warn(
                f'[MISSION] {mission_id} 동층 직행 → 자기에게 ESCORT_TO_FINAL({dest_poi_id})')
            self._self_dispatch(TASK_ESCORT_TO_FINAL, mission_id, poi.goal_for(dest_poi_id))
            return

        # 교차층 — 이 설계에서 유일하게 진짜 "상대에게 보내는 명령"이 필요한 지점:
        # next_robot에게 "고객 온다, standby로 가있어"를 알린다(= 옛 FMS의 최초
        # MOVE_TO_STANDBY 배정). 이후 핸드오버 진행은 양쪽 다 partner 상태 관찰만으로
        # 스스로 진행한다 — 더 이상의 cross-robot 명령은 없다.
        with self._lock:
            self._cross_mission_active = True
        handover_goal = poi.goal_for(poi.first_of_type('HANDOVER'))
        self._self_dispatch(TASK_ESCORT_TO_HANDOVER, mission_id, handover_goal)
        self._publish_relay_task(mission_id, dest_poi_id, msg.dest_floor,
                                 msg.customer_id, msg.customer_profile, msg.customer_language)
        self.get_logger().warn(
            f'[MISSION] {mission_id} 교차층 릴레이 시작 — 핸드오버로 에스코트 + '
            f'{self._partner_id}에 대기 지시(최종 목적지={dest_poi_id})')

    def _on_cancel_request(self, msg: Request) -> None:
        goal = None
        with self._lock:
            if self._task_id is None or self._state in IDLE_LIKE:
                self.get_logger().info('[REQUEST] CANCEL 수신 — 진행 중인 임무 없음, 무시')
                return
            was_cross = self._cross_mission_active
            self.get_logger().warn(f'[MISSION] {self._mission_id} 사용자 취소 — 정리 후 복귀')
            goal = self._terminate_mission_locked()
            if was_cross:
                self._publish_signal_locked(SIGNAL_ABORT, 'user CANCEL')
        self._send_nav_goal(goal)

    def _publish_relay_task(self, mission_id: str, final_poi_id: str, final_floor: int,
                            customer_id: str, customer_profile: str, customer_language: str) -> None:
        """next_robot에게 보내는 단 하나의 진짜 명령 — Task/MOVE_TO_STANDBY 재사용.

        주의: goal_* 필드에는 "지금 가야 할 곳(standby)"이 아니라 "나중에 핸드오버
        받으면 데려다줄 최종 목적지"를 싣는다. Task.msg에는 최종 목적지 전용 필드가
        없고, standby 좌표는 next_robot이 자기 POI 테이블에서 직접(`first_of_type
        ("STANDBY")`) 찾을 수 있어 굳이 실어 보낼 필요가 없기 때문이다 — 정작 상대가
        스스로 알아낼 수 없는 정보(최종 목적지)만 골라 보낸다. 수신측 _on_relay_task
        와 쌍을 이루는 약속이니 두 곳을 함께 고치지 않으면 깨진다."""
        final = poi.get(final_poi_id) or {}
        msg = Task()
        msg.task_id = self._gen_task_id()
        msg.robot_id = self._partner_id
        msg.task_type = TASK_MOVE_TO_STANDBY
        msg.goal_poi_id = final_poi_id
        msg.goal_pose = _pose2d(final.get('pose'))
        msg.goal_floor = int(final_floor)
        msg.customer_id = customer_id
        msg.customer_profile = customer_profile
        msg.customer_language = customer_language
        msg.mission_id = mission_id
        msg.cancel_task_id = ''
        msg.timestamp = _now_iso()
        self._relay_task_pub.publish(msg)
        self.get_logger().warn(f'[RELAY] → {self._partner_id}  MOVE_TO_STANDBY (최종={final_poi_id})')

    # ════════════════════════════════════════════════════════════════
    # ①-b 입력: relay_task 수신 — 유일한 피어투피어 명령(MOVE_TO_STANDBY)에 대한
    #     ACCEPT/REJECT 응답 + 수락 시 자기 자신에게 셀프 디스패치.
    #     ACK 판정 규칙은 옛 IF-03 task 수락 규칙(_decide_ack_locked)과 동일 —
    #     명령의 출처가 FMS에서 partner로 바뀌었을 뿐 "받는 쪽" 입장은 변함없다.
    # ════════════════════════════════════════════════════════════════
    def _on_relay_task(self, msg: Task) -> None:
        task_id = msg.task_id
        task_type = msg.task_type
        mission_id = msg.mission_id
        goal_to_send = None
        with self._lock:
            result = self._decide_ack_locked(task_type)
            self._publish_relay_ack_locked(task_id, result)
            self.get_logger().warn(
                f'[RELAY] {self._partner_id} → {task_id} {task_type} → {result} '
                f'(현재 state={self._state})')
            if result == ACK_REJECT:
                return   # PATROL/IDLE이 아닌데 거절했을 리 없음 — 유령 에스코트 방지
            if task_type != TASK_MOVE_TO_STANDBY:
                self.get_logger().error(f'[RELAY] 예상치 못한 task_type "{task_type}" — 무시')
                return

            # _publish_relay_task와 쌍을 이루는 약속: goal_*에는 "최종 목적지"가
            # 실려 있다 — 나중에(합 조건 충족 시) ESCORT_TO_FINAL로 쓸 좌표를 미리
            # 기억해 둔다. 지금 당장 가야 할 standby 좌표는 직접 조회한다.
            self._relay_final_goal = {
                'poi_id': msg.goal_poi_id or None,
                'floor': msg.goal_floor,
                'pose': {'x': msg.goal_pose.x, 'y': msg.goal_pose.y, 'theta': msg.goal_pose.theta},
            }
            self._cross_mission_active = True
            standby_goal = poi.goal_for(poi.first_of_type('STANDBY'))
            goal_to_send = self._self_dispatch_locked(TASK_MOVE_TO_STANDBY, mission_id, standby_goal)
        self._send_nav_goal(goal_to_send)

    def _on_relay_ack(self, msg: TaskAck) -> None:
        """relay_task에 대한 partner의 응답 — REJECT면 미션을 더 끌고 갈 이유가
        없다(상대가 받으러 오지 않을 핸드오버 지점으로 가 봐야 헛걸음). 옛 FMS의
        on_task_ack(REJECT → mission FAILED)와 같은 결로 즉시 정리하고 복귀한다."""
        if msg.result != ACK_REJECT:
            return
        goal = None
        with self._lock:
            if not self._cross_mission_active or self._task_id is None:
                return
            self.get_logger().error(
                f'[RELAY] {self._partner_id}가 relay_task {msg.task_id} 거절 — 미션 중단, 복귀')
            goal = self._terminate_mission_locked()
            self._publish_signal_locked(SIGNAL_ABORT, f'{self._partner_id} REJECT relay_task')
        self._send_nav_goal(goal)

    def _publish_relay_ack_locked(self, task_id: str, result: str) -> None:
        msg = TaskAck()
        msg.task_id = task_id
        msg.robot_id = self._robot_id
        msg.result = result
        msg.timestamp = _now_iso()
        self._relay_ack_pub.publish(msg)

    def _decide_ack_locked(self, task_type: str) -> str:
        """거절 규칙(계약 §6.2): "지금 임무 없이 대기 중인가"가 유일한 기준.

        INTERACTING/RESERVED/HANDOVER_READY/WAITING_HANDOVER/ESCORTING 등
        '임무 중' 상태에서는 ESCORT 계열도 항상 수락한다(특히 next_robot이
        HANDOVER_READY 상태에서 ESCORT_TO_FINAL을 자기-디스패치하는 정상 흐름과
        섞이지 않도록 — 이 판정은 오직 relay_task 수신 시에만 쓰인다).
        """
        if task_type in ESCORT_TASK_TYPES and self._state in IDLE_LIKE:
            return ACK_REJECT
        return ACK_ACCEPT

    # ════════════════════════════════════════════════════════════════
    # ① 입력: 테스트 전용 제어 채널(계약 외) — 고객 호출/비상 등 로봇 자체 전이 재현
    # ════════════════════════════════════════════════════════════════
    def _on_test_cmd(self, msg: String) -> None:
        """실제로는 키오스크/이상감지/E-stop 등에서 비롯될 로봇 자신의 판단으로
        일어나는 전이(고객 호출 응대, 비상 등)를 테스트에서 흉내 낸다. 'emergency'는
        EMERGENCY 신호 전파(_set_state_locked 훅) 시나리오 검증을 위해 둔다."""
        cmd = msg.data
        with self._lock:
            if cmd == 'emergency':
                self._set_state_locked(ROBOT_EMERGENCY)   # 임무 중에도 즉시 — 비상은 기다리지 않는다
                return
            if self._task_id is not None:
                return
            if cmd == 'call':
                self._set_state_locked(ROBOT_INTERACTING)
            elif cmd == 'idle':
                self._set_state_locked(ROBOT_PATROL)

    # ════════════════════════════════════════════════════════════════
    # ② 입력: 위치 — map→base_link TF (주행 여부와 무관하게 항상 갱신)
    # ════════════════════════════════════════════════════════════════
    def _update_pose(self) -> None:
        pose = self._localizer.current_pose()
        if pose is None:
            return
        with self._lock:
            self._pose = pose

    # ════════════════════════════════════════════════════════════════
    # ③ 입력: Nav2 주행 결과 — task_status/state 계산의 마지막 조각
    # ════════════════════════════════════════════════════════════════
    def _on_nav_result(self, success: bool) -> None:
        pending_goal = None
        with self._lock:
            if self._task_id is None:
                return  # 이미 취소·종료된 task의 뒤늦은 콜백 — 무시

            if success:
                self._task_status = TS_SUCCEEDED
                done_state = TASK_DONE_STATE[self._task_type]
                task_type_done = self._task_type
                mission_id = self._mission_id
                self.get_logger().warn(
                    f'[TASK] {self._task_id} {task_type_done} 완료 → {done_state}')
                self._set_state_locked(done_state)
                if task_type_done == TASK_RETURN_TO_BASE:
                    # RETURN_TO_BASE는 'task 완전 종료' — 보고 필드·미션 정보 초기화
                    self._task_id = self._task_type = self._mission_id = None
                    self._task_status = None
                    self._cross_mission_active = False
                    self._relay_final_goal = None
                # ★ 다음 자기-전이를 검사·실행하기 *전에* 먼저 이 done_state를 내보낸다.
                # 곧장 다음 상태로 자기-전이해버리면(아래 두 분기) partner는 이 milestone
                # (특히 WAITING_HANDOVER/HANDOVER_READY)을 한 번도 못 보고 지나칠 수 있어
                # partner 쪽 합 조건이 영원히 못 맞는 race가 생긴다 — 실측으로 확인된 버그.
                self._publish_state_locked()
                if task_type_done == TASK_ESCORT_TO_FINAL:
                    # 고객을 최종 목적지에 인계 완료 — 더 살필 합 조건이 없는 유일한
                    # 종결 지점이라 partner 관찰 없이 곧장 복귀를 자기-디스패치한다
                    # (states.TASK_DONE_STATE의 "곧 RETURN_TO_BASE를 스스로 셀프
                    # 디스패치" 주석이 가리키는 지점이 바로 여기 — 옛 FMS도
                    # ESCORT_TO_FINAL 완료 시 바로 RETURN_TO_BASE를 내렸다).
                    self.get_logger().warn(
                        f'[MISSION] {mission_id} 인계 완료 → 자기에게 RETURN_TO_BASE')
                    pending_goal = self._self_dispatch_locked(
                        TASK_RETURN_TO_BASE, mission_id, poi.goal_for(self._base_poi))
                elif task_type_done != TASK_RETURN_TO_BASE:
                    # WAITING_HANDOVER/HANDOVER_READY 진입 — partner가 합 조건의 반대쪽에
                    # 이미 먼저 도달해 있을 수 있다. partner의 "다음" 상태 갱신을 기다리면
                    # (그사이 partner가 한 단계 더 진행해버려) 이 조합을 영영 못 보는 race가
                    # 생기므로, 캐시된 partner 상태로 지금 즉시 한 번 더 검사한다 — 위에서
                    # done_state를 이미 내보냈으니 partner도 이 상태를 놓치지 않는다.
                    # (_maybe_self_transition_locked는 self._state를 트리거 조건으로 쓰므로
                    #  이후 _on_partner_state에서 다시 불려도 1회만 발동 — 이중 호출 안전)
                    pending_goal = self._maybe_self_transition_locked()
            else:
                self._fail_current_task_locked('NAV_FAILED')
                self._publish_state_locked()  # 전이/완료 즉시 보고
        self._send_nav_goal(pending_goal)

    def _fail_current_task_locked(self, error_code: str) -> None:
        """task 실패 → ERROR. 옛 FMS는 실패한 로봇에게도 RETURN_TO_BASE를 내려
        '복구'시켰지만, 명령 주체가 사라진 지금 자가-RETURN_TO_BASE를 시도하면
        실패가 실패를 부르는 루프 위험이 있다 — ERROR에 머물러 운영자 개입을
        기다리는 쪽이 더 안전하다(의도적으로 옛 동작과 다른 선택). 대신 진행
        중이던 교차층 미션이 있다면 partner에게는 즉시 알려 스스로 정리하게 한다."""
        self._task_status = TS_FAILED
        self._error_code = error_code
        was_cross = self._cross_mission_active
        self._cross_mission_active = False
        self._relay_final_goal = None
        self._set_state_locked(ROBOT_ERROR)
        self.get_logger().error(f'[TASK] {self._task_id} 실패({error_code}) → ERROR')
        if was_cross:
            self._publish_signal_locked(SIGNAL_TASK_FAILED, f'{self._task_id} {error_code}')

    # ════════════════════════════════════════════════════════════════
    # ④ 자율 PATROL — task 없을 때 로봇이 알아서 도는 유일한 예외 동작
    # ════════════════════════════════════════════════════════════════
    def _maybe_start_patrol(self) -> None:
        """주기 점검 — PATROL ∧ task 없음 ∧ 아직 순찰 중 아니면 다음 목표로 출발.
        도킹 중이면 순찰보다 undock이 먼저(둘 다 '로봇이 알아서 정하는' 자율 동작)."""
        if not self._patrol_waypoints:
            return
        with self._lock:
            if self._patrolling or self._state != ROBOT_PATROL or self._task_id is not None:
                return
            docked = self._dock.is_docked
            if docked is None:
                return   # dock_status 아직 수신 전 — 다음 주기에 재확인
            start_undock = docked and not self._undocking
            if start_undock:
                self._undocking = True
            wp = self._patrol_waypoints[self._patrol_index]

        if docked:
            if start_undock:
                self.get_logger().warn('[DOCK] 도킹 상태로 기동 — undock 먼저 수행 후 순찰 시작')
                if not self._dock.undock():
                    with self._lock:
                        self._undocking = False  # 서버 미준비 — 다음 주기에 재시도
            return

        if self._patrol_nav.send_goal(wp['x'], wp['y'], wp.get('theta', 0.0)):
            with self._lock:
                self._patrolling = True

    def _on_undock_result(self, success: bool) -> None:
        with self._lock:
            self._undocking = False
        if success:
            self.get_logger().warn('[DOCK] undock 완료 — 순찰로 진행')
        else:
            self.get_logger().error('[DOCK] undock 실패 — 다음 주기에 재시도')

    def _on_patrol_result(self, success: bool) -> None:
        with self._lock:
            if not self._patrolling:
                return
            self._patrol_index = (self._patrol_index + 1) % len(self._patrol_waypoints)
            wp = self._patrol_waypoints[self._patrol_index]
        if not self._patrol_nav.send_goal(wp['x'], wp['y'], wp.get('theta', 0.0)):
            with self._lock:
                self._patrolling = False

    # ════════════════════════════════════════════════════════════════
    # ⑤ 입력: partner 상태 관찰 — 합 조건 충족 시 자기 자신에게 다음 task를
    #    self-dispatch한다("승인자 없는 대칭적 자기-전이"의 핵심 — 옛
    #    _maybe_approve_handover를 대체). 두 로봇이 같은 두 사실(내 상태 +
    #    partner 상태)을 보고 같은 결론에 독립적으로 도달하므로 race condition이
    #    없다 — 그리고 자기-디스패치가 곧 트리거 조건의 self._state를 바꾸므로
    #    별도 가드 플래그 없이 자연히 1회만 발동한다.
    # ════════════════════════════════════════════════════════════════
    def _on_partner_state(self, msg: RobotState) -> None:
        pending_goal = None
        with self._lock:
            self._partner_state = msg.state
            self._partner_last_seen = self.get_clock().now()
            pending_goal = self._maybe_self_transition_locked()
        self._send_nav_goal(pending_goal)

    def _maybe_self_transition_locked(self) -> dict | None:
        if self._state == ROBOT_WAITING_HANDOVER and self._partner_state == ROBOT_HANDOVER_READY:
            # 나(start_robot)는 핸드오버 지점에서 대기 중 + partner(next_robot)가
            # 인수 준비 완료 → 고객은 partner에게 넘어간다. 나는 복귀.
            self.get_logger().warn(
                f'[MISSION] {self._mission_id} 합 조건 충족(나=WAITING_HANDOVER, '
                f'{self._partner_id}=HANDOVER_READY) → 자기에게 RETURN_TO_BASE')
            self._cross_mission_active = False
            return self._self_dispatch_locked(
                TASK_RETURN_TO_BASE, self._mission_id, poi.goal_for(self._base_poi))

        if self._state == ROBOT_HANDOVER_READY and self._partner_state == ROBOT_WAITING_HANDOVER:
            # 나(next_robot)는 standby에서 대기 중 + partner(start_robot)가 핸드오버
            # 지점에 고객과 함께 도착 → 인수해서 최종 목적지로 출발.
            final_goal = self._relay_final_goal
            self.get_logger().warn(
                f'[MISSION] {self._mission_id} 합 조건 충족(나=HANDOVER_READY, '
                f'{self._partner_id}=WAITING_HANDOVER) → 자기에게 ESCORT_TO_FINAL')
            self._cross_mission_active = False
            return self._self_dispatch_locked(TASK_ESCORT_TO_FINAL, self._mission_id, final_goal)

        return None

    def _check_partner_timeout(self) -> None:
        """중앙 감시 스레드 대신 — 교차층 미션 진행 중일 때만 partner의 상태
        수신 간격을 자가 점검한다(옛 fms_server.check_timeouts을 분산 형태로).
        타임아웃 시 partner는 통신 두절 상태이므로 신호를 보내봐야 무의미 —
        그냥 내 쪽만 정리하고 복귀한다(옛 _terminate의 silent_robot 처리와 같은 결:
        통신 두절 로봇에는 명령하지 않는다)."""
        goal = None
        with self._lock:
            if not self._cross_mission_active or self._partner_last_seen is None:
                return
            elapsed = (self.get_clock().now() - self._partner_last_seen).nanoseconds / 1e9
            if elapsed <= _PARTNER_TIMEOUT_SEC:
                return
            self.get_logger().error(
                f'[TIMEOUT] {self._partner_id} 응답 없음 {elapsed:.1f}s > '
                f'{_PARTNER_TIMEOUT_SEC:.0f}s — 미션 정리, 복귀')
            goal = self._terminate_mission_locked()
        self._send_nav_goal(goal)

    # ════════════════════════════════════════════════════════════════
    # 예외 전파(mission_signal) — partner 간 ABORT/EMERGENCY/TASK_FAILED
    # 유일한 비-task 피어투피어 채널. FMS의 _terminate 캐스케이드를 대체한다.
    # ════════════════════════════════════════════════════════════════
    def _on_mission_signal(self, msg: MissionSignal) -> None:
        goal = None
        with self._lock:
            if self._task_id is None or msg.mission_id != (self._mission_id or ''):
                return  # 내가 모르는/이미 끝난 미션의 신호 — 무시(지연 도착 등 안전 처리)
            self.get_logger().warn(
                f'[SIGNAL] {self._partner_id} ← {msg.signal} ({msg.reason}) — 미션 정리, 복귀')
            goal = self._terminate_mission_locked()
        self._send_nav_goal(goal)

    def _publish_signal_locked(self, signal: str, reason: str) -> None:
        msg = MissionSignal()
        msg.mission_id = self._mission_id or ''
        msg.robot_id = self._robot_id
        msg.signal = signal
        msg.reason = reason
        msg.timestamp = _now_iso()
        self._signal_pub.publish(msg)
        self.get_logger().warn(f'[SIGNAL] → {self._partner_id}  {signal} ({reason})')

    def _terminate_mission_locked(self) -> dict | None:
        """진행 중이던 임무를 정리하고 복귀(RETURN_TO_BASE)를 자기에게
        self-dispatch한다 — CANCEL/relay 거절/partner 신호/타임아웃, 모든 예외
        종결 경로가 이리로 모인다(옛 FMS _terminate의 '내 쪽 정리' 부분과 동급).
        호출자가 self._lock 보유 상태에서 호출 — 반환된 goal은 락 밖에서 전송."""
        mission_id = self._mission_id
        self._nav.cancel()
        self._cross_mission_active = False
        self._relay_final_goal = None
        return self._self_dispatch_locked(
            TASK_RETURN_TO_BASE, mission_id, poi.goal_for(self._base_poi))

    # ════════════════════════════════════════════════════════════════
    # 상태 전이 / state(IF-02 동등) 보고
    # ════════════════════════════════════════════════════════════════
    def _set_state_locked(self, new_state: str) -> None:
        if self._state == new_state:
            return
        self.get_logger().warn(f'[STATE] {self._state} → {new_state}')
        self._state = new_state
        # EMERGENCY 진입은 기다리지 않고 즉시 partner에 전파한다(원인 로봇 자신에게는
        # 옛 FMS도 명령하지 않았다 — 로봇 소유 상태이고 명령이 무의미하므로 그대로 둔다).
        if new_state == ROBOT_EMERGENCY and self._cross_mission_active:
            self._publish_signal_locked(SIGNAL_EMERGENCY, f'{self._robot_id} EMERGENCY')

    def _publish_state(self) -> None:
        """주기 보고 타이머 콜백 (0.5s = 2Hz)."""
        with self._lock:
            self._publish_state_locked()

    def _publish_state_locked(self) -> None:
        msg = RobotState()
        msg.robot_id = self._robot_id
        msg.state = self._state
        msg.pose = _pose2d(self._pose)
        msg.battery = self._battery if self._battery is not None else 0
        msg.current_task_id = self._task_id or ''
        msg.task_status = self._task_status or ''
        msg.error_code = self._error_code or ''
        msg.timestamp = _now_iso()
        self._state_pub.publish(msg)

    def destroy_node(self) -> bool:
        return super().destroy_node()
