import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import AnyLaunchDescriptionSource


def generate_launch_description():
    xml_launch_file = os.path.join(
        get_package_share_directory('inference_depth'),
        'launch',
        'inference_depth.launch.xml',
    )

    return LaunchDescription([
        IncludeLaunchDescription(AnyLaunchDescriptionSource(xml_launch_file)),
    ])
