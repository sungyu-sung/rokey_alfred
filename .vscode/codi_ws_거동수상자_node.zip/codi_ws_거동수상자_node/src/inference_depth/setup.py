import os
from glob import glob
from setuptools import find_packages, setup

package_name = 'inference_depth'

setup(
    name=package_name,
    version='0.0.1',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'),
            glob('launch/*.launch.py') + glob('launch/*.launch.xml')),
    ],
    package_data={package_name: ['inference_depth_settings.json']},
    include_package_data=True,
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='han3',
    maintainer_email='hansemun1@gmail.com',
    description='YOLO + RGB-D 추론 UI 노드 - 감지된 클래스명/X/Y 좌표를 ROS2 토픽으로 발행',
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'inference_depth_node = inference_depth.inference_depth_node:main',
        ],
    },
)
