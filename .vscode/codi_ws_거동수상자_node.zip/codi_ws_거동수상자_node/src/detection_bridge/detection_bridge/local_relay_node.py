#!/usr/bin/env python3
"""도메인0(SIMPLE) 쪽: /astra/detection/info 구독 → 로컬 소켓으로 전달."""
import socket

import rclpy
from rclpy.executors import ExternalShutdownException
from rclpy.node import Node
from std_msgs.msg import String

from detection_bridge.common import SOCK_PATH, TOPIC


class LocalRelayNode(Node):
    def __init__(self):
        super().__init__('astra_bridge_local')
        self.create_subscription(String, TOPIC, self._on_msg, 10)

    def _on_msg(self, msg: String):
        try:
            with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as s:
                s.settimeout(0.5)
                s.connect(SOCK_PATH)
                s.sendall((msg.data + '\n').encode('utf-8'))
        except OSError as e:
            self.get_logger().warn(
                f'브릿지 전송 실패 (remote_relay_node 미실행?): {e}',
                throttle_duration_sec=5.0)


def main(args=None):
    rclpy.init(args=args)
    node = LocalRelayNode()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        try:
            node.destroy_node()
        except KeyboardInterrupt:
            pass
        rclpy.try_shutdown()


if __name__ == '__main__':
    main()
