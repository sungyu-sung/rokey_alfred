#!/usr/bin/env python3
"""도메인2 + ROS_DISCOVERY_SERVER 쪽: 로컬 소켓으로 받은 내용을 /astra/detection/info로 재발행."""
import os
import socket
import threading

import rclpy
from rclpy.executors import ExternalShutdownException
from rclpy.node import Node
from std_msgs.msg import String

from detection_bridge.common import SOCK_PATH, TOPIC


class RemoteRelayNode(Node):
    def __init__(self):
        super().__init__('astra_bridge_remote')
        self._pub = self.create_publisher(String, TOPIC, 10)
        self._stop = threading.Event()

        if os.path.exists(SOCK_PATH):
            os.remove(SOCK_PATH)
        self._srv = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self._srv.bind(SOCK_PATH)
        self._srv.listen(1)
        self._srv.settimeout(1.0)
        threading.Thread(target=self._accept_loop, daemon=True).start()

    def _accept_loop(self):
        while not self._stop.is_set():
            try:
                conn, _ = self._srv.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            threading.Thread(target=self._handle_conn, args=(conn,), daemon=True).start()

    def _handle_conn(self, conn):
        with conn:
            buf = b''
            while not self._stop.is_set():
                data = conn.recv(4096)
                if not data:
                    break
                buf += data
                while b'\n' in buf:
                    line, buf = buf.split(b'\n', 1)
                    if line.strip():
                        msg = String()
                        msg.data = line.decode('utf-8')
                        self._pub.publish(msg)

    def destroy_node(self):
        self._stop.set()
        try:
            self._srv.close()
        except OSError:
            pass
        if os.path.exists(SOCK_PATH):
            os.remove(SOCK_PATH)
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = RemoteRelayNode()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        try:
            node.destroy_node()
        except KeyboardInterrupt:
            pass
        rclpy.try_shutdown()


if __name__ == '__main__':
    main()
