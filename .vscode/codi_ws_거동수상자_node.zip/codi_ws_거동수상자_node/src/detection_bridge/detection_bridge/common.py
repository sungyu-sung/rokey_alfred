# 도메인0(astra/inference, SIMPLE discovery)과 도메인2(turtlebot, discovery server)는
# 같은 프로세스에서 동시에 쓸 수 없어 두 노드를 분리하고, 그 사이를 이 로컬 소켓으로 잇는다.
SOCK_PATH = '/tmp/astra_detection_bridge.sock'
TOPIC = '/astra/detection/info'
