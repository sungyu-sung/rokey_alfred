import os
from glob import glob
from setuptools import find_packages, setup

package_name = 'detection_bridge'

setup(
    name=package_name,
    version='0.0.1',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='han3',
    maintainer_email='hansemun1@gmail.com',
    description='도메인0(SIMPLE)과 도메인2(discovery server) 사이에서 /astra/detection/info를 중계',
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'local_relay_node = detection_bridge.local_relay_node:main',
            'remote_relay_node = detection_bridge.remote_relay_node:main',
        ],
    },
)
