from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    local_node = Node(
        package='detection_bridge',
        executable='local_relay_node',
        name='astra_bridge_local',
        output='screen',
        # astra_camera / inference_depth 와 동일한 환경(도메인2, Discovery Server 끔 = SIMPLE discovery)으로 고정
        additional_env={
            'ROS_DOMAIN_ID': '2',
            'ROS_DISCOVERY_SERVER': '',
            'ROS_SUPER_CLIENT': '',
        },
    )

    remote_node = Node(
        package='detection_bridge',
        executable='remote_relay_node',
        name='astra_bridge_remote',
        output='screen',
        # turtlebot4 디스커버리 서버 환경(도메인2)으로 고정
        additional_env={
            'ROS_DOMAIN_ID': '2',
            'ROS_DISCOVERY_SERVER': ';;192.168.107.102:11811',
        },
    )

    return LaunchDescription([local_node, remote_node])
